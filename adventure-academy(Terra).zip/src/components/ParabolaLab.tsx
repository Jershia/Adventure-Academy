import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sliders, Sparkles, CheckCircle, RotateCcw, ArrowRight, Lightbulb } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { NovaCompanion } from './NovaCompanion';
import { NovaDialogueModal } from './NovaDialogueModal';
import { PlayerProfile } from '../types';
import { sounds } from '../utils/soundEffects';

interface ParabolaLabProps {
  player: PlayerProfile;
  onComplete: (rewards: { xp: number; seeds: number; water: number; fertilizer: number }) => void;
  onNext?: () => void;
}

export const ParabolaLab: React.FC<ParabolaLabProps> = ({
  player,
  onComplete,
  onNext,
}) => {
  // Slider 'a' controls curvature (smaller = wider curve)
  // Slider 'b' controls shift
  const [sliderA, setSliderA] = useState<number>(1.8); // Starts narrower
  const [sliderB, setSliderB] = useState<number>(0.0);
  const [showNovaModal, setShowNovaModal] = useState(false);
  const [isCalibrated, setIsCalibrated] = useState(false);

  // Target goal: widen curve so 'a' is between 0.3 and 0.7
  const targetMinA = 0.3;
  const targetMaxA = 0.7;
  const isTargetMatched = sliderA >= targetMinA && sliderA <= targetMaxA;

  const handleSliderChangeA = (val: number) => {
    setSliderA(val);
    sounds.playClick();
    if (val >= targetMinA && val <= targetMaxA && !isCalibrated) {
      setIsCalibrated(true);
      sounds.playSuccess();
      onComplete({ xp: 120, seeds: 2, water: 2, fertilizer: 1 });
    }
  };

  // Generate SVG path coordinates for the parabola: y = a * x^2 + b * x
  // Graph dimensions: width 320, height 220. Center at (160, 160)
  const generateParabolaPoints = (aCoeff: number, bCoeff: number) => {
    const points: string[] = [];
    const centerX = 160;
    const centerY = 160;
    const scaleX = 22;
    const scaleY = 22;

    for (let x = -6; x <= 6; x += 0.2) {
      const y = aCoeff * Math.pow(x, 2) + bCoeff * x;
      const screenX = centerX + x * scaleX;
      const screenY = centerY - y * scaleY;
      points.push(`${screenX.toFixed(1)},${screenY.toFixed(1)}`);
    }
    return points.join(' ');
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex flex-col justify-between p-3 sm:p-6 overflow-hidden select-none">
      {/* Background Painted Forest Backdrop matching Frame 7 */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${ASSETS.forestPath})`,
          filter: 'brightness(0.9) contrast(1.05)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-black/50 pointer-events-none" />

      {/* Top Banner Header */}
      <div className="relative z-10 flex items-center justify-between bg-[#24170e]/90 border-2 border-[#855325] px-5 py-2.5 rounded-2xl shadow-xl backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#0284c7] text-[#fef9c3] text-[10px] font-bold px-2 py-0.5 rounded-md uppercase">
              PARABOLA FIELD LAB
            </span>
            <h2 className="font-serif font-black text-sm sm:text-base text-[#fef9c3] uppercase tracking-wider">
              VISUAL GRAPH SIMULATION: WIDEN THE CURVE
            </h2>
          </div>
          <p className="text-xs font-serif text-[#fed7aa] mt-0.5">
            Adjust slider 'a' to widen the parabola so the energy arc spans the entire river gap.
          </p>
        </div>

        <button
          onClick={() => setShowNovaModal(true)}
          className="flex items-center gap-1.5 bg-[#0369a1] hover:bg-[#0284c7] text-white px-3 py-1.5 rounded-xl border border-cyan-400 text-xs font-serif font-bold transition shadow-md"
        >
          <Lightbulb className="w-3.5 h-3.5 text-yellow-300" />
          <span>Ask Nova</span>
        </button>
      </div>

      {/* Center Stage: Ornate Wooden Easel Chalkboard matching Frame 7 */}
      <div className="relative z-10 my-4 flex-1 flex flex-col items-center justify-center max-w-4xl mx-auto w-full">
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="relative w-full max-w-xl bg-gradient-to-b from-[#3a2211] via-[#24150a] to-[#140b05] border-4 border-[#855325] rounded-3xl p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.95)] text-[#f4ecd8]"
          style={{
            boxShadow: '0 25px 50px -12px rgba(0,0,0,0.9), inset 0 2px 10px rgba(212,175,55,0.2)',
          }}
        >
          {/* Ornate Board Header */}
          <div className="flex items-center justify-between border-b border-[#5a3617] pb-3 mb-4">
            <div className="flex items-center gap-2">
              <Sliders className="w-5 h-5 text-amber-400" />
              <span className="font-serif font-bold text-sm tracking-wider uppercase text-[#fef08a]">
                Parabola Equation: y = {sliderA.toFixed(1)}x² {sliderB >= 0 ? `+ ${sliderB.toFixed(1)}x` : `- ${Math.abs(sliderB).toFixed(1)}x`}
              </span>
            </div>
            {isCalibrated && (
              <span className="bg-emerald-800 text-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase flex items-center gap-1">
                <CheckCircle className="w-3 h-3" />
                CALIBRATED
              </span>
            )}
          </div>

          {/* Chalkboard Screen with Graph Coordinate Grid */}
          <div className="relative w-full h-64 bg-[#141e1b] rounded-2xl border-4 border-[#4d3725] p-2 shadow-inner overflow-hidden flex items-center justify-center">
            <svg viewBox="0 0 320 220" className="w-full h-full">
              {/* Grid Lines */}
              <defs>
                <pattern id="chalkGrid" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#253832" strokeWidth="0.8" strokeDasharray="2 2" />
                </pattern>
                {/* Parabola Glow filter */}
                <filter id="cyanGlow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="3" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
              </defs>

              <rect width="320" height="220" fill="url(#chalkGrid)" />

              {/* X and Y Axes */}
              <line x1="0" y1="160" x2="320" y2="160" stroke="#4ade80" strokeWidth="1.5" opacity="0.7" />
              <line x1="160" y1="0" x2="160" y2="220" stroke="#4ade80" strokeWidth="1.5" opacity="0.7" />
              <text x="310" y="155" fill="#4ade80" fontSize="11" fontFamily="sans-serif">x</text>
              <text x="165" y="14" fill="#4ade80" fontSize="11" fontFamily="sans-serif">y</text>

              {/* Target Ghost Parabola (Wider Archway, target a=0.5) */}
              <polyline
                points={generateParabolaPoints(0.5, 0.0)}
                fill="none"
                stroke="#fbbf24"
                strokeWidth="2"
                strokeDasharray="4 4"
                opacity="0.4"
              />

              {/* Dynamic Interactive Parabola Curve */}
              <polyline
                points={generateParabolaPoints(sliderA, sliderB)}
                fill="none"
                stroke={isCalibrated ? '#4ade80' : '#38bdf8'}
                strokeWidth="3.5"
                strokeLinecap="round"
                filter="url(#cyanGlow)"
              />
            </svg>

            {/* Target Goal Note badge inside chalkboard */}
            <div className="absolute top-3 left-3 bg-[#0d1613]/80 border border-[#2d4d42] px-2.5 py-1 rounded-lg text-[11px] font-mono text-amber-300">
              Target Arc: a ≈ 0.5 (Wide Curve)
            </div>
          </div>

          {/* Wooden Slider Controls matching Frame 7 */}
          <div className="mt-5 space-y-4 bg-[#1f1309] p-4 rounded-2xl border-2 border-[#5a3617]">
            {/* Slider 'a' (Curvature / Width) */}
            <div>
              <div className="flex items-center justify-between text-xs font-serif font-bold uppercase tracking-wider text-[#fed7aa] mb-1">
                <span>Slider 'a' (Curvature / Width): {sliderA.toFixed(2)}</span>
                <span className={sliderA <= 0.7 && sliderA >= 0.3 ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
                  {sliderA > 1.2 ? 'Too Narrow' : sliderA < 0.3 ? 'Too Flat' : 'Perfect Width!'}
                </span>
              </div>
              <input
                type="range"
                min="0.2"
                max="2.5"
                step="0.05"
                value={sliderA}
                onChange={(e) => handleSliderChangeA(parseFloat(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer h-2 bg-[#3a2211] rounded-lg"
              />
            </div>

            {/* Slider 'b' (Shift) */}
            <div>
              <div className="flex items-center justify-between text-xs font-serif font-bold uppercase tracking-wider text-[#fed7aa] mb-1">
                <span>Slider 'b' (Axis Shift): {sliderB.toFixed(2)}</span>
                <span>{sliderB === 0 ? 'Centered' : sliderB > 0 ? 'Shifted Left' : 'Shifted Right'}</span>
              </div>
              <input
                type="range"
                min="-2.0"
                max="2.0"
                step="0.1"
                value={sliderB}
                onChange={(e) => {
                  setSliderB(parseFloat(e.target.value));
                  sounds.playClick();
                }}
                className="w-full accent-cyan-500 cursor-pointer h-2 bg-[#3a2211] rounded-lg"
              />
            </div>
          </div>

          {/* Calibrated Success Action */}
          {isCalibrated && (
            <div className="mt-4 p-3 bg-emerald-950/80 border border-emerald-500 rounded-xl flex items-center justify-between">
              <span className="text-xs font-serif text-emerald-200">
                Parabola widened successfully! Energy arch connects both banks. (+120 XP)
              </span>
              {onNext && (
                <button
                  onClick={() => {
                    sounds.playSuccess();
                    onNext();
                  }}
                  className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-serif font-bold uppercase tracking-wider transition flex items-center gap-1"
                >
                  <span>Next Step</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </motion.div>
      </div>

      {/* Nova Companion floating next to chalkboard with prompt matching Frame 7 */}
      <div className="relative z-10 flex items-center justify-between">
        <NovaCompanion
          size="md"
          mood={isCalibrated ? 'excited' : 'speaking'}
          speechBubble={
            isCalibrated
              ? 'Superb! A lower coefficient "a" widens the curve gracefully across the river.'
              : "Adjust slider 'a' to widen the curve!"
          }
        />
      </div>

      {/* AI Nova Hint Modal */}
      <NovaDialogueModal
        isOpen={showNovaModal}
        onClose={() => setShowNovaModal(false)}
        problemContext={{
          question: 'y = ax^2 + bx parabola curvature',
          topic: 'Parabola Width & Transformations',
          currentInput: `a=${sliderA}, b=${sliderB}`,
        }}
      />
    </div>
  );
};
