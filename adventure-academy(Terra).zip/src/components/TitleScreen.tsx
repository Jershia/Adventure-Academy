import React from 'react';
import { motion } from 'motion/react';
import { Settings, Play, Sparkles, User, ShieldCheck } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { TerraCompanion } from './TerraCompanion';
import { sounds } from '../utils/soundEffects';

interface TitleScreenProps {
  onStart: () => void;
  onOpenLogin: () => void;
  onOpenSetup: () => void;
  onOpenSettings: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStart,
  onOpenLogin,
  onOpenSetup,
  onOpenSettings,
}) => {
  return (
    <div className="relative min-h-[calc(100vh-56px)] flex items-center justify-center p-4 overflow-hidden select-none">
      {/* Background Painted Forest Backdrop */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-all duration-700"
        style={{
          backgroundImage: `url(${ASSETS.forestPath})`,
          filter: 'brightness(0.9) contrast(1.05)',
        }}
      />

      {/* Atmospheric vignette & dappled sunlight rays */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#120a05]/80 via-transparent to-[#120a05]/40 pointer-events-none" />

      {/* Top Right Gear Button */}
      <button
        onClick={() => {
          sounds.playClick();
          onOpenSettings();
        }}
        className="absolute top-6 right-6 z-20 w-12 h-12 bg-[#2d1e13]/90 hover:bg-[#3d2919] border-2 border-[#855325] rounded-xl flex items-center justify-center text-[#fef08a] shadow-2xl transition active:scale-95"
        title="Settings"
      >
        <Settings className="w-6 h-6" />
      </button>

      {/* Main Container */}
      <div className="relative z-10 max-w-4xl w-full flex flex-col items-center justify-center text-center">
        {/* Natural Wooden Banner Title */}
        <motion.div
          initial={{ y: -40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="relative max-w-2xl w-full bg-gradient-to-b from-[#3d2514] via-[#2a170a] to-[#170c04] border-2 border-[#855325]/80 rounded-2xl p-6 sm:p-9 shadow-[0_20px_50px_rgba(0,0,0,0.7)]"
        >
          {/* Natural Forest Subtitle */}
          <div className="inline-block px-4 py-1 rounded-full bg-[#1b1007]/80 border border-emerald-700/60 text-emerald-400 font-mono text-xs uppercase tracking-widest mb-3">
            An Adaptive Woodland Learning Odyssey
          </div>

          <h1 className="font-serif font-black text-3xl sm:text-5xl md:text-6xl text-[#fef9c3] tracking-wide uppercase drop-shadow-[0_4px_8px_rgba(0,0,0,0.9)]">
            Adventure Academy
          </h1>

          <div className="mt-2 text-base sm:text-xl font-serif italic text-[#fed7aa] tracking-widest font-semibold flex items-center justify-center gap-2">
            <span>LEARN.</span>
            <span className="text-emerald-400">•</span>
            <span>RESTORE.</span>
            <span className="text-emerald-400">•</span>
            <span>GROW.</span>
          </div>
        </motion.div>

        {/* Character & Terra Display Center */}
        <div className="my-8 flex items-center justify-center gap-8 relative">
          {/* Explorer Character Card */}
          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="flex flex-col items-center"
          >
            <div className="w-32 h-44 sm:w-40 sm:h-52 rounded-2xl bg-[#2a170b]/90 border border-[#855325]/80 p-2.5 flex flex-col items-center justify-between shadow-2xl backdrop-blur-sm relative overflow-hidden">
              <div className="w-24 h-28 sm:w-32 sm:h-36 rounded-xl overflow-hidden shadow-inner">
                <img
                  src={ASSETS.forestExplorer}
                  alt="Woodland Explorer"
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="text-[11px] font-serif font-bold text-amber-200 bg-[#140b05] px-3 py-0.5 rounded-full border border-amber-700/60">
                Woodland Explorer
              </div>
            </div>
          </motion.div>

          {/* Terra Forest Spirit Companion */}
          <motion.div
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="flex flex-col items-center"
          >
            <TerraCompanion
              size="lg"
              mood="speaking"
              speechBubble="The living forest whispers of ancient mysteries waiting to be solved!"
            />
          </motion.div>
        </div>

        {/* Start Button & Alternative Options */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="flex flex-col items-center gap-3 w-full max-w-md"
        >
          {/* Big Tactile START Button */}
          <button
            onClick={() => {
              sounds.playSuccess();
              onStart();
            }}
            className="w-full py-4 px-8 bg-gradient-to-b from-[#2d6a4f] via-[#1b4332] to-[#081c15] hover:from-[#40916c] hover:to-[#1b4332] text-[#fef9c3] font-serif font-black text-2xl tracking-widest rounded-2xl border-2 border-emerald-400/70 shadow-[0_10px_25px_rgba(0,0,0,0.8)] transition-all transform hover:-translate-y-1 active:translate-y-0.5 uppercase flex items-center justify-center gap-3"
            style={{
              textShadow: '0 2px 4px rgba(0,0,0,0.8)',
            }}
          >
            <Play className="w-6 h-6 fill-[#fef9c3]" />
            START ADVENTURE
          </button>

          {/* Sub-buttons: Login, Character Setup */}
          <div className="grid grid-cols-2 gap-3 w-full">
            <button
              onClick={() => {
                sounds.playClick();
                onOpenLogin();
              }}
              className="py-2.5 px-4 bg-[#2c1a0e]/90 hover:bg-[#3d2615] text-[#fed7aa] border border-[#855325]/80 rounded-xl text-xs font-serif font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition"
            >
              <User className="w-3.5 h-3.5 text-amber-400" />
              Explorer Sign In
            </button>

            <button
              onClick={() => {
                sounds.playClick();
                onOpenSetup();
              }}
              className="py-2.5 px-4 bg-[#2c1a0e]/90 hover:bg-[#3d2615] text-[#fed7aa] border border-[#855325]/80 rounded-xl text-xs font-serif font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Character Setup
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
