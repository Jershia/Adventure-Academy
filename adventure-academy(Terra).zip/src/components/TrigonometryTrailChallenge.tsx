import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { Triangle, Sparkles, Trophy, HelpCircle, CheckCircle2, ChevronRight, Sliders, Eye } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { NovaDialogueModal } from './NovaDialogueModal';
import { PlayerProfile } from '../types';
import { sounds } from '../utils/soundEffects';

interface TrigonometryTrailChallengeProps {
  player: PlayerProfile;
  onComplete: (rewards: { xp: number; seeds: number; water: number; fertilizer: number }) => void;
  onNext?: () => void;
  onBackToMap?: () => void;
}

interface TrigStage {
  id: number;
  title: string;
  subtitle: string;
  prompt: string;
  formula: string;
  options: { label: string; value: string; correct: boolean; explanation: string }[];
  hint: string;
}

export const TrigonometryTrailChallenge: React.FC<TrigonometryTrailChallengeProps> = ({
  player,
  onComplete,
  onNext,
  onBackToMap,
}) => {
  const [currentStageIdx, setCurrentStageIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [stageCleared, setStageCleared] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [showNovaModal, setShowNovaModal] = useState(false);

  // Interactive Angle Slider State (degrees)
  const [angleDeg, setAngleDeg] = useState(45);

  const STAGES: TrigStage[] = [
    {
      id: 1,
      title: 'Stage 1: The Beacon of Tangents',
      subtitle: 'SOH • CAH • TOA Fundamentals',
      prompt: 'Adjust the surveyor beacon angle. When the elevation angle is set to exactly θ = 45°, what is the value of tan(45°), and why?',
      formula: '\\tan(\\theta) = \\frac{\\text{Opposite}}{\\text{Adjacent}}',
      options: [
        {
          label: 'tan(45°) = 1 (Opposite = Adjacent)',
          value: '1',
          correct: true,
          explanation: 'Precisely! In a 45°-45°-90° isosceles right triangle, both legs are equal in length, so opposite / adjacent = 1!',
        },
        {
          label: 'tan(45°) = 0.5 (Half of a right angle)',
          value: '0.5',
          correct: false,
          explanation: 'Angle ratios are non-linear trigonometric functions, not direct fractions of 90°!',
        },
        {
          label: 'tan(45°) = √2 ≈ 1.414',
          value: 'sqrt2',
          correct: false,
          explanation: '√2 is the hypotenuse ratio when each leg is 1 (c² = 1² + 1² = 2). Tan is leg/leg = 1!',
        },
        {
          label: 'tan(45°) = 0',
          value: '0',
          correct: false,
          explanation: 'tan(0°) is 0, but at 45° the opposite side equals the adjacent side!',
        },
      ],
      hint: 'Move the slider to 45°. Notice how the vertical height (Opposite) matches the horizontal base (Adjacent) exactly.',
    },
    {
      id: 2,
      title: 'Stage 2: Cliffside Watchtower Height',
      subtitle: 'Indirect Measurement with Tangent',
      prompt: 'From a surveying tripod 40 meters from the base of an ancient cliff, the angle of elevation to the watchtower crest is θ = 30°. Given tan(30°) = 1/√3 ≈ 0.577, what is the height of the watchtower?',
      formula: 'h = d \\times \\tan(\\theta) = 40 \\times 0.577',
      options: [
        {
          label: 'h ≈ 23.09 meters',
          value: '23.09',
          correct: true,
          explanation: 'Excellent math! h = 40 × tan(30°) = 40 × 0.57735 ≈ 23.09 meters tall!',
        },
        {
          label: 'h = 20.00 meters',
          value: '20',
          correct: false,
          explanation: '20 meters would be 40 × sin(30°), but the tripod distance is along the ground (adjacent), not the line of sight (hypotenuse)!',
        },
        {
          label: 'h = 40.00 meters',
          value: '40',
          correct: false,
          explanation: 'At 40 meters tall, the angle would be 45° because tan(45°) = 1.',
        },
        {
          label: 'h ≈ 34.64 meters',
          value: '34.64',
          correct: false,
          explanation: '34.64 is 40 × cos(30°). Remember to use Tangent = Opposite / Adjacent!',
        },
      ],
      hint: 'Remember: tan(θ) = Opposite / Adjacent. Here, Adjacent = 40m, so Height (Opposite) = 40 × tan(30°).',
    },
    {
      id: 3,
      title: 'Stage 3: The Chasm Zipline Cable',
      subtitle: 'Pythagorean & Hypotenuse Rope Geometry',
      prompt: 'To anchor a rescue zipline across the misty gorge, the vertical drop is 30 meters and the horizontal gap is 40 meters. What is the minimum length of steel cable (Hypotenuse c) needed?',
      formula: 'c^2 = a^2 + b^2 \\implies c = \\sqrt{30^2 + 40^2}',
      options: [
        {
          label: 'c = 50 meters (Classic 3-4-5 Pythagorean Triple)',
          value: '50',
          correct: true,
          explanation: 'Masterful! 30² + 40² = 900 + 1600 = 2500, and √2500 = 50 meters! The cable connects cleanly.',
        },
        {
          label: 'c = 70 meters (30 + 40)',
          value: '70',
          correct: false,
          explanation: 'Direct addition violates the triangle inequality theorem: the straight diagonal is always shorter than the sum of both legs!',
        },
        {
          label: 'c ≈ 45.5 meters',
          value: '45.5',
          correct: false,
          explanation: 'Calculate 30² (900) + 40² (1600) = 2500. √2500 is exactly 50.',
        },
        {
          label: 'c = 60 meters',
          value: '60',
          correct: false,
          explanation: 'Close estimate, but the exact Pythagorean root of 2500 is 50.',
        },
      ],
      hint: 'Use the Pythagorean theorem: c = √(30² + 40²) = √(900 + 1600) = √2500.',
    },
  ];

  const currentStage = STAGES[currentStageIdx];

  // Dynamic calculations for the interactive triangle
  const angleRad = (angleDeg * Math.PI) / 180;
  const sinVal = Math.sin(angleRad).toFixed(3);
  const cosVal = Math.cos(angleRad).toFixed(3);
  const tanVal = Math.tan(angleRad).toFixed(3);

  // SVG dimensions for dynamic right triangle
  const baseWidth = 140;
  const heightVal = Math.min(130, Math.max(20, Math.round(baseWidth * Math.tan(angleRad) * 0.7)));

  const handleSelectOption = (idx: number) => {
    setSelectedOption(idx);
    const opt = currentStage.options[idx];

    if (opt.correct) {
      sounds.playSuccess();
      sounds.playMagicChime();
      setStageCleared(true);

      if (currentStageIdx === STAGES.length - 1) {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#06b6d4', '#3b82f6', '#f59e0b', '#10b981'],
        });
        setTimeout(() => {
          setShowCelebration(true);
          onComplete({
            xp: 220,
            seeds: 5,
            water: 4,
            fertilizer: 2,
          });
        }, 1200);
      }
    } else {
      sounds.playError();
      setShowNovaModal(true);
    }
  };

  const handleNextStage = () => {
    if (currentStageIdx < STAGES.length - 1) {
      sounds.playClick();
      setCurrentStageIdx((prev) => prev + 1);
      setSelectedOption(null);
      setStageCleared(false);
    }
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex items-center justify-center p-3 sm:p-6 overflow-hidden select-none">
      {/* Background Mountain Trail */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${ASSETS.forestBackground})`,
          filter: 'hue-rotate(180deg) brightness(0.85) contrast(1.1)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/45 to-black/65 pointer-events-none" />

      {/* Main Altar Board */}
      <div className="relative z-10 w-full max-w-4xl bg-gradient-to-b from-[#1b2229] via-[#11171d] to-[#0a0d10] border-4 border-[#38bdf8]/60 rounded-3xl p-4 sm:p-7 shadow-[0_25px_60px_rgba(0,0,0,0.9)] flex flex-col justify-between">
        {/* Header Ribbon */}
        <div className="flex flex-wrap items-center justify-between border-b-2 border-cyan-800/60 pb-3 gap-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-950/80 border border-cyan-400 flex items-center justify-center text-cyan-300 shadow-md">
              <Triangle className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="text-[11px] font-mono uppercase tracking-widest text-cyan-300">
                Trigonometry Trail • Realm Challenge
              </div>
              <h2 className="font-serif font-black text-xl sm:text-2xl text-cyan-50">
                The Beacon of Tangents & Watchtower
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="bg-[#0b1015] border border-cyan-600/60 px-3 py-1.5 rounded-xl text-xs font-mono text-cyan-200">
              Stage {currentStageIdx + 1} of {STAGES.length}
            </div>
            <button
              onClick={() => {
                sounds.playClick();
                setShowNovaModal(true);
              }}
              className="p-2 bg-cyan-900/40 hover:bg-cyan-800/60 border border-cyan-500/60 rounded-xl text-cyan-200 transition"
              title="Ask Nova for a hint"
            >
              <HelpCircle className="w-5 h-5 text-cyan-400" />
            </button>
          </div>
        </div>

        {/* Challenge Stage Content */}
        <div className="my-5 grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
          {/* Left: Dynamic Right-Angle Triangle SVG + Slider */}
          <div className="md:col-span-5 bg-[#080d12]/95 border-2 border-cyan-800/60 rounded-2xl p-4 flex flex-col items-center justify-between min-h-[280px] shadow-inner">
            <div className="w-full flex items-center justify-between text-xs font-serif font-bold text-cyan-300">
              <span className="flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <span>Surveyor Angle (θ)</span>
              </span>
              <span className="font-mono text-cyan-200 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-700">
                {angleDeg}°
              </span>
            </div>

            {/* Slider */}
            <input
              type="range"
              min="15"
              max="75"
              value={angleDeg}
              onChange={(e) => {
                setAngleDeg(Number(e.target.value));
                sounds.playClick();
              }}
              className="w-full h-2 bg-cyan-950 rounded-lg appearance-none cursor-pointer accent-cyan-400 my-2"
            />

            {/* Interactive SVG Diagram */}
            <div className="w-full h-36 flex items-center justify-center relative my-1">
              <svg width="220" height="140" viewBox="0 0 220 140" className="overflow-visible">
                {/* Ground Line */}
                <line x1="20" y1="120" x2="200" y2="120" stroke="#334155" strokeWidth="2" strokeDasharray="4 4" />

                {/* Right Triangle */}
                {/* Horizontal Leg (Adjacent) */}
                <line x1="40" y1="120" x2={40 + baseWidth} y2="120" stroke="#38bdf8" strokeWidth="3" />
                <text x={40 + baseWidth / 2} y="135" fill="#7dd3fc" fontSize="10" textAnchor="middle" fontFamily="monospace">
                  Adj = 40m
                </text>

                {/* Vertical Leg (Opposite) */}
                <line x1={40 + baseWidth} y1="120" x2={40 + baseWidth} y2={120 - heightVal} stroke="#f43f5e" strokeWidth="3" />
                <text x={40 + baseWidth + 8} y={120 - heightVal / 2} fill="#fb7185" fontSize="10" fontFamily="monospace">
                  Opp (h)
                </text>

                {/* Hypotenuse (Light Laser Beam) */}
                <line x1="40" y1="120" x2={40 + baseWidth} y2={120 - heightVal} stroke="#34d399" strokeWidth="3" strokeDasharray="3 2" />

                {/* Right-angle marker */}
                <rect x={40 + baseWidth - 10} y="110" width="10" height="10" fill="none" stroke="#94a3b8" strokeWidth="1" />

                {/* Angle Arc */}
                <path d={`M 65 120 A 25 25 0 0 0 ${40 + 25 * Math.cos(angleRad)} ${120 - 25 * Math.sin(angleRad)}`} fill="none" stroke="#facc15" strokeWidth="2" />
                <text x="70" y="112" fill="#fde047" fontSize="10" fontWeight="bold" fontFamily="monospace">
                  θ
                </text>
              </svg>
            </div>

            {/* Trig Ratios Readout */}
            <div className="w-full grid grid-cols-3 gap-1.5 text-center text-[10px] font-mono mt-1">
              <div className="bg-cyan-950/80 border border-cyan-700/60 p-1.5 rounded-lg text-cyan-200">
                sin(θ) = {sinVal}
              </div>
              <div className="bg-cyan-950/80 border border-cyan-700/60 p-1.5 rounded-lg text-cyan-200">
                cos(θ) = {cosVal}
              </div>
              <div className="bg-amber-950/80 border border-amber-600/60 p-1.5 rounded-lg text-amber-200 font-bold">
                tan(θ) = {tanVal}
              </div>
            </div>
          </div>

          {/* Right: Question & Multiple Choice */}
          <div className="md:col-span-7 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono uppercase tracking-widest text-cyan-400 mb-1">
                {currentStage.subtitle}
              </div>
              <h3 className="font-serif font-bold text-lg sm:text-xl text-cyan-50 leading-snug mb-3">
                {currentStage.prompt}
              </h3>

              <div className="bg-[#081119] border border-cyan-600/40 rounded-xl px-3 py-2 text-xs font-mono text-cyan-300 mb-4 inline-block">
                Target Formula: {currentStage.formula}
              </div>
            </div>

            {/* Options Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 my-2">
              {currentStage.options.map((option, idx) => {
                const isSelected = selectedOption === idx;
                const isCorrect = option.correct;
                let btnStyle = 'bg-[#101720] hover:bg-[#162230] border-cyan-800/60 text-cyan-100';

                if (isSelected) {
                  btnStyle = isCorrect
                    ? 'bg-emerald-950/90 border-emerald-400 text-emerald-100 ring-2 ring-emerald-500'
                    : 'bg-red-950/90 border-red-400 text-red-100 ring-2 ring-red-500';
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(idx)}
                    disabled={stageCleared}
                    className={`p-3 border-2 rounded-xl text-left transition-all active:scale-[0.98] shadow-md flex items-center justify-between text-xs sm:text-sm font-serif font-bold ${btnStyle}`}
                  >
                    <span>{option.label}</span>
                    {isSelected && isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 ml-2" />}
                  </button>
                );
              })}
            </div>

            {/* Advance / Next Stage Footer */}
            <div className="mt-4 flex items-center justify-between pt-2 border-t border-cyan-900/60">
              {stageCleared ? (
                <div className="flex items-center justify-between w-full">
                  <div className="text-xs font-mono text-emerald-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Watchtower Calibrated!</span>
                  </div>

                  {currentStageIdx < STAGES.length - 1 ? (
                    <button
                      onClick={handleNextStage}
                      className="px-5 py-2 bg-gradient-to-r from-cyan-600 to-blue-700 hover:from-cyan-500 hover:to-blue-600 text-white font-serif font-bold text-xs rounded-xl shadow-lg flex items-center gap-1.5 active:scale-95 transition"
                    >
                      <span>Next Stage</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        sounds.playVictoryFanfare();
                        setShowCelebration(true);
                      }}
                      className="px-5 py-2 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black font-serif font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 active:scale-95 transition"
                    >
                      <Trophy className="w-4 h-4" />
                      <span>Claim Trail Rewards</span>
                    </button>
                  )}
                </div>
              ) : (
                <div className="text-xs font-serif text-cyan-200/60 italic">
                  Select the trigonometrically accurate solution to focus the surveyor beacon.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom Companion Footer & Back to Map */}
        <div className="flex items-center justify-between border-t border-cyan-900/60 pt-3 text-xs">
          <button
            onClick={() => {
              sounds.playClick();
              if (onBackToMap) onBackToMap();
            }}
            className="text-cyan-300 hover:text-cyan-100 font-serif font-bold transition flex items-center gap-1"
          >
            ← Return to World Map
          </button>

          <div className="flex items-center gap-2">
            <span className="text-cyan-300 font-mono text-[11px]">Pythagorean Sync:</span>
            <span className="text-emerald-400 font-serif font-bold">100% Geometry Resonance</span>
          </div>
        </div>
      </div>

      {/* Nova Hint Modal */}
      <AnimatePresence>
        {showNovaModal && (
          <NovaDialogueModal
            isOpen={showNovaModal}
            onClose={() => setShowNovaModal(false)}
            onTryAgain={() => {
              setShowNovaModal(false);
              setSelectedOption(null);
            }}
            question={currentStage.prompt}
            topic="Trigonometry & Right Triangles"
            playerGrade={player.grade}
          />
        )}
      </AnimatePresence>

      {/* Final Victory Celebration Modal */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="w-full max-w-md bg-gradient-to-b from-[#111f2a] to-[#080d12] border-4 border-cyan-400 rounded-3xl p-6 shadow-2xl text-center flex flex-col items-center"
            >
              <div className="w-16 h-16 rounded-2xl bg-cyan-500/20 border-2 border-cyan-400 flex items-center justify-center text-cyan-300 mb-3 animate-bounce">
                <Trophy className="w-8 h-8" />
              </div>

              <div className="text-xs font-mono uppercase tracking-widest text-cyan-400">
                TRIGONOMETRY TRAIL CLEARED
              </div>
              <h2 className="font-serif font-black text-2xl sm:text-3xl text-cyan-100 mt-1 mb-2">
                Pinnacle Surveyor!
              </h2>

              <p className="text-sm text-cyan-100/90 font-serif leading-relaxed mb-4">
                You harnessed the tangent of elevation, unraveled Pythagorean cables across the gorge, and lit the summit watchtowers!
              </p>

              {/* Rewards Box */}
              <div className="w-full bg-[#070e14] border-2 border-cyan-600/60 rounded-2xl p-3.5 mb-5 flex justify-around text-center font-mono">
                <div>
                  <div className="text-lg font-bold text-yellow-400">+220</div>
                  <div className="text-[10px] text-cyan-200/80">XP</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-emerald-400">+5</div>
                  <div className="text-[10px] text-cyan-200/80">SEEDS</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-cyan-400">+4</div>
                  <div className="text-[10px] text-cyan-200/80">WATER</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-orange-400">+2</div>
                  <div className="text-[10px] text-cyan-200/80">FERTILIZER</div>
                </div>
              </div>

              <div className="flex gap-2 w-full">
                <button
                  onClick={() => {
                    sounds.playClick();
                    if (onNext) onNext();
                    else if (onBackToMap) onBackToMap();
                  }}
                  className="flex-1 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-serif font-black text-sm rounded-xl shadow-lg active:scale-95 transition"
                >
                  Continue Expedition
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
