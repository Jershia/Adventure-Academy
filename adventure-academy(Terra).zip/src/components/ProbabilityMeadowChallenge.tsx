import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { Dices, Sparkles, Trophy, ArrowRight, RotateCcw, HelpCircle, CheckCircle2, Award, ChevronRight } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { NovaCompanion } from './NovaCompanion';
import { NovaDialogueModal } from './NovaDialogueModal';
import { PlayerProfile } from '../types';
import { sounds } from '../utils/soundEffects';

interface ProbabilityMeadowChallengeProps {
  player: PlayerProfile;
  onComplete: (rewards: { xp: number; seeds: number; water: number; fertilizer: number }) => void;
  onNext?: () => void;
  onBackToMap?: () => void;
}

interface QuestionStage {
  id: number;
  title: string;
  subtitle: string;
  prompt: string;
  mathFormula?: string;
  visualType: 'dice' | 'urn' | 'spinner';
  options: { label: string; value: string; correct: boolean; explanation: string }[];
  hint: string;
}

export const ProbabilityMeadowChallenge: React.FC<ProbabilityMeadowChallengeProps> = ({
  player,
  onComplete,
  onNext,
  onBackToMap,
}) => {
  const [currentStageIdx, setCurrentStageIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [stageCleared, setStageCleared] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [showNovaModal, setShowNovaModal] = useState(false);
  const [novaFeedback, setNovaFeedback] = useState<{ title: string; body: string }>({ title: '', body: '' });

  // Interactive dice simulator state
  const [dice1, setDice1] = useState(3);
  const [dice2, setDice2] = useState(5);
  const [isRolling, setIsRolling] = useState(false);

  // Interactive Urn state
  const [drawnRunes, setDrawnRunes] = useState<string[]>([]);

  const STAGES: QuestionStage[] = [
    {
      id: 1,
      title: 'Stage 1: The Twin Celestial Dice',
      subtitle: 'Sample Space & Compound Probability',
      prompt: 'Two ancient 6-sided dice are cast upon the meadow altar. What is the exact probability of rolling a combined sum of 9 or higher (Sum ≥ 9)?',
      mathFormula: 'P(\\text{Sum} \\ge 9) = \\frac{\\text{Successful Combinations}}{36}',
      visualType: 'dice',
      options: [
        {
          label: '10 / 36 (or 5 / 18)',
          value: '5/18',
          correct: true,
          explanation: 'Exactly right! The successful rolls are: (3,6), (4,5), (4,6), (5,4), (5,5), (5,6), (6,3), (6,4), (6,5), (6,6) = 10 outcomes out of 36!',
        },
        {
          label: '6 / 36 (or 1 / 6)',
          value: '1/6',
          correct: false,
          explanation: '6 outcomes only cover sums equal to 7. For sum ≥ 9, there are 10 valid combinations!',
        },
        {
          label: '12 / 36 (or 1 / 3)',
          value: '1/3',
          correct: false,
          explanation: 'A bit too high! Count the outcomes carefully: 4 ways for 9, 3 ways for 10, 2 ways for 11, 1 way for 12.',
        },
        {
          label: '8 / 36 (or 2 / 9)',
          value: '2/9',
          correct: false,
          explanation: 'Close, but remember to include sums of 11 (2 ways) and 12 (1 way) along with 9 and 10!',
        },
      ],
      hint: 'List the sums: Sum = 9 has 4 ways (3+6, 4+5, 5+4, 6+3). Sum = 10 has 3 ways. Sum = 11 has 2 ways. Sum = 12 has 1 way. Add them up!',
    },
    {
      id: 2,
      title: 'Stage 2: The Urn of Elemental Runes',
      subtitle: 'Dependent Events Without Replacement',
      prompt: 'A sacred urn contains 5 Fire Rubies, 4 Water Sapphires, and 3 Earth Emeralds (12 total runes). If you draw two runes consecutively WITHOUT replacement, what is the probability that BOTH are Water Sapphires?',
      mathFormula: 'P(W_1 \\cap W_2) = P(W_1) \\times P(W_2 \\mid W_1)',
      visualType: 'urn',
      options: [
        {
          label: '4/12 × 3/11 = 1/11 (approx 9.1%)',
          value: '1/11',
          correct: true,
          explanation: 'Brilliant! First draw has 4/12 chance. With one sapphire gone, the second draw has 3/11 chance: 12/132 = 1/11!',
        },
        {
          label: '4/12 × 4/12 = 1/9 (approx 11.1%)',
          value: '1/9',
          correct: false,
          explanation: 'That would be WITH replacement! The question states the first rune is NOT replaced, so 11 runes remain.',
        },
        {
          label: '4/12 + 3/11 = 20/33',
          value: '20/33',
          correct: false,
          explanation: 'We multiply probabilities for compound sequential events ("AND"), we do not add them!',
        },
        {
          label: '3/12 = 1/4',
          value: '1/4',
          correct: false,
          explanation: 'Remember both draws must be sapphires: the second draw depends on the first reduction.',
        },
      ],
      hint: 'The first sapphire has probability 4/12. Since it is removed, there are now 3 sapphires left among 11 total runes: multiply 4/12 by 3/11!',
    },
    {
      id: 3,
      title: 'Stage 3: The Totem of Expected Value',
      subtitle: 'Expected Value E(X) = Σ [x · P(x)]',
      prompt: 'The Altar Dial offers 3 enchanted outcomes: 50% chance of gaining 10 seeds, 30% chance of gaining 20 seeds, and 20% chance of gaining 50 seeds. What is the Expected Value of seeds per spin?',
      mathFormula: 'E(X) = (0.50 \\times 10) + (0.30 \\times 20) + (0.20 \\times 50)',
      visualType: 'spinner',
      options: [
        {
          label: '21 Seeds',
          value: '21',
          correct: true,
          explanation: 'Spot on! (0.50 × 10 = 5) + (0.30 × 20 = 6) + (0.20 × 50 = 10) = 5 + 6 + 10 = 21 seeds on average!',
        },
        {
          label: '26.6 Seeds (Simple Average)',
          value: '26.6',
          correct: false,
          explanation: 'A simple average (10 + 20 + 50)/3 assumes equal probability, but the 10 seed outcome happens 50% of the time!',
        },
        {
          label: '18 Seeds',
          value: '18',
          correct: false,
          explanation: 'Check the arithmetic: 5 from the first term + 6 from the second + 10 from the third!',
        },
        {
          label: '25 Seeds',
          value: '25',
          correct: false,
          explanation: 'Close, but calculate weighted values: 5 + 6 + 10.',
        },
      ],
      hint: 'Multiply each reward by its probability and sum them: (10 × 0.5) + (20 × 0.3) + (50 × 0.2).',
    },
  ];

  const currentStage = STAGES[currentStageIdx];

  const rollDice = () => {
    if (isRolling) return;
    setIsRolling(true);
    sounds.playClick();
    let ticks = 0;
    const interval = setInterval(() => {
      setDice1(Math.floor(Math.random() * 6) + 1);
      setDice2(Math.floor(Math.random() * 6) + 1);
      ticks++;
      if (ticks > 8) {
        clearInterval(interval);
        setIsRolling(false);
        sounds.playWater();
      }
    }, 80);
  };

  const drawRuneFromUrn = () => {
    const urn = ['Ruby (Fire)', 'Sapphire (Water)', 'Emerald (Earth)'];
    const randomRune = urn[Math.floor(Math.random() * urn.length)];
    setDrawnRunes((prev) => [randomRune, ...prev.slice(0, 3)]);
    sounds.playPlant();
  };

  const handleSelectOption = (idx: number) => {
    setSelectedOption(idx);
    const opt = currentStage.options[idx];

    if (opt.correct) {
      sounds.playSuccess();
      sounds.playMagicChime();
      setStageCleared(true);

      if (currentStageIdx === STAGES.length - 1) {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#a855f7', '#3b82f6', '#10b981', '#f59e0b'],
        });
        setTimeout(() => {
          setShowCelebration(true);
          onComplete({
            xp: 200,
            seeds: 6,
            water: 3,
            fertilizer: 2,
          });
        }, 1200);
      }
    } else {
      sounds.playError();
      setNovaFeedback({
        title: 'Nova\'s Probability Insight',
        body: `${opt.explanation}\n\nHint: ${currentStage.hint}`,
      });
      setShowNovaModal(true);
    }
  };

  const handleNextStage = () => {
    if (currentStageIdx < STAGES.length - 1) {
      sounds.playClick();
      setCurrentStageIdx((prev) => prev + 1);
      setSelectedOption(null);
      setStageCleared(false);
    }
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex items-center justify-center p-3 sm:p-6 overflow-hidden select-none">
      {/* Background Painted Vintage Meadow */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${ASSETS.forestBackground})`,
          filter: 'hue-rotate(30deg) brightness(0.9)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-black/60 pointer-events-none" />

      {/* Main Altar Board */}
      <div className="relative z-10 w-full max-w-4xl bg-gradient-to-b from-[#26180c] via-[#1f140b] to-[#120a05] border-4 border-[#855325] rounded-3xl p-4 sm:p-7 shadow-[0_25px_60px_rgba(0,0,0,0.9)] flex flex-col justify-between">
        {/* Header Ribbon */}
        <div className="flex flex-wrap items-center justify-between border-b-2 border-[#5e3816] pb-3 gap-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-900/60 border border-purple-500/80 flex items-center justify-center text-purple-300 shadow-md">
              <Dices className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="text-[11px] font-mono uppercase tracking-widest text-purple-300">
                Probability Meadow • Realm Challenge
              </div>
              <h2 className="font-serif font-black text-xl sm:text-2xl text-amber-100">
                The Dice of Destiny & Lucky Totems
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="bg-[#120803] border border-amber-600/60 px-3 py-1.5 rounded-xl text-xs font-mono text-amber-200">
              Stage {currentStageIdx + 1} of {STAGES.length}
            </div>
            <button
              onClick={() => {
                sounds.playClick();
                setNovaFeedback({
                  title: 'Nova Companion Guidance',
                  body: currentStage.hint,
                });
                setShowNovaModal(true);
              }}
              className="p-2 bg-amber-900/40 hover:bg-amber-800/60 border border-amber-500/60 rounded-xl text-amber-200 transition"
              title="Ask Nova for a hint"
            >
              <HelpCircle className="w-5 h-5 text-amber-400" />
            </button>
          </div>
        </div>

        {/* Challenge Stage Content */}
        <div className="my-5 grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
          {/* Left / Top: Interactive Visual Area (Dice / Urn / Spinner) */}
          <div className="md:col-span-5 bg-[#140b05]/90 border-2 border-[#5a3818] rounded-2xl p-4 flex flex-col items-center justify-center min-h-[260px] shadow-inner relative overflow-hidden">
            <div className="text-xs font-serif font-bold text-amber-300/80 uppercase tracking-wider mb-2">
              {currentStage.visualType === 'dice' && 'Celestial Dice Altar'}
              {currentStage.visualType === 'urn' && 'Urn of 12 Elemental Runes'}
              {currentStage.visualType === 'spinner' && 'Altar Wheel of Fortune'}
            </div>

            {/* DICE VISUALIZER */}
            {currentStage.visualType === 'dice' && (
              <div className="flex flex-col items-center gap-4">
                <div className="flex items-center gap-4">
                  {/* Die 1 */}
                  <motion.div
                    animate={isRolling ? { rotate: [0, 90, 180, 270, 360], scale: [1, 1.1, 1] } : {}}
                    transition={{ repeat: isRolling ? Infinity : 0, duration: 0.3 }}
                    className="w-16 h-16 bg-gradient-to-br from-[#fef3c7] to-[#d97706] border-2 border-amber-200 rounded-2xl shadow-xl flex items-center justify-center font-serif font-black text-3xl text-[#451a03]"
                  >
                    {dice1}
                  </motion.div>

                  <span className="text-2xl font-black text-amber-400">+</span>

                  {/* Die 2 */}
                  <motion.div
                    animate={isRolling ? { rotate: [0, -90, -180, -270, -360], scale: [1, 1.1, 1] } : {}}
                    transition={{ repeat: isRolling ? Infinity : 0, duration: 0.3 }}
                    className="w-16 h-16 bg-gradient-to-br from-[#fef3c7] to-[#d97706] border-2 border-amber-200 rounded-2xl shadow-xl flex items-center justify-center font-serif font-black text-3xl text-[#451a03]"
                  >
                    {dice2}
                  </motion.div>

                  <span className="text-2xl font-black text-amber-400">=</span>

                  {/* Sum Display */}
                  <div className="w-16 h-16 bg-purple-950/80 border-2 border-purple-400 rounded-2xl flex flex-col items-center justify-center">
                    <span className="text-[10px] text-purple-300 font-mono">SUM</span>
                    <span className="text-2xl font-serif font-black text-purple-200">{dice1 + dice2}</span>
                  </div>
                </div>

                <button
                  onClick={rollDice}
                  disabled={isRolling}
                  className="px-4 py-2 bg-gradient-to-r from-purple-800 to-indigo-900 hover:from-purple-700 hover:to-indigo-800 border-2 border-purple-400/80 rounded-xl text-xs font-serif font-bold text-white shadow-md active:scale-95 transition flex items-center gap-2"
                >
                  <Dices className="w-4 h-4" />
                  <span>{isRolling ? 'Rolling...' : 'Test Roll Dice'}</span>
                </button>

                <div className="text-[11px] text-amber-200/70 font-mono text-center">
                  Total Outcomes: 6 × 6 = 36
                </div>
              </div>
            )}

            {/* URN VISUALIZER */}
            {currentStage.visualType === 'urn' && (
              <div className="flex flex-col items-center gap-3 w-full">
                {/* Visual Urn Box */}
                <div className="w-full max-w-[220px] bg-[#1a0f07] border-2 border-amber-700/80 rounded-2xl p-3 shadow-md flex flex-col items-center">
                  <div className="text-[11px] font-serif font-bold text-amber-200 mb-2">
                    Current Urn Contents:
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-mono w-full">
                    <div className="bg-red-950/70 border border-red-500/60 p-1.5 rounded-lg text-red-200">
                      5 Rubies
                    </div>
                    <div className="bg-blue-950/70 border border-blue-500/60 p-1.5 rounded-lg text-blue-200">
                      4 Sapphires
                    </div>
                    <div className="bg-emerald-950/70 border border-emerald-500/60 p-1.5 rounded-lg text-emerald-200">
                      3 Emeralds
                    </div>
                  </div>
                </div>

                <button
                  onClick={drawRuneFromUrn}
                  className="px-4 py-1.5 bg-gradient-to-r from-amber-700 to-amber-900 hover:from-amber-600 hover:to-amber-800 border border-amber-400/70 rounded-xl text-xs font-serif font-bold text-amber-100 active:scale-95 transition"
                >
                  Draw Sample Rune
                </button>

                {drawnRunes.length > 0 && (
                  <div className="text-center text-[11px] font-mono text-emerald-300">
                    Drawn: {drawnRunes[0]}
                  </div>
                )}
              </div>
            )}

            {/* SPINNER VISUALIZER */}
            {currentStage.visualType === 'spinner' && (
              <div className="flex flex-col items-center gap-3">
                <div className="w-32 h-32 rounded-full border-4 border-amber-400/80 bg-gradient-to-tr from-amber-900 via-purple-950 to-indigo-900 shadow-xl flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-full h-0.5 bg-amber-400/60" />
                    <div className="h-full w-0.5 bg-amber-400/60" />
                  </div>
                  <div className="relative z-10 text-center bg-black/60 px-3 py-1.5 rounded-xl border border-amber-500/60">
                    <div className="text-[10px] font-mono text-amber-300">E(X) Target</div>
                    <div className="font-serif font-black text-lg text-amber-100">21 Seeds</div>
                  </div>
                </div>
                <div className="text-[11px] font-mono text-center text-amber-200/80">
                  50% × 10 + 30% × 20 + 20% × 50
                </div>
              </div>
            )}
          </div>

          {/* Right / Main: Question & Multiple Choice Options */}
          <div className="md:col-span-7 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono uppercase tracking-widest text-amber-400 mb-1">
                {currentStage.subtitle}
              </div>
              <h3 className="font-serif font-bold text-lg sm:text-xl text-[#fef9c3] leading-snug mb-3">
                {currentStage.prompt}
              </h3>

              {currentStage.mathFormula && (
                <div className="bg-[#120904] border border-amber-600/40 rounded-xl px-3 py-2 text-xs font-mono text-amber-300 mb-4 inline-block">
                  Formula: {currentStage.mathFormula}
                </div>
              )}
            </div>

            {/* Options Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 my-2">
              {currentStage.options.map((option, idx) => {
                const isSelected = selectedOption === idx;
                const isCorrect = option.correct;
                let btnStyle = 'bg-[#24150b] hover:bg-[#382112] border-[#5e3b1f] text-[#fed7aa]';

                if (isSelected) {
                  btnStyle = isCorrect
                    ? 'bg-emerald-950/90 border-emerald-400 text-emerald-100 ring-2 ring-emerald-500'
                    : 'bg-red-950/90 border-red-400 text-red-100 ring-2 ring-red-500';
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(idx)}
                    disabled={stageCleared}
                    className={`p-3 border-2 rounded-xl text-left transition-all active:scale-[0.98] shadow-md flex items-center justify-between text-xs sm:text-sm font-serif font-bold ${btnStyle}`}
                  >
                    <span>{option.label}</span>
                    {isSelected && isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 ml-2" />}
                  </button>
                );
              })}
            </div>

            {/* Advance / Next Stage Footer */}
            <div className="mt-4 flex items-center justify-between pt-2 border-t border-[#4a2e15]">
              {stageCleared ? (
                <div className="flex items-center justify-between w-full">
                  <div className="text-xs font-mono text-emerald-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Stage Cleared! Nova is impressed.</span>
                  </div>

                  {currentStageIdx < STAGES.length - 1 ? (
                    <button
                      onClick={handleNextStage}
                      className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-serif font-bold text-xs rounded-xl shadow-lg flex items-center gap-1.5 active:scale-95 transition"
                    >
                      <span>Next Stage</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        sounds.playVictoryFanfare();
                        setShowCelebration(true);
                      }}
                      className="px-5 py-2 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black font-serif font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 active:scale-95 transition"
                    >
                      <Trophy className="w-4 h-4" />
                      <span>Claim Meadow Rewards</span>
                    </button>
                  )}
                </div>
              ) : (
                <div className="text-xs font-serif text-amber-200/60 italic">
                  Select the mathematically verified probability to harmonize the meadow altar.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom Companion Footer & Back to Map */}
        <div className="flex items-center justify-between border-t border-[#4a2e15] pt-3 text-xs">
          <button
            onClick={() => {
              sounds.playClick();
              if (onBackToMap) onBackToMap();
            }}
            className="text-amber-300 hover:text-amber-100 font-serif font-bold transition flex items-center gap-1"
          >
            ← Return to World Map
          </button>

          <div className="flex items-center gap-2">
            <span className="text-purple-300 font-mono text-[11px]">Companion Sync:</span>
            <span className="text-emerald-400 font-serif font-bold">Nova Active (Lv.{player.level})</span>
          </div>
        </div>
      </div>

      {/* Nova Hint / Insight Modal */}
      <AnimatePresence>
        {showNovaModal && (
          <NovaDialogueModal
            isOpen={showNovaModal}
            onClose={() => setShowNovaModal(false)}
            onTryAgain={() => {
              setShowNovaModal(false);
              setSelectedOption(null);
            }}
            question={currentStage.prompt}
            topic="Probability & Expected Value"
            playerGrade={player.grade}
          />
        )}
      </AnimatePresence>

      {/* Final Victory Celebration Modal */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="w-full max-w-md bg-gradient-to-b from-[#2e190b] to-[#120a05] border-4 border-[#eab308] rounded-3xl p-6 shadow-2xl text-center flex flex-col items-center"
            >
              <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-amber-300 mb-3 animate-bounce">
                <Trophy className="w-8 h-8" />
              </div>

              <div className="text-xs font-mono uppercase tracking-widest text-amber-400">
                PROBABILITY MEADOW CONQUERED
              </div>
              <h2 className="font-serif font-black text-2xl sm:text-3xl text-yellow-200 mt-1 mb-2">
                Master of Outcomes!
              </h2>

              <p className="text-sm text-amber-100/90 font-serif leading-relaxed mb-4">
                You successfully mastered compound probability, non-replacement urn logic, and expected value! The mystical runes of Probability Meadow now shine in resonance.
              </p>

              {/* Rewards Box */}
              <div className="w-full bg-[#120803] border-2 border-amber-600/60 rounded-2xl p-3.5 mb-5 flex justify-around text-center font-mono">
                <div>
                  <div className="text-lg font-bold text-yellow-400">+200</div>
                  <div className="text-[10px] text-amber-200/80">XP</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-emerald-400">+6</div>
                  <div className="text-[10px] text-amber-200/80">SEEDS</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-cyan-400">+3</div>
                  <div className="text-[10px] text-amber-200/80">WATER</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-orange-400">+2</div>
                  <div className="text-[10px] text-amber-200/80">FERTILIZER</div>
                </div>
              </div>

              <div className="flex gap-2 w-full">
                <button
                  onClick={() => {
                    sounds.playClick();
                    if (onNext) onNext();
                    else if (onBackToMap) onBackToMap();
                  }}
                  className="flex-1 py-3 bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-black font-serif font-black text-sm rounded-xl shadow-lg active:scale-95 transition"
                >
                  Continue Journey
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
