import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, Sparkles, CheckCircle2, RotateCcw, FlaskConical, Trophy, Leaf } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { TerraCompanion } from './TerraCompanion';
import { TerraDialogueModal } from './TerraDialogueModal';
import { PlayerProfile, SteppingStoneItem } from '../types';
import { sounds } from '../utils/soundEffects';
import { getSteppingStonesCurriculum } from '../data/curriculumData';

interface RiverSteppingStonesProps {
  player: PlayerProfile;
  onComplete: (rewards: { xp: number; seeds: number; water: number; fertilizer: number }) => void;
  onNext?: () => void;
}

export const RiverSteppingStones: React.FC<RiverSteppingStonesProps> = ({
  player,
  onComplete,
  onNext,
}) => {
  const stones = useMemo(() => {
    return getSteppingStonesCurriculum(player.grade, player.mainSubject);
  }, [player.grade, player.mainSubject]);

  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<any | null>(null);
  const [showTerraModal, setShowTerraModal] = useState(false);
  const [isCrossed, setIsCrossed] = useState(false);
  const [fertilizerAwarded, setFertilizerAwarded] = useState(false);

  const activeStone = stones[currentStepIndex] || stones[0];

  const handleChooseAnswer = (val: any) => {
    setSelectedAnswer(val);
    const isCorrect = String(val).trim().toLowerCase() === String(activeStone.expectedAnswer).trim().toLowerCase();
    if (isCorrect) {
      sounds.playWaterSplash();
      sounds.playSuccess();
      if (currentStepIndex < stones.length - 1) {
        setCurrentStepIndex(currentStepIndex + 1);
        setSelectedAnswer(null);
      } else {
        setIsCrossed(true);
        setFertilizerAwarded(true);
        sounds.playMagicChime();
        onComplete({ xp: 140, seeds: 4, water: 2, fertilizer: 2 });
      }
    } else {
      sounds.playError();
      setShowTerraModal(true);
    }
  };

  const handleReset = () => {
    setCurrentStepIndex(0);
    setSelectedAnswer(null);
    setIsCrossed(false);
    setFertilizerAwarded(false);
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex flex-col justify-between p-3 sm:p-6 overflow-hidden select-none">
      {/* Rushing River Background */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${ASSETS.steppingStones})`,
          filter: 'brightness(0.9) contrast(1.05)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-black/50 pointer-events-none" />

      {/* Top Banner Header */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-2 bg-[#1b2615]/90 border-2 border-[#4d7c0f] px-4 sm:px-5 py-2.5 rounded-2xl shadow-xl backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#4d7c0f] text-[#ecfccb] text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider flex items-center gap-1">
              <Leaf className="w-3 h-3 text-[#bef264]" />
              <span>RIVER EXPEDITION</span>
            </span>
            <h2 className="font-serif font-black text-sm sm:text-base text-[#fef9c3] uppercase tracking-wider">
              STREAM STEPPING STONES ({player.grade} {player.mainSubject})
            </h2>
          </div>
          <p className="text-xs font-serif text-[#d9f99d] mt-0.5">
            Step {currentStepIndex + 1} of {stones.length} • Balance each natural rune to traverse the forest rapids!
          </p>
        </div>

        <button
          onClick={handleReset}
          className="p-2 bg-[#2d4a1d] hover:bg-[#365314] text-[#ecfccb] rounded-xl border border-[#65a30d] transition"
          title="Reset River Stones"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Center Stage: Stepping Stones in Rushing River */}
      <div className="relative z-10 my-4 flex-1 flex flex-col items-center justify-center max-w-4xl mx-auto w-full">
        {/* Floating Banner: DECODE -> STEP -> DISCOVER */}
        <div className="mb-6 bg-gradient-to-r from-[#203316] via-[#365314] to-[#203316] border-2 border-[#84cc16] px-6 py-2 rounded-full shadow-2xl flex items-center gap-2 text-[#fef9c3] font-serif font-black text-xs sm:text-sm tracking-widest uppercase animate-pulse">
          <span>DECODE</span>
          <span className="text-lime-300">➔</span>
          <span>STEP</span>
          <span className="text-lime-300">➔</span>
          <span>DISCOVER</span>
        </div>

        {/* Stepping Stones River Path */}
        <div className="relative w-full max-w-2xl h-56 sm:h-64 rounded-3xl bg-gradient-to-b from-[#0c2618]/80 to-[#07170e]/90 border-4 border-[#3f6212] p-4 flex items-center justify-between shadow-2xl overflow-hidden">
          {/* Blue/Emerald Water Currents graphic */}
          <div className="absolute inset-0 bg-gradient-to-r from-teal-800/30 via-emerald-600/30 to-teal-900/30 opacity-70 pointer-events-none" />

          {/* Stepping stones chain */}
          {stones.map((stone, idx) => {
            const isCurrent = idx === currentStepIndex && !isCrossed;
            const isPast = idx < currentStepIndex || isCrossed;

            return (
              <div key={stone.id} className="relative flex flex-col items-center z-10">
                {/* Explorer Character standing on current stone */}
                {isCurrent && (
                  <motion.div
                    animate={{ y: [-3, 3, -3] }}
                    transition={{ repeat: Infinity, duration: 1.8 }}
                    className="absolute -top-16 flex flex-col items-center z-20"
                  >
                    <div className="w-10 h-14 bg-[#203316] border-2 border-lime-400 rounded-xl p-1 flex items-center justify-center shadow-lg">
                      <div className="w-6 h-6 rounded-full bg-lime-300 border border-lime-600 flex items-center justify-center text-xs">
                        🌱
                      </div>
                    </div>
                    {/* Glowing footprint guidance arrow */}
                    <div className="w-0 h-0 border-x-6 border-x-transparent border-t-6 border-t-lime-400 mt-0.5" />
                  </motion.div>
                )}

                {/* Stepping Stone Disk */}
                <motion.div
                  animate={{
                    scale: isCurrent ? [1, 1.05, 1] : 1,
                  }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className={`w-20 h-20 sm:w-28 sm:h-24 rounded-full border-4 shadow-2xl flex flex-col items-center justify-center p-2 text-center transition-all ${
                    isCurrent
                      ? 'bg-gradient-to-b from-[#365314] to-[#142316] border-lime-300 shadow-[0_0_25px_rgba(163,230,53,0.85)]'
                      : isPast
                      ? 'bg-[#1b3d22] border-emerald-400 text-emerald-100 opacity-90'
                      : 'bg-[#18231a] border-stone-600 text-stone-400 opacity-70'
                  }`}
                >
                  <span className="font-serif font-black text-xs sm:text-sm text-yellow-100 tracking-wider">
                    {stone.equation}
                  </span>
                  {isPast && (
                    <span className="text-[10px] font-mono text-emerald-300 font-bold mt-0.5">
                      ✓ {stone.expectedAnswer}
                    </span>
                  )}
                </motion.div>
              </div>
            );
          })}
        </div>

        {/* Current Stone Answer Choices */}
        {!isCrossed && activeStone && (
          <div className="mt-6 flex flex-col items-center gap-3 w-full max-w-md">
            <div className="text-xs font-serif font-bold uppercase tracking-wider text-[#d9f99d]">
              Answer the stepping rune: <span className="text-yellow-300 font-black text-base">{activeStone.equation}</span>
            </div>
            <div className="grid grid-cols-3 gap-3 w-full">
              {activeStone.options.map((opt) => (
                <button
                  key={String(opt)}
                  onClick={() => handleChooseAnswer(opt)}
                  className="py-3 px-3 bg-gradient-to-b from-[#283e18] to-[#16240d] hover:from-[#365314] hover:to-[#203316] text-[#fef9c3] font-serif font-black text-base sm:text-lg tracking-wider rounded-2xl border-2 border-[#4d7c0f] shadow-lg transition active:scale-95 text-center"
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Crossed celebration & +2 Fertilizer reward popup */}
        {isCrossed && (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="mt-6 bg-[#16240f] border-2 border-lime-400 p-5 rounded-2xl shadow-2xl flex flex-col items-center text-center max-w-md"
          >
            {/* +2 Fertilizer badge */}
            <div className="mb-2 inline-flex items-center gap-1.5 bg-emerald-900/80 border border-emerald-400 px-3 py-1 rounded-full text-xs font-mono text-emerald-300 font-bold animate-bounce">
              <FlaskConical className="w-4 h-4 text-emerald-400" />
              <span>+2 Forest Fertilizer Gained!</span>
            </div>

            <h3 className="font-serif font-black text-xl text-yellow-200 uppercase tracking-wider">
              Opposite Shore Reached!
            </h3>
            <p className="text-xs font-serif text-[#d9f99d] mt-1">
              You've navigated every stepping stone in {player.grade} {player.mainSubject}!
            </p>

            {onNext && (
              <button
                onClick={() => {
                  sounds.playSuccess();
                  onNext();
                }}
                className="mt-4 py-2.5 px-6 bg-gradient-to-b from-[#65a30d] to-[#365314] hover:from-[#84cc16] hover:to-[#3f6212] text-[#fef9c3] rounded-xl text-xs font-serif font-bold uppercase tracking-wider border-2 border-lime-300 shadow-lg transition flex items-center gap-2"
              >
                <span>CONTINUE EXPEDITION</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </motion.div>
        )}
      </div>

      {/* Terra Companion */}
      <div className="relative z-10 flex items-center justify-between">
        <TerraCompanion
          size="md"
          mood={isCrossed ? 'excited' : 'speaking'}
          speechBubble={
            isCrossed
              ? 'Outstanding footing, Explorer! You traversed the forest rapids!'
              : `Terra: "Examine ${activeStone?.equation} carefully — trust your intuition!"`
          }
        />
      </div>

      {/* Terra Dialogue Modal for hints / mistakes */}
      <TerraDialogueModal
        isOpen={showTerraModal}
        onClose={() => setShowTerraModal(false)}
        problemContext={{
          question: activeStone?.equation || '',
          topic: `${player.grade} ${player.mainSubject} Stepping Stones`,
          currentInput: selectedAnswer !== null ? String(selectedAnswer) : '',
          grade: player.grade,
          subject: player.mainSubject,
        }}
        onTryAgain={() => {
          setSelectedAnswer(null);
          setShowTerraModal(false);
        }}
      />
    </div>
  );
};

