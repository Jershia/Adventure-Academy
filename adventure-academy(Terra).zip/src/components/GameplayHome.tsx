import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Compass, Backpack, BookOpen, User, ArrowRight, Sparkles, Sprout, Hammer, Trophy, TreePine } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { NovaCompanion } from './NovaCompanion';
import { PlayerProfile, Quest } from '../types';
import { sounds } from '../utils/soundEffects';
import { ChallengeRosterModal } from './ChallengeRosterModal';

interface GameplayHomeProps {
  player: PlayerProfile;
  quests: Quest[];
  onStartQuest: (questId: string) => void;
  onNavigate: (screen: string) => void;
}

export const GameplayHome: React.FC<GameplayHomeProps> = ({
  player,
  quests,
  onStartQuest,
  onNavigate,
}) => {
  const [showQuestCodex, setShowQuestCodex] = useState(false);
  const activeQuest = quests.find((q) => !q.completed) || quests[0];

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex flex-col justify-between p-3 sm:p-6 overflow-hidden select-none">
      {/* Forest Path Background matching Image 7 Screen 4 */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${ASSETS.forestPath})`,
          filter: 'brightness(0.95) contrast(1.05)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/50 pointer-events-none" />

      {/* Top Welcome Ribbon */}
      <div className="relative z-10 flex items-center justify-between">
        <div className="bg-[#24170e]/90 border-2 border-[#855325] px-4 py-2 rounded-2xl shadow-xl backdrop-blur-sm">
          <span className="text-xs font-serif text-[#fed7aa] uppercase tracking-wider block">
            Current Trail
          </span>
          <span className="font-serif font-black text-sm sm:text-base text-[#fef9c3]">
            🌲 {player.currentArea} • Whispering Pines Path
          </span>
        </div>

        {/* Quick Eco & Camp Badges */}
        <div className="flex items-center gap-2">
          {/* Living Forest: Save the Planet Button */}
          <button
            onClick={() => {
              sounds.playClick();
              onNavigate('grove');
            }}
            className="flex items-center gap-1.5 bg-[#142d1b]/90 hover:bg-[#1a3822] border-2 border-emerald-500/80 px-3 py-1.5 rounded-xl shadow-lg transition active:scale-95 text-xs font-serif font-bold text-emerald-300"
            title="Save the Planet: Living Forest Sanctuary (Real Trees)"
          >
            <TreePine className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span>{player.realTreesPlanted || 0} Real Trees</span>
          </button>

          {/* Quick Camp Level Badge */}
          <button
            onClick={() => {
              sounds.playClick();
              onNavigate('camp');
            }}
            className="flex items-center gap-2 bg-[#3a2211]/90 hover:bg-[#4a2e18] border-2 border-[#855325] px-3 py-1.5 rounded-xl shadow-lg transition active:scale-95 text-xs font-serif font-bold text-emerald-300"
          >
            <Hammer className="w-4 h-4 text-amber-400" />
            <span>Camp Lv.{player.camp.level}</span>
          </button>
        </div>
      </div>

      {/* Center Stage: Explorer walking on trail, Nova hovering, Wooden Signpost */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center my-4">
        {/* Signpost Banner Prompt: "REPAIR THE BRIDGE ?" matching Image 7 Screen 4 */}
        <motion.div
          initial={{ scale: 0.9, y: 15 }}
          animate={{ scale: 1, y: 0 }}
          className="mb-8 cursor-pointer flex flex-col items-center"
          onClick={() => {
            sounds.playClick();
            onStartQuest(activeQuest.id);
          }}
        >
          {/* Wooden Signboard */}
          <div className="bg-gradient-to-b from-[#653d1a] to-[#3a210d] border-4 border-[#8e693b] px-6 sm:px-8 py-3.5 rounded-2xl shadow-[0_15px_30px_rgba(0,0,0,0.8)] flex items-center gap-3 transform hover:scale-105 transition-all text-[#fef9c3] group">
            <Sparkles className="w-5 h-5 text-amber-400 animate-pulse" />
            <div className="text-center">
              <div className="text-[10px] font-mono uppercase tracking-widest text-[#fde047]">
                NEXT EXPEDITION OBJECTIVE
              </div>
              <div className="font-serif font-black text-lg sm:text-2xl uppercase tracking-wider group-hover:text-amber-300 transition">
                {activeQuest.title} ?
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-amber-400 group-hover:translate-x-1 transition" />
          </div>

          {/* Wooden Post Stake */}
          <div className="w-4 h-12 bg-gradient-to-r from-[#45270f] via-[#653d1a] to-[#3a210d] border-x border-[#8e693b] -mt-1 shadow-md" />
        </motion.div>

        {/* Trail Characters: Explorer & Nova */}
        <div className="flex items-center gap-8">
          {/* Walking Explorer Character */}
          <div className="flex flex-col items-center">
            <div className="w-24 h-32 sm:w-28 sm:h-36 rounded-2xl bg-[#2a1a10]/80 border-2 border-[#855325] p-2 flex flex-col items-center justify-center shadow-2xl relative">
              <svg width="68" height="68" viewBox="0 0 100 100" fill="none">
                <ellipse cx="50" cy="30" rx="32" ry="9" fill="#784d22" stroke="#452b14" strokeWidth="2" />
                <path d="M 30 30 C 30 14 70 14 70 30 Z" fill="#945f2b" stroke="#452b14" strokeWidth="2" />
                <circle cx="50" cy="44" r="14" fill="#fcd34d" />
                <circle cx="45" cy="42" r="2" fill="#451a03" />
                <circle cx="55" cy="42" r="2" fill="#451a03" />
                <path d="M 28 66 C 28 54 72 54 72 66 L 72 90 L 28 90 Z" fill="#bfa076" stroke="#5a3e22" strokeWidth="2" />
                <rect x="34" y="60" width="5" height="28" fill="#78350f" />
                <rect x="61" y="60" width="5" height="28" fill="#78350f" />
              </svg>
              <div className="text-[10px] font-serif font-bold text-[#fef08a] mt-1">
                Scholar Ash
              </div>
            </div>
          </div>

          {/* Nova Floating Companion */}
          <NovaCompanion
            size="md"
            mood="speaking"
            speechBubble="The wooden planks across the river need quadratic equations to align! Shall we go?"
          />
        </div>
      </div>

      {/* Bottom Wooden Navigation Bar matching Image 7 Screen 4: [MAP], [FOREST], [CAMP], [QUESTS], [INSIGHTS] */}
      <div className="relative z-10 w-full max-w-3xl mx-auto bg-gradient-to-b from-[#3a2211] via-[#24150a] to-[#140b05] border-4 border-[#855325] rounded-2xl p-2 sm:p-2.5 shadow-[0_20px_50px_rgba(0,0,0,0.9)]">
        <div className="grid grid-cols-5 gap-1.5 sm:gap-2">
          {/* MAP */}
          <button
            onClick={() => {
              sounds.playClick();
              onNavigate('map');
            }}
            className="py-2.5 px-1 sm:px-2 bg-[#2d1b0d] hover:bg-[#422915] text-[#fed7aa] hover:text-[#fef08a] border-2 border-[#6b421c] rounded-xl text-[11px] sm:text-xs font-serif font-bold uppercase tracking-wider flex flex-col items-center gap-1 transition active:scale-95 shadow-md"
          >
            <Compass className="w-4 sm:w-5 h-4 sm:h-5 text-amber-400" />
            <span>[ MAP ]</span>
          </button>

          {/* LIVING FOREST (SAVE THE PLANET) */}
          <button
            onClick={() => {
              sounds.playClick();
              onNavigate('grove');
            }}
            className="py-2.5 px-1 sm:px-2 bg-[#122b17] hover:bg-[#1a3d21] text-emerald-200 hover:text-emerald-100 border-2 border-emerald-500/80 rounded-xl text-[11px] sm:text-xs font-serif font-bold uppercase tracking-wider flex flex-col items-center gap-1 transition active:scale-95 shadow-md"
            title="Living Forest: Save the Planet"
          >
            <TreePine className="w-4 sm:w-5 h-4 sm:h-5 text-emerald-400" />
            <span className="truncate">[ FOREST ]</span>
          </button>

          {/* CAMP & FARM (BAG) */}
          <button
            onClick={() => {
              sounds.playClick();
              onNavigate('camp');
            }}
            className="py-2.5 px-1 sm:px-2 bg-[#2d1b0d] hover:bg-[#422915] text-[#fed7aa] hover:text-[#fef08a] border-2 border-[#6b421c] rounded-xl text-[11px] sm:text-xs font-serif font-bold uppercase tracking-wider flex flex-col items-center gap-1 transition active:scale-95 shadow-md"
          >
            <Sprout className="w-4 sm:w-5 h-4 sm:h-5 text-emerald-400" />
            <span>[ CAMP ]</span>
          </button>

          {/* QUESTS */}
          <button
            onClick={() => {
              sounds.playClick();
              setShowQuestCodex(true);
            }}
            className="py-2.5 px-1 sm:px-2 bg-[#2d1b0d] hover:bg-[#422915] text-[#fed7aa] hover:text-[#fef08a] border-2 border-[#6b421c] rounded-xl text-[11px] sm:text-xs font-serif font-bold uppercase tracking-wider flex flex-col items-center gap-1 transition active:scale-95 shadow-md"
            title="Open Academy Challenge Codex"
          >
            <BookOpen className="w-4 sm:w-5 h-4 sm:h-5 text-cyan-400" />
            <span>[ QUESTS ]</span>
          </button>

          {/* INSIGHTS / PROFILE */}
          <button
            onClick={() => {
              sounds.playClick();
              onNavigate('insights');
            }}
            className="py-2.5 px-1 sm:px-2 bg-[#2d1b0d] hover:bg-[#422915] text-[#fed7aa] hover:text-[#fef08a] border-2 border-[#6b421c] rounded-xl text-[11px] sm:text-xs font-serif font-bold uppercase tracking-wider flex flex-col items-center gap-1 transition active:scale-95 shadow-md"
          >
            <Trophy className="w-4 sm:w-5 h-4 sm:h-5 text-yellow-300" />
            <span>[ INSIGHTS ]</span>
          </button>
        </div>
      </div>

      {/* Challenge Codex Modal */}
      <ChallengeRosterModal
        isOpen={showQuestCodex}
        onClose={() => setShowQuestCodex(false)}
        player={player}
        quests={quests}
        onSelectChallenge={(questId) => {
          setShowQuestCodex(false);
          onStartQuest(questId);
        }}
      />
    </div>
  );
};
