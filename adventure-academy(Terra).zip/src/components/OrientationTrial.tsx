import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { CheckCircle, Circle, HelpCircle, ArrowRight, Sparkles, Leaf } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { TerraCompanion } from './TerraCompanion';
import { OrientationQuestion, PlayerProfile } from '../types';
import { sounds } from '../utils/soundEffects';
import { getOrientationTrial } from '../data/curriculumData';

interface OrientationTrialProps {
  player?: PlayerProfile;
  onComplete: (score: number) => void;
  onSkip?: () => void;
}

export const OrientationTrial: React.FC<OrientationTrialProps> = ({
  player,
  onComplete,
  onSkip,
}) => {
  const trialQuestions: OrientationQuestion[] = useMemo(() => {
    return getOrientationTrial(player?.grade || '6-8', player?.mainSubject || 'Math');
  }, [player?.grade, player?.mainSubject]);

  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [answers, setAnswers] = useState<{ [qId: number]: boolean }>({});

  const currentQ = trialQuestions[currentIdx] || trialQuestions[0];

  const handleSelect = (label: string) => {
    sounds.playClick();
    setSelectedOption(label);
  };

  const handleConfirm = () => {
    if (!selectedOption) return;
    const option = currentQ.options.find((o) => o.label === selectedOption);
    const isCorrect = !!option?.correct;

    if (isCorrect) {
      sounds.playSuccess();
    } else {
      sounds.playError();
    }

    const updatedAnswers = { ...answers, [currentQ.id]: isCorrect };
    setAnswers(updatedAnswers);

    if (currentIdx < trialQuestions.length - 1) {
      setCurrentIdx(currentIdx + 1);
      setSelectedOption(null);
    } else {
      const correctCount = Object.values(updatedAnswers).filter(Boolean).length;
      onComplete(correctCount);
    }
  };

  const handleNotLearned = () => {
    sounds.playClick();
    const updatedAnswers = { ...answers, [currentQ.id]: false };
    setAnswers(updatedAnswers);

    if (currentIdx < trialQuestions.length - 1) {
      setCurrentIdx(currentIdx + 1);
      setSelectedOption(null);
    } else {
      const correctCount = Object.values(updatedAnswers).filter(Boolean).length;
      onComplete(correctCount);
    }
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex flex-col justify-between p-3 sm:p-6 overflow-hidden select-none">
      {/* Background painted forest ruins */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${ASSETS.ruinsGate})`,
          filter: 'brightness(0.9) contrast(1.05)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-black/60 pointer-events-none" />

      {/* Top Banner & Progress Stones Header */}
      <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#1b2615]/90 border-2 border-[#4d7c0f] rounded-2xl px-5 py-2.5 shadow-2xl backdrop-blur-md">
        {/* Title */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-[#10200e] border border-lime-400/50 flex items-center justify-center">
            <Leaf className="w-5 h-5 text-lime-400 animate-pulse" />
          </div>
          <div>
            <h2 className="font-serif font-black text-sm sm:text-lg text-[#fef9c3] uppercase tracking-wider">
              ORIENTATION TRIAL — {player?.grade || 'Grade 6-8'} {player?.mainSubject || 'Curriculum'}
            </h2>
          </div>
        </div>

        {/* Question Counter & Status Stone Runes */}
        <div className="flex items-center gap-3">
          <span className="font-serif font-bold text-xs uppercase tracking-wider text-[#bef264]">
            QUESTION {currentIdx + 1} OF {trialQuestions.length}
          </span>
          <div className="flex items-center gap-1.5">
            {trialQuestions.map((q, idx) => {
              const isDone = idx < currentIdx;
              const isCurrent = idx === currentIdx;
              return (
                <div
                  key={q.id}
                  className={`w-7 h-7 rounded-lg flex items-center justify-center border-2 transition-all ${
                    isCurrent
                      ? 'bg-gradient-to-b from-[#65a30d] to-[#365314] border-lime-300 text-white font-bold shadow-[0_0_12px_rgba(163,230,53,0.8)] scale-110'
                      : isDone
                      ? 'bg-emerald-800/80 border-emerald-400 text-emerald-200'
                      : 'bg-[#2a1b10]/90 border-[#6b421c] text-stone-500'
                  }`}
                >
                  {isDone ? (
                    <CheckCircle className="w-4 h-4 text-emerald-300" />
                  ) : (
                    <span className="text-xs font-serif font-bold">{idx + 1}</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Altar Slate Board & Equation */}
      <div className="relative z-10 my-4 flex flex-col items-center justify-center max-w-4xl mx-auto w-full">
        {/* Ancient Stone Altar Chalkboard */}
        <motion.div
          key={currentQ.id}
          initial={{ scale: 0.96, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="relative w-full max-w-xl bg-gradient-to-b from-[#23180f] via-[#1a110a] to-[#0f0904] border-4 border-[#65a30d] rounded-3xl p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.9)] text-center text-[#f4ecd8]"
          style={{
            boxShadow: '0 25px 50px -12px rgba(0,0,0,0.9), inset 0 2px 10px rgba(163,230,53,0.15)',
          }}
        >
          {/* Leaf corner accents */}
          <div className="absolute -top-3 -left-3 w-7 h-7 border-t-4 border-l-4 border-[#a3e635] rounded-tl-lg" />
          <div className="absolute -top-3 -right-3 w-7 h-7 border-t-4 border-r-4 border-[#a3e635] rounded-tr-lg" />
          <div className="absolute -bottom-3 -left-3 w-7 h-7 border-b-4 border-l-4 border-[#a3e635] rounded-bl-lg" />
          <div className="absolute -bottom-3 -right-3 w-7 h-7 border-b-4 border-r-4 border-[#a3e635] rounded-br-lg" />

          {/* Slate Chalkboard Interior */}
          <div className="bg-[#142316] border-4 border-[#365314] rounded-2xl p-6 sm:p-8 shadow-inner relative">
            <div className="text-xs font-serif font-bold uppercase tracking-widest text-[#a7f3d0] mb-2">
              SOLVE TO HARMONIZE THE FOREST WAYSTONE:
            </div>

            {/* Equation / Prompt */}
            <div className="font-serif font-black text-2xl sm:text-3xl text-yellow-200 tracking-wider my-3 drop-shadow-md">
              {currentQ.equation}
            </div>

            <p className="text-sm sm:text-base font-serif text-[#e2e8f0] italic">
              {currentQ.question}
            </p>
          </div>
        </motion.div>

        {/* 4 Signpost Multiple-Choice Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 w-full max-w-2xl mt-6">
          {currentQ.options.map((opt) => {
            const isSelected = selectedOption === opt.label;
            return (
              <button
                key={opt.label}
                onClick={() => handleSelect(opt.label)}
                className={`relative py-3.5 px-3 rounded-2xl font-serif font-bold text-base sm:text-lg border-2 transition-all active:scale-95 flex items-center justify-center gap-2 ${
                  isSelected
                    ? 'bg-gradient-to-b from-[#65a30d] to-[#365314] text-[#fef9c3] border-lime-300 shadow-[0_0_15px_rgba(163,230,53,0.7)] scale-105'
                    : 'bg-gradient-to-b from-[#2e1c10] to-[#1e120a] hover:from-[#3e2717] hover:to-[#2b180d] text-[#fed7aa] border-[#5a3617] shadow-lg'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-sans font-black ${
                    isSelected ? 'bg-lime-300 text-black' : 'bg-[#1e1107] text-[#fed7aa]'
                  }`}
                >
                  {opt.label}
                </div>
                <span>{opt.text}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom Area: Terra Speech Bubble & Action Buttons */}
      <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-4 mt-2">
        {/* Terra Speech Bubble */}
        <div className="flex items-center gap-3 bg-[#1b2615]/90 border-2 border-[#4d7c0f] p-3 rounded-2xl shadow-xl max-w-md backdrop-blur-md">
          <TerraCompanion size="sm" mood="speaking" />
          <p className="text-xs font-serif text-[#f4ecd8] leading-relaxed">
            "NO WORRIES IF YOU'RE NOT SURE! THIS HELPS TERRA PICK THE PERFECT FOREST PATH FOR YOUR EXPEDITION."
          </p>
        </div>

        {/* Action Buttons: "I HAVEN'T LEARNED THIS YET" & "CONFIRM CHOICE ->" */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleNotLearned}
            className="py-3 px-4 bg-[#233816] hover:bg-[#2e4a1d] text-[#d9f99d] border-2 border-[#4d7c0f] rounded-xl text-xs font-serif font-bold uppercase tracking-wider transition active:scale-95 shadow-md"
          >
            "I HAVEN'T LEARNED THIS YET"
          </button>

          <button
            onClick={handleConfirm}
            disabled={!selectedOption}
            className={`py-3 px-6 rounded-xl font-serif font-black text-sm tracking-wider uppercase border-2 transition active:scale-95 flex items-center gap-2 shadow-xl ${
              selectedOption
                ? 'bg-gradient-to-b from-[#65a30d] to-[#365314] hover:from-[#84cc16] hover:to-[#3f6212] text-[#fef9c3] border-lime-300'
                : 'bg-stone-800 text-stone-500 border-stone-700 cursor-not-allowed'
            }`}
          >
            <span>CONFIRM CHOICE</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

