import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Sparkles, Lightbulb, Compass, RefreshCw, Leaf } from 'lucide-react';
import { TerraCompanion } from './TerraCompanion';
import { sounds } from '../utils/soundEffects';

export interface TerraDialogueModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  initialMessage?: string;
  problemContext?: {
    question: string;
    topic: string;
    currentInput?: string;
    grade?: string;
    subject?: string;
  };
  onTryAgain?: () => void;
  onContinue?: () => void;
  showContinueOnly?: boolean;
}

export const TerraDialogueModal: React.FC<TerraDialogueModalProps> = ({
  isOpen,
  onClose,
  title = 'TERRA • FOREST SPIRIT',
  initialMessage = "NOT QUITE — LET'S TRY A DIFFERENT APPROACH, EXPLORER.",
  problemContext,
  onTryAgain,
  onContinue,
  showContinueOnly = false,
}) => {
  const [activeMessage, setActiveMessage] = useState(initialMessage);
  const [loadingAI, setLoadingAI] = useState(false);
  const [mode, setMode] = useState<'initial' | 'hint' | 'explain'>('initial');

  if (!isOpen) return null;

  const handleGetHint = async () => {
    sounds.playClick();
    setLoadingAI(true);
    setMode('hint');
    try {
      const res = await fetch('/api/ai/hint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: problemContext?.question || 'Sanctuary problem',
          context: problemContext?.topic || 'Solving the mystery',
          currentInput: problemContext?.currentInput || '',
          grade: problemContext?.grade || 'Grade 6-8',
          subject: problemContext?.subject || 'Math',
        }),
      });
      const data = await res.json();
      if (data.hint) {
        setActiveMessage(data.hint);
        sounds.playMagicChime();
      }
    } catch (err) {
      setActiveMessage('Terra whispers: "Look closely at the clues carved into the ancient bark. Break the problem into small, gentle steps!"');
    } finally {
      setLoadingAI(false);
    }
  };

  const handleExplainDifferently = async () => {
    sounds.playClick();
    setLoadingAI(true);
    setMode('explain');
    try {
      const res = await fetch('/api/ai/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: problemContext?.question || 'Sanctuary problem',
          topic: problemContext?.topic || 'Forest Curriculum',
          grade: problemContext?.grade || 'Grade 6-8',
          subject: problemContext?.subject || 'Math',
        }),
      });
      const data = await res.json();
      if (data.explanation) {
        setActiveMessage(data.explanation);
        sounds.playMagicChime();
      }
    } catch (err) {
      setActiveMessage('Terra smiles: "Think of it like balancing stones across a rushing woodland creek: each side of the equation or statement must hold the exact same weight!"');
    } finally {
      setLoadingAI(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="relative w-full max-w-lg bg-[#1a2e1a] border-4 border-[#4d7c0f] rounded-2xl shadow-2xl p-6 text-[#f4ecd8]"
          style={{
            boxShadow: '0 0 40px rgba(0,0,0,0.85), inset 0 0 20px rgba(74,222,128,0.15)',
          }}
        >
          {/* Close corner button */}
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="absolute top-3 right-3 text-[#bef264]/70 hover:text-white p-1 rounded-full hover:bg-black/30 transition"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header Title with forest filigree */}
          <div className="text-center mb-4 border-b border-[#2d4a1d] pb-2">
            <h3 className="font-serif font-black text-xl tracking-widest text-[#fef08a] uppercase flex items-center justify-center gap-2">
              <Leaf className="w-4 h-4 text-emerald-400 animate-pulse" />
              {title}
              <Leaf className="w-4 h-4 text-emerald-400 animate-pulse" />
            </h3>
          </div>

          {/* Terra Floating Avatar & Message parchment plaque */}
          <div className="flex flex-col items-center mb-6">
            <div className="mb-3">
              <TerraCompanion
                size="md"
                mood={loadingAI ? 'thinking' : mode === 'hint' ? 'excited' : 'speaking'}
              />
            </div>

            {/* In-game parchment scroll plaque */}
            <div className="w-full bg-[#f6edd9] text-[#28180e] p-5 rounded-xl border-2 border-[#855325] shadow-inner font-serif text-base sm:text-lg leading-relaxed text-center min-h-[100px] flex items-center justify-center">
              {loadingAI ? (
                <div className="flex items-center gap-2 text-[#365314] font-sans text-sm animate-pulse">
                  <RefreshCw className="w-4 h-4 animate-spin text-[#65a30d]" />
                  Terra is tuning into forest intelligence for you...
                </div>
              ) : (
                <p className="font-semibold">{activeMessage}</p>
              )}
            </div>
          </div>

          {/* Action Buttons styled like carved cedar buttons */}
          {showContinueOnly ? (
            <div className="flex justify-center">
              <button
                onClick={() => {
                  sounds.playClick();
                  if (onContinue) onContinue();
                  onClose();
                }}
                className="w-full py-3 bg-gradient-to-b from-[#65a30d] to-[#3f6212] hover:from-[#84cc16] hover:to-[#4d7c0f] text-white font-serif font-bold text-base tracking-wider rounded-xl border-2 border-[#a3e635] shadow-lg transition active:scale-95 uppercase"
              >
                [ CONTINUE ]
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <button
                onClick={() => {
                  sounds.playClick();
                  if (onTryAgain) onTryAgain();
                  onClose();
                }}
                className="py-2.5 px-3 bg-gradient-to-b from-[#523219] to-[#361e0d] hover:from-[#6b4222] hover:to-[#452712] text-[#fde047] font-serif font-bold text-xs uppercase tracking-wider rounded-lg border-2 border-[#855325] shadow-md transition active:scale-95"
              >
                TRY AGAIN
              </button>

              <button
                onClick={handleGetHint}
                disabled={loadingAI}
                className="py-2.5 px-3 bg-gradient-to-b from-[#15803d] to-[#14532d] hover:from-[#16a34a] hover:to-[#166534] text-white font-serif font-bold text-xs uppercase tracking-wider rounded-lg border-2 border-emerald-400 shadow-md transition active:scale-95 flex items-center justify-center gap-1"
              >
                <Lightbulb className="w-3.5 h-3.5 text-yellow-300" />
                GET HINT
              </button>

              <button
                onClick={handleExplainDifferently}
                disabled={loadingAI}
                className="py-2.5 px-3 bg-gradient-to-b from-[#854d0e] to-[#713f12] hover:from-[#a16207] hover:to-[#854d0e] text-white font-serif font-bold text-xs uppercase tracking-wider rounded-lg border-2 border-amber-400 shadow-md transition active:scale-95 flex items-center justify-center gap-1"
              >
                <Compass className="w-3.5 h-3.5 text-amber-200" />
                EXPLAIN
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export const NovaDialogueModal = TerraDialogueModal;
export default TerraDialogueModal;
