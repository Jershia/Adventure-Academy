import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { Sparkles, Trophy, HelpCircle, CheckCircle2, ChevronRight, Compass, Shapes } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { NovaDialogueModal } from './NovaDialogueModal';
import { PlayerProfile } from '../types';
import { sounds } from '../utils/soundEffects';

interface GeometryCanopyChallengeProps {
  player: PlayerProfile;
  onComplete: (rewards: { xp: number; seeds: number; water: number; fertilizer: number }) => void;
  onNext?: () => void;
  onBackToMap?: () => void;
}

interface GeoStage {
  id: number;
  title: string;
  subtitle: string;
  prompt: string;
  theorem: string;
  visualType: 'parallel' | 'composite' | 'circle';
  options: { label: string; value: string; correct: boolean; explanation: string }[];
  hint: string;
}

export const GeometryCanopyChallenge: React.FC<GeometryCanopyChallengeProps> = ({
  player,
  onComplete,
  onNext,
  onBackToMap,
}) => {
  const [currentStageIdx, setCurrentStageIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [stageCleared, setStageCleared] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [showNovaModal, setShowNovaModal] = useState(false);

  const STAGES: GeoStage[] = [
    {
      id: 1,
      title: 'Stage 1: Transversal Sunbeam Alignment',
      subtitle: 'Parallel Lines & Alternate Interior Angles',
      prompt: 'Two ancient parallel stone corridors are intersected by a falling beam of dawn sunlight (transversal). If the top interior angle is measured at 68°, what is the measure of its alternate interior angle across the transversal?',
      theorem: '\\text{If } L_1 \\parallel L_2, \\text{ then alternate interior angles are congruent: } \\angle A = \\angle B',
      visualType: 'parallel',
      options: [
        {
          label: '68° (Alternate interior angles are equal)',
          value: '68',
          correct: true,
          explanation: 'Exactly right! When two parallel lines are cut by a transversal, alternate interior angles are congruent (equal)!',
        },
        {
          label: '112° (Supplementary angle)',
          value: '112',
          correct: false,
          explanation: '112° (180° - 68°) would be the consecutive interior angle or linear pair, not the alternate interior angle!',
        },
        {
          label: '90° (Right angle alignment)',
          value: '90',
          correct: false,
          explanation: 'The transversal cuts at an oblique 68° angle, not perpendicular.',
        },
        {
          label: '34° (Half angle)',
          value: '34',
          correct: false,
          explanation: 'Alternate interior angles are never halved—they maintain equal angular divergence!',
        },
      ],
      hint: 'Look for the "Z" shape formed by the parallel lines and the transversal beam. The interior opposite corners are always equal!',
    },
    {
      id: 2,
      title: 'Stage 2: Restoring the Sanctuary Mosaic',
      subtitle: 'Decomposing Composite Geometric Areas',
      prompt: 'The sacred altar floor is shaped as a composite polygon: a central rectangle of 8m × 6m attached to an emerald triangle garden with base 4m and height 6m. What is the total combined floor area?',
      theorem: '\\text{Area}_{\\text{total}} = \\text{Area}_{\\text{rect}} + \\text{Area}_{\\text{tri}} = (l \\times w) + \\left(\\frac{1}{2} b \\times h\\right)',
      visualType: 'composite',
      options: [
        {
          label: '60 m² (48 m² rectangle + 12 m² triangle)',
          value: '60',
          correct: true,
          explanation: 'Perfection! Rectangle = 8 × 6 = 48 m². Triangle = (4 × 6) / 2 = 12 m². Total = 48 + 12 = 60 square meters!',
        },
        {
          label: '72 m² (8 × 6 + 4 × 6 without halving)',
          value: '72',
          correct: false,
          explanation: 'Remember that a triangle is half a rectangle: Area = (1/2) × base × height, so 12 m², not 24 m²!',
        },
        {
          label: '54 m²',
          value: '54',
          correct: false,
          explanation: 'Close, but double-check your arithmetic: 48 + 12 = 60.',
        },
        {
          label: '48 m² (Forgot the triangular wing)',
          value: '48',
          correct: false,
          explanation: '48 m² only covers the rectangle; you must add the triangle garden area as well!',
        },
      ],
      hint: 'Calculate each section separately: Rectangle = 8 × 6 = 48. Triangle = (4 × 6) / 2 = 12. Add them together!',
    },
    {
      id: 3,
      title: 'Stage 3: The Ancient Sun Dial Arc',
      subtitle: 'Circle Sector Arc Length: L = (θ / 360°) × 2πr',
      prompt: 'A circular stone dial with radius r = 6 meters has a sundial shadow that sweeps across a central angle of θ = 60°. What is the length of the curved stone perimeter arc swept by the shadow?',
      theorem: 'L = \\frac{\\theta}{360^{\\circ}} \\times 2\\pi r = \\frac{60^{\\circ}}{360^{\\circ}} \\times 2\\pi(6)',
      visualType: 'circle',
      options: [
        {
          label: '2π meters (approx 6.28 m)',
          value: '2pi',
          correct: true,
          explanation: 'Brilliant! (60 / 360) = 1/6. Total circumference is 2π(6) = 12π. One-sixth of 12π is exactly 2π ≈ 6.28 meters!',
        },
        {
          label: '6π meters',
          value: '6pi',
          correct: false,
          explanation: '6π would be half the circumference (180°), but 60° is only one-sixth (60/360)!',
        },
        {
          label: 'π meters',
          value: 'pi',
          correct: false,
          explanation: 'Double-check the math: 12π / 6 = 2π, not π!',
        },
        {
          label: '12 meters',
          value: '12',
          correct: false,
          explanation: 'Curved circular arcs always depend on the constant π (pi)!',
        },
      ],
      hint: 'The whole circle circumference is 2πr = 12π. Since 60° is 1/6 of 360°, divide 12π by 6.',
    },
  ];

  const currentStage = STAGES[currentStageIdx];

  const handleSelectOption = (idx: number) => {
    setSelectedOption(idx);
    const opt = currentStage.options[idx];

    if (opt.correct) {
      sounds.playSuccess();
      sounds.playMagicChime();
      setStageCleared(true);

      if (currentStageIdx === STAGES.length - 1) {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#10b981', '#34d399', '#f59e0b', '#38bdf8'],
        });
        setTimeout(() => {
          setShowCelebration(true);
          onComplete({
            xp: 240,
            seeds: 6,
            water: 4,
            fertilizer: 3,
          });
        }, 1200);
      }
    } else {
      sounds.playError();
      setShowNovaModal(true);
    }
  };

  const handleNextStage = () => {
    if (currentStageIdx < STAGES.length - 1) {
      sounds.playClick();
      setCurrentStageIdx((prev) => prev + 1);
      setSelectedOption(null);
      setStageCleared(false);
    }
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex items-center justify-center p-3 sm:p-6 overflow-hidden select-none">
      {/* Background Painted Vintage Forest Canopy */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${ASSETS.forestBackground})`,
          filter: 'hue-rotate(80deg) brightness(0.85) contrast(1.1)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/45 to-black/65 pointer-events-none" />

      {/* Main Altar Board */}
      <div className="relative z-10 w-full max-w-4xl bg-gradient-to-b from-[#17261b] via-[#101b13] to-[#09110b] border-4 border-emerald-500/70 rounded-3xl p-4 sm:p-7 shadow-[0_25px_60px_rgba(0,0,0,0.9)] flex flex-col justify-between">
        {/* Header Ribbon */}
        <div className="flex flex-wrap items-center justify-between border-b-2 border-emerald-800/60 pb-3 gap-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-950/90 border border-emerald-400 flex items-center justify-center text-emerald-300 shadow-md">
              <Shapes className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="text-[11px] font-mono uppercase tracking-widest text-emerald-300">
                Geometry Canopy • Realm Challenge
              </div>
              <h2 className="font-serif font-black text-xl sm:text-2xl text-emerald-100">
                The Sacred Polygon Shrine & Area Slicer
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="bg-[#0b140d] border border-emerald-600/60 px-3 py-1.5 rounded-xl text-xs font-mono text-emerald-200">
              Stage {currentStageIdx + 1} of {STAGES.length}
            </div>
            <button
              onClick={() => {
                sounds.playClick();
                setShowNovaModal(true);
              }}
              className="p-2 bg-emerald-900/40 hover:bg-emerald-800/60 border border-emerald-500/60 rounded-xl text-emerald-200 transition"
              title="Ask Nova for a hint"
            >
              <HelpCircle className="w-5 h-5 text-emerald-400" />
            </button>
          </div>
        </div>

        {/* Challenge Stage Content */}
        <div className="my-5 grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
          {/* Left: Interactive Diagram for Stage */}
          <div className="md:col-span-5 bg-[#061009]/95 border-2 border-emerald-800/60 rounded-2xl p-4 flex flex-col items-center justify-center min-h-[270px] shadow-inner">
            <div className="text-xs font-serif font-bold text-emerald-300/80 uppercase tracking-wider mb-2">
              {currentStage.visualType === 'parallel' && 'Transversal & Parallel Beam Diagram'}
              {currentStage.visualType === 'composite' && 'Decomposed Sanctuary Floor Mosaic'}
              {currentStage.visualType === 'circle' && 'Sun Dial 60° Sector Arc'}
            </div>

            {/* STAGE 1: Parallel lines & Transversal */}
            {currentStage.visualType === 'parallel' && (
              <svg width="220" height="150" viewBox="0 0 220 150">
                {/* Parallel Line 1 */}
                <line x1="20" y1="40" x2="200" y2="40" stroke="#10b981" strokeWidth="3" />
                <text x="205" y="44" fill="#6ee7b7" fontSize="10" fontFamily="monospace">L1</text>

                {/* Parallel Line 2 */}
                <line x1="20" y1="110" x2="200" y2="110" stroke="#10b981" strokeWidth="3" />
                <text x="205" y="114" fill="#6ee7b7" fontSize="10" fontFamily="monospace">L2</text>

                {/* Transversal Line */}
                <line x1="40" y1="140" x2="180" y2="10" stroke="#f59e0b" strokeWidth="3" strokeDasharray="4 2" />

                {/* Angle 1 (Top interior right) */}
                <circle cx="147" cy="40" r="14" fill="none" stroke="#f43f5e" strokeWidth="2" strokeDasharray="2 2" />
                <text x="156" y="35" fill="#f43f5e" fontSize="11" fontWeight="bold" fontFamily="monospace">68°</text>

                {/* Angle 2 (Bottom interior left - alternate interior) */}
                <circle cx="73" cy="110" r="14" fill="none" stroke="#38bdf8" strokeWidth="2" strokeDasharray="2 2" />
                <text x="50" y="125" fill="#38bdf8" fontSize="11" fontWeight="bold" fontFamily="monospace">θ = ?</text>
              </svg>
            )}

            {/* STAGE 2: Composite Area Floor */}
            {currentStage.visualType === 'composite' && (
              <svg width="220" height="150" viewBox="0 0 220 150">
                {/* Rectangle: 80x60 */}
                <rect x="30" y="45" width="100" height="60" fill="#065f46" stroke="#34d399" strokeWidth="2" opacity="0.8" />
                <text x="80" y="80" fill="#a7f3d0" fontSize="11" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  Rect: 8m × 6m = 48m²
                </text>

                {/* Attached Triangle: base 40 (4m), height 60 (6m) */}
                <polygon points="130,45 130,105 180,105" fill="#047857" stroke="#10b981" strokeWidth="2" opacity="0.9" />
                <text x="150" y="95" fill="#fde047" fontSize="10" fontWeight="bold" fontFamily="monospace">
                  12m²
                </text>

                {/* Total label */}
                <text x="110" y="130" fill="#6ee7b7" fontSize="11" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  Total Area = 48 + 12 = 60 m²
                </text>
              </svg>
            )}

            {/* STAGE 3: Circle Sector Arc */}
            {currentStage.visualType === 'circle' && (
              <svg width="220" height="150" viewBox="0 0 220 150">
                {/* Circle Dial */}
                <circle cx="110" cy="75" r="55" fill="#062d1d" stroke="#059669" strokeWidth="2" strokeDasharray="3 3" />

                {/* Sector 60 degrees */}
                <path d="M 110 75 L 165 75 A 55 55 0 0 0 137.5 27.37 Z" fill="#10b981" fillOpacity="0.3" stroke="#34d399" strokeWidth="2" />

                {/* Radius line */}
                <line x1="110" y1="75" x2="165" y2="75" stroke="#f59e0b" strokeWidth="2" />
                <text x="135" y="90" fill="#fde047" fontSize="10" fontFamily="monospace">r = 6m</text>

                {/* Arc highlight */}
                <path d="M 165 75 A 55 55 0 0 0 137.5 27.37" fill="none" stroke="#38bdf8" strokeWidth="4" />

                {/* Angle marker */}
                <text x="118" y="65" fill="#67e8f9" fontSize="11" fontWeight="bold" fontFamily="monospace">60°</text>
              </svg>
            )}
          </div>

          {/* Right: Question & Multiple Choice */}
          <div className="md:col-span-7 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono uppercase tracking-widest text-emerald-400 mb-1">
                {currentStage.subtitle}
              </div>
              <h3 className="font-serif font-bold text-lg sm:text-xl text-emerald-50 leading-snug mb-3">
                {currentStage.prompt}
              </h3>

              <div className="bg-[#05140b] border border-emerald-600/40 rounded-xl px-3 py-2 text-xs font-mono text-emerald-300 mb-4 inline-block">
                Theorem: {currentStage.theorem}
              </div>
            </div>

            {/* Options Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 my-2">
              {currentStage.options.map((option, idx) => {
                const isSelected = selectedOption === idx;
                const isCorrect = option.correct;
                let btnStyle = 'bg-[#102016] hover:bg-[#162d1f] border-emerald-800/60 text-emerald-100';

                if (isSelected) {
                  btnStyle = isCorrect
                    ? 'bg-emerald-950/90 border-emerald-400 text-emerald-100 ring-2 ring-emerald-500'
                    : 'bg-red-950/90 border-red-400 text-red-100 ring-2 ring-red-500';
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(idx)}
                    disabled={stageCleared}
                    className={`p-3 border-2 rounded-xl text-left transition-all active:scale-[0.98] shadow-md flex items-center justify-between text-xs sm:text-sm font-serif font-bold ${btnStyle}`}
                  >
                    <span>{option.label}</span>
                    {isSelected && isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 ml-2" />}
                  </button>
                );
              })}
            </div>

            {/* Advance / Next Stage Footer */}
            <div className="mt-4 flex items-center justify-between pt-2 border-t border-emerald-900/60">
              {stageCleared ? (
                <div className="flex items-center justify-between w-full">
                  <div className="text-xs font-mono text-emerald-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Shrine Harmonized!</span>
                  </div>

                  {currentStageIdx < STAGES.length - 1 ? (
                    <button
                      onClick={handleNextStage}
                      className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-serif font-bold text-xs rounded-xl shadow-lg flex items-center gap-1.5 active:scale-95 transition"
                    >
                      <span>Next Stage</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        sounds.playVictoryFanfare();
                        setShowCelebration(true);
                      }}
                      className="px-5 py-2 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black font-serif font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 active:scale-95 transition"
                    >
                      <Trophy className="w-4 h-4" />
                      <span>Claim Geometry Rewards</span>
                    </button>
                  )}
                </div>
              ) : (
                <div className="text-xs font-serif text-emerald-200/60 italic">
                  Select the geometric theorem solution to align the stone canopy.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom Companion Footer & Back to Map */}
        <div className="flex items-center justify-between border-t border-emerald-900/60 pt-3 text-xs">
          <button
            onClick={() => {
              sounds.playClick();
              if (onBackToMap) onBackToMap();
            }}
            className="text-emerald-300 hover:text-emerald-100 font-serif font-bold transition flex items-center gap-1"
          >
            ← Return to World Map
          </button>

          <div className="flex items-center gap-2">
            <span className="text-emerald-300 font-mono text-[11px]">Canopy Alignment:</span>
            <span className="text-emerald-400 font-serif font-bold">100% Euclidean Geometry</span>
          </div>
        </div>
      </div>

      {/* Nova Hint Modal */}
      <AnimatePresence>
        {showNovaModal && (
          <NovaDialogueModal
            isOpen={showNovaModal}
            onClose={() => setShowNovaModal(false)}
            onTryAgain={() => {
              setShowNovaModal(false);
              setSelectedOption(null);
            }}
            question={currentStage.prompt}
            topic="Geometry & Polygons"
            playerGrade={player.grade}
          />
        )}
      </AnimatePresence>

      {/* Final Victory Celebration Modal */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="w-full max-w-md bg-gradient-to-b from-[#11261a] to-[#07130b] border-4 border-emerald-400 rounded-3xl p-6 shadow-2xl text-center flex flex-col items-center"
            >
              <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-300 mb-3 animate-bounce">
                <Trophy className="w-8 h-8" />
              </div>

              <div className="text-xs font-mono uppercase tracking-widest text-emerald-400">
                GEOMETRY CANOPY CLEARED
              </div>
              <h2 className="font-serif font-black text-2xl sm:text-3xl text-emerald-100 mt-1 mb-2">
                Architect of Theorems!
              </h2>

              <p className="text-sm text-emerald-100/90 font-serif leading-relaxed mb-4">
                You unified transversal alternate angles, sliced composite floor mosaics, and unlocked the circular dial arc!
              </p>

              {/* Rewards Box */}
              <div className="w-full bg-[#051108] border-2 border-emerald-600/60 rounded-2xl p-3.5 mb-5 flex justify-around text-center font-mono">
                <div>
                  <div className="text-lg font-bold text-yellow-400">+240</div>
                  <div className="text-[10px] text-emerald-200/80">XP</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-emerald-400">+6</div>
                  <div className="text-[10px] text-emerald-200/80">SEEDS</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-cyan-400">+4</div>
                  <div className="text-[10px] text-emerald-200/80">WATER</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-orange-400">+3</div>
                  <div className="text-[10px] text-emerald-200/80">FERTILIZER</div>
                </div>
              </div>

              <div className="flex gap-2 w-full">
                <button
                  onClick={() => {
                    sounds.playClick();
                    if (onNext) onNext();
                    else if (onBackToMap) onBackToMap();
                  }}
                  className="flex-1 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-serif font-black text-sm rounded-xl shadow-lg active:scale-95 transition"
                >
                  Continue Expedition
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
