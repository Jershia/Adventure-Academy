import React from 'react';
import { motion } from 'motion/react';
import { ASSETS } from '../assets/assets';

export interface TerraCompanionProps {
  mood?: 'idle' | 'speaking' | 'excited' | 'thinking';
  size?: 'sm' | 'md' | 'lg';
  speechBubble?: string;
  onClick?: () => void;
  className?: string;
  useImage?: boolean;
}

export const TerraCompanion: React.FC<TerraCompanionProps> = ({
  mood = 'idle',
  size = 'md',
  speechBubble,
  onClick,
  className = '',
  useImage = false,
}) => {
  const scale = size === 'sm' ? 0.75 : size === 'lg' ? 1.3 : 1;
  const imageDim = size === 'sm' ? 48 : size === 'lg' ? 88 : 64;

  return (
    <div
      className={`relative inline-flex flex-col items-center select-none ${
        onClick ? 'cursor-pointer' : ''
      } ${className}`}
      onClick={onClick}
    >
      {/* Speech bubble if provided */}
      {speechBubble && (
        <motion.div
          initial={{ opacity: 0, y: 10, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          className="mb-2 max-w-xs bg-[#f4ecd8] text-[#2c1d11] px-3.5 py-2.5 rounded-2xl border-2 border-[#5c7a38] shadow-xl text-xs sm:text-sm font-serif leading-relaxed relative z-20"
        >
          <div className="flex items-center gap-1.5 font-bold text-[#365314] uppercase text-[10px] tracking-wider mb-0.5">
            <span className="w-2 h-2 rounded-full bg-[#65a30d] animate-ping" />
            <span>Terra • Forest Spirit Guide</span>
          </div>
          {speechBubble}
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-0 h-0 border-x-8 border-x-transparent border-t-8 border-t-[#5c7a38]" />
        </motion.div>
      )}

      {/* Floating Animated Terra Nature Spirit */}
      <motion.div
        animate={{
          y: mood === 'speaking' ? [-4, 4, -4] : [-6, 6, -6],
          rotate: mood === 'excited' ? [-6, 6, -6] : [-2, 2, -2],
        }}
        transition={{
          repeat: Infinity,
          duration: mood === 'speaking' ? 1.3 : 2.8,
          ease: 'easeInOut',
        }}
        style={{ transform: `scale(${scale})` }}
        className="relative flex items-center justify-center filter drop-shadow-[0_0_14px_rgba(74,222,128,0.65)]"
      >
        {useImage ? (
          <div className="relative p-1 rounded-full bg-gradient-to-b from-[#84cc16] via-[#15803d] to-[#1e3a1e] shadow-2xl border-2 border-[#a3e635]/80">
            <img
              src={ASSETS.terraCompanion}
              alt="Terra Forest Spirit"
              className="rounded-full object-cover object-center shadow-inner"
              style={{ width: `${imageDim}px`, height: `${imageDim}px` }}
              referrerPolicy="no-referrer"
            />
            {/* Spore particles */}
            <motion.div
              animate={{ scale: [1, 1.4, 1], opacity: [0.6, 1, 0.6] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-[#fef08a] shadow-[0_0_8px_#fef08a] border border-[#ca8a04]"
            />
          </div>
        ) : (
          <svg
            width="78"
            height="78"
            viewBox="0 0 100 100"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              {/* Forest Leaf Wings Gradient */}
              <linearGradient id="terraLeafWing" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#a3e635" stopOpacity="0.95" />
                <stop offset="50%" stopColor="#22c55e" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#15803d" stopOpacity="0.4" />
              </linearGradient>

              {/* Terra Core Spirit Body */}
              <radialGradient id="terraBody" cx="40%" cy="40%" r="60%">
                <stop offset="0%" stopColor="#ecfdf5" />
                <stop offset="40%" stopColor="#86efac" />
                <stop offset="85%" stopColor="#15803d" />
                <stop offset="100%" stopColor="#14532d" />
              </radialGradient>

              {/* Luminous Emerald Eye Lens */}
              <radialGradient id="terraEyeGlow" cx="45%" cy="45%" r="55%">
                <stop offset="0%" stopColor="#fef08a" />
                <stop offset="35%" stopColor="#4ade80" />
                <stop offset="75%" stopColor="#16a34a" />
                <stop offset="100%" stopColor="#064e3b" />
              </radialGradient>

              {/* Amber Bark Vine */}
              <linearGradient id="terraBark" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#d97706" />
                <stop offset="100%" stopColor="#78350f" />
              </linearGradient>
            </defs>

            {/* Left Leaf Wing with delicate fluttering */}
            <motion.path
              animate={{ rotate: [-10, 10, -10] }}
              transition={{ repeat: Infinity, duration: 0.28, ease: 'easeInOut' }}
              style={{ transformOrigin: '38px 48px' }}
              d="M 38 48 C 22 32 8 16 4 24 C 0 32 18 48 38 48 Z"
              fill="url(#terraLeafWing)"
              stroke="#bef264"
              strokeWidth="1.3"
            />
            {/* Left Leaf Vein */}
            <path d="M 38 48 Q 20 32 6 23" stroke="#d9f99d" strokeWidth="0.9" opacity="0.8" />

            {/* Right Leaf Wing */}
            <motion.path
              animate={{ rotate: [10, -10, 10] }}
              transition={{ repeat: Infinity, duration: 0.28, ease: 'easeInOut' }}
              style={{ transformOrigin: '62px 48px' }}
              d="M 62 48 C 78 32 92 16 96 24 C 100 32 82 48 62 48 Z"
              fill="url(#terraLeafWing)"
              stroke="#bef264"
              strokeWidth="1.3"
            />
            {/* Right Leaf Vein */}
            <path d="M 62 48 Q 80 32 94 23" stroke="#d9f99d" strokeWidth="0.9" opacity="0.8" />

            {/* Lower Minor Leaf Fins */}
            <motion.path
              animate={{ rotate: [-6, 6, -6] }}
              transition={{ repeat: Infinity, duration: 0.35, ease: 'easeInOut' }}
              style={{ transformOrigin: '40px 56px' }}
              d="M 40 56 C 26 58 14 50 12 58 C 10 64 26 65 40 56 Z"
              fill="url(#terraLeafWing)"
              stroke="#86efac"
              strokeWidth="1"
              opacity="0.8"
            />
            <motion.path
              animate={{ rotate: [6, -6, 6] }}
              transition={{ repeat: Infinity, duration: 0.35, ease: 'easeInOut' }}
              style={{ transformOrigin: '60px 56px' }}
              d="M 60 56 C 74 58 86 50 88 58 C 90 64 74 65 60 56 Z"
              fill="url(#terraLeafWing)"
              stroke="#86efac"
              strokeWidth="1"
              opacity="0.8"
            />

            {/* Terra Sprout Antenna with Acorn Bud */}
            <path
              d="M 50 28 C 48 18 42 12 40 8 C 42 8 46 12 48 18 Z"
              fill="#84cc16"
              stroke="#4d7c0f"
              strokeWidth="1"
            />
            <path
              d="M 50 28 C 52 18 58 12 60 8 C 58 8 54 12 52 18 Z"
              fill="#84cc16"
              stroke="#4d7c0f"
              strokeWidth="1"
            />
            {/* Glowing Spore Bulb */}
            <circle cx="50" cy="14" r="3.5" fill="#fef08a" stroke="#ca8a04" strokeWidth="1">
              <animate attributeName="opacity" values="0.7;1;0.7" dur="1.8s" repeatCount="indefinite" />
            </circle>

            {/* Main Forest Elemental Sphere */}
            <circle cx="50" cy="50" r="22" fill="url(#terraBody)" stroke="#166534" strokeWidth="2.2" />

            {/* Vine Leaf Circlet Ring */}
            <ellipse cx="50" cy="50" rx="22" ry="12" fill="none" stroke="url(#terraBark)" strokeWidth="1.6" opacity="0.85" />
            <circle cx="28" cy="50" r="2" fill="#bef264" />
            <circle cx="72" cy="50" r="2" fill="#bef264" />

            {/* Luminous Woodland Spirit Face */}
            <circle cx="50" cy="50" r="14" fill="#052e16" stroke="#22c55e" strokeWidth="1.5" />
            <circle cx="50" cy="50" r="10" fill="url(#terraEyeGlow)" />

            {/* Animated Pupil */}
            <motion.circle
              animate={{
                cx: mood === 'thinking' ? [48, 52, 48] : [50, 50, 50],
                r: mood === 'excited' ? [4.5, 5.5, 4.5] : [4, 4, 4],
              }}
              transition={{ repeat: Infinity, duration: 2 }}
              cy="50"
              fill="#064e3b"
            />
            {/* Glint of Light */}
            <circle cx="47" cy="47" r="1.8" fill="#ffffff" opacity="0.9" />

            {/* Smiling Leaf Cheeks */}
            <ellipse cx="42" cy="55" rx="2" ry="1" fill="#86efac" opacity="0.7" />
            <ellipse cx="58" cy="55" rx="2" ry="1" fill="#86efac" opacity="0.7" />
          </svg>
        )}
      </motion.div>
    </div>
  );
};

// Re-export as NovaCompanion to ensure zero breaking changes across existing code
export const NovaCompanion = TerraCompanion;
export default TerraCompanion;
