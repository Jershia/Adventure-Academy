import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Brain, Compass, TrendingUp, Award, ArrowRight, Layers, CheckCircle2, Sliders } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { NovaCompanion } from './NovaCompanion';
import { PlayerProfile } from '../types';
import { sounds } from '../utils/soundEffects';

interface NovaInsightsViewProps {
  player: PlayerProfile;
  onChoosePath: (path: 'visual' | 'text') => void;
  onNavigate: (screen: string) => void;
}

export const NovaInsightsView: React.FC<NovaInsightsViewProps> = ({
  player,
  onChoosePath,
  onNavigate,
}) => {
  // Tabs representing the 5 key frames of Image 2
  const [activeTab, setActiveTab] = useState<'insight' | 'fork' | 'journeys' | 'difficulty' | 'profile'>('insight');

  const stats = player.learningStats;

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex flex-col justify-between p-3 sm:p-6 overflow-hidden select-none">
      {/* Campfire at Twilight Background matching Image 2 */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${ASSETS.campFire})`,
          filter: 'brightness(0.85) contrast(1.1)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-black/60 pointer-events-none" />

      {/* Top Tabs Ribbon for Frames 11 - 15 */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-2 bg-[#24170e]/90 border-2 border-[#855325] px-4 py-2.5 rounded-2xl shadow-xl backdrop-blur-md">
        <div className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-cyan-400" />
          <h2 className="font-serif font-black text-sm sm:text-base text-[#fef9c3] uppercase tracking-wider">
            NOVA'S ADAPTIVE LEARNING INTELLIGENCE
          </h2>
        </div>

        {/* Frame selector pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {[
            { id: 'insight', label: 'Nova Insight' },
            { id: 'fork', label: 'Adaptive Forest Fork' },
            { id: 'journeys', label: 'Learning Paths' },
            { id: 'difficulty', label: 'Dynamic Mastery' },
            { id: 'profile', label: 'Explorer Profile' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                sounds.playClick();
                setActiveTab(tab.id as any);
              }}
              className={`px-3 py-1 rounded-xl text-xs font-serif font-bold whitespace-nowrap transition ${
                activeTab === tab.id
                  ? 'bg-gradient-to-b from-[#b45309] to-[#78350f] text-[#fef9c3] border border-[#fde047] shadow-md'
                  : 'bg-[#1b1007] text-[#fed7aa] hover:bg-[#331c0d] border border-[#5a3617]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Center Dynamic Content based on Active Frame */}
      <div className="relative z-10 my-4 flex-1 flex flex-col items-center justify-center max-w-4xl mx-auto w-full">
        {/* FRAME 11: NOVA'S INSIGHT MODAL */}
        {activeTab === 'insight' && (
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-lg bg-gradient-to-b from-[#3a2211] via-[#24150a] to-[#140b05] border-4 border-[#855325] rounded-3xl p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.95)] text-[#f4ecd8]"
            style={{
              boxShadow: '0 25px 50px -12px rgba(0,0,0,0.9), inset 0 2px 10px rgba(212,175,55,0.2)',
            }}
          >
            {/* Header Plaque */}
            <div className="text-center mb-5 border-b border-[#5a3617] pb-3">
              <div className="bg-[#523318] text-[#fef9c3] font-serif font-black text-xl px-6 py-1.5 rounded-xl border-2 border-[#855325] inline-block uppercase tracking-widest shadow-md">
                NOVA'S INSIGHT
              </div>
            </div>

            {/* Visual vs Text Progress Bars matching Frame 11 */}
            <div className="space-y-4 my-6 bg-[#1a1007] p-5 rounded-2xl border-2 border-[#523318]">
              {/* Visual Speed Bar */}
              <div>
                <div className="flex items-center justify-between text-xs font-serif font-bold uppercase tracking-wider text-[#a7f3d0] mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                    VISUAL PUZZLE SPEED
                  </span>
                  <span className="font-mono text-sm">{stats.visualSpeedScore}%</span>
                </div>
                <div className="w-full h-4 bg-[#0a0502] rounded-full overflow-hidden border border-emerald-700/50">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-300 rounded-full transition-all duration-1000"
                    style={{ width: `${stats.visualSpeedScore}%` }}
                  />
                </div>
              </div>

              {/* Text Speed Bar */}
              <div>
                <div className="flex items-center justify-between text-xs font-serif font-bold uppercase tracking-wider text-[#fed7aa] mb-1.5">
                  <span>TEXT-HEAVY PROBLEM SPEED</span>
                  <span className="font-mono text-sm">{stats.textSpeedScore}%</span>
                </div>
                <div className="w-full h-4 bg-[#0a0502] rounded-full overflow-hidden border border-[#855325]/50">
                  <div
                    className="h-full bg-gradient-to-r from-amber-700 to-yellow-600 rounded-full transition-all duration-1000"
                    style={{ width: `${stats.textSpeedScore}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Inscription Quote matching Frame 11 */}
            <p className="text-center font-serif text-sm sm:text-base text-[#fef9c3] italic mb-6">
              "You solve visual problems faster than text-heavy problems."
            </p>

            {/* CONTINUE BUTTON */}
            <button
              onClick={() => {
                sounds.playClick();
                setActiveTab('fork');
              }}
              className="w-full py-3 bg-gradient-to-b from-[#b45309] to-[#78350f] hover:from-[#d97706] hover:to-[#92400e] text-[#fef9c3] font-serif font-bold text-sm tracking-wider uppercase rounded-xl border-2 border-[#d4af37] shadow-lg transition active:scale-95 flex items-center justify-center gap-2"
            >
              <span>[ CONTINUE TO ADAPTIVE FORK ]</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </motion.div>
        )}

        {/* FRAME 12: ADAPTIVE FOREST FORK */}
        {activeTab === 'fork' && (
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-2xl bg-gradient-to-b from-[#3a2211] via-[#24150a] to-[#140b05] border-4 border-[#855325] rounded-3xl p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.95)] text-[#f4ecd8] text-center"
          >
            <div className="mb-4">
              <span className="bg-amber-900 text-amber-200 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                Trail Crossroads Ahead
              </span>
              <h3 className="font-serif font-black text-2xl text-yellow-200 uppercase tracking-wider mt-1">
                ADAPTIVE FOREST FORK
              </h3>
              <p className="text-xs font-serif text-[#fed7aa] mt-1">
                Nova has analyzed your problem-solving metrics and paved tailored trails through the woodland.
              </p>
            </div>

            {/* Two Path Signposts */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-6">
              {/* Left Path: Text Challenge */}
              <div
                onClick={() => {
                  sounds.playClick();
                  onChoosePath('text');
                }}
                className="cursor-pointer bg-[#24150b] hover:bg-[#331e0f] border-2 border-[#6b421c] p-5 rounded-2xl flex flex-col items-center justify-between transition-all group"
              >
                <div className="w-12 h-12 rounded-xl bg-black/40 flex items-center justify-center text-[#fed7aa] mb-2">
                  <TrendingUp className="w-6 h-6 text-amber-400" />
                </div>
                <div className="font-serif font-black text-lg text-[#fed7aa] uppercase group-hover:text-yellow-200">
                  TEXT CHALLENGE
                </div>
                <p className="text-xs font-serif text-[#fed7aa]/70 mt-1">
                  Word formulations, symbolic deductions & equation logic.
                </p>
                <button className="mt-4 w-full py-2 bg-[#3a2211] text-[#fed7aa] rounded-xl text-xs font-serif font-bold uppercase border border-[#6b421c]">
                  Choose Text Path
                </button>
              </div>

              {/* Right Path: Visual Challenge (AI Recommended Beacon matching Frame 12) */}
              <div
                onClick={() => {
                  sounds.playSuccess();
                  onChoosePath('visual');
                }}
                className="cursor-pointer bg-gradient-to-b from-[#1b3228] to-[#12221b] border-2 border-emerald-400 p-5 rounded-2xl flex flex-col items-center justify-between shadow-[0_0_25px_rgba(52,211,153,0.4)] transition-all transform hover:scale-105 group relative overflow-hidden"
              >
                {/* AI RECOMMENDED badge matching Frame 12 */}
                <div className="absolute top-2 right-2 bg-gradient-to-r from-amber-500 to-yellow-400 text-black font-sans font-black text-[9px] px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1 shadow-md animate-pulse">
                  <Sparkles className="w-3 h-3" />
                  AI RECOMMENDED
                </div>

                <div className="w-12 h-12 rounded-xl bg-emerald-950/60 border border-emerald-400 flex items-center justify-center text-emerald-300 mb-2 mt-2">
                  <Sliders className="w-6 h-6 text-emerald-400" />
                </div>

                <div className="font-serif font-black text-lg text-emerald-200 uppercase group-hover:text-yellow-100">
                  VISUAL CHALLENGE
                </div>
                <p className="text-xs font-serif text-emerald-100/80 mt-1">
                  Interactive graphs, parabola curves, and geometric spatial simulations.
                </p>

                <button className="mt-4 w-full py-2 bg-gradient-to-b from-emerald-600 to-emerald-800 text-white rounded-xl text-xs font-serif font-bold uppercase border border-emerald-300 shadow-md">
                  Choose Visual Path (Recommended)
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* FRAME 13: DIFFERENT JOURNEYS FLOWCHART */}
        {activeTab === 'journeys' && (
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-2xl bg-gradient-to-b from-[#3a2211] via-[#24150a] to-[#140b05] border-4 border-[#855325] rounded-3xl p-6 sm:p-8 shadow-2xl text-[#f4ecd8]"
          >
            <div className="text-center mb-6">
              <h3 className="font-serif font-black text-xl text-yellow-200 uppercase tracking-wider">
                QUADRATIC EQUATIONS: DIFFERENT JOURNEYS
              </h3>
              <p className="text-xs font-serif text-[#fed7aa] mt-0.5">
                Every explorer learns uniquely. Nova branches your quest structure automatically:
              </p>
            </div>

            <div className="space-y-6">
              {/* Path A */}
              <div className="bg-[#24150b] p-4 rounded-2xl border-2 border-[#6b421c]">
                <div className="text-xs font-serif font-bold text-amber-400 uppercase tracking-widest mb-2">
                  Path A: Symbolic & Conceptual
                </div>
                <div className="flex items-center justify-between gap-2 overflow-x-auto text-xs font-serif font-bold">
                  <div className="bg-[#3a2211] px-3 py-2 rounded-xl border border-[#855325] text-stone-300">
                    [ Explanation ]
                  </div>
                  <span className="text-amber-500 font-bold">➔</span>
                  <div className="bg-[#3a2211] px-3 py-2 rounded-xl border border-[#855325] text-stone-300">
                    [ Guided Practice ]
                  </div>
                  <span className="text-amber-500 font-bold">➔</span>
                  <div className="bg-[#523318] px-3 py-2 rounded-xl border border-amber-400 text-amber-200">
                    [ Challenge ]
                  </div>
                  <span className="text-amber-500 font-bold">➔</span>
                  <div className="bg-amber-900 px-3 py-2 rounded-xl border border-yellow-300 text-yellow-200">
                    🏆 Mastery
                  </div>
                </div>
              </div>

              {/* Path B */}
              <div className="bg-[#192b23] p-4 rounded-2xl border-2 border-emerald-500/80">
                <div className="text-xs font-serif font-bold text-emerald-300 uppercase tracking-widest mb-2 flex items-center justify-between">
                  <span>Path B: Interactive Visual Simulation</span>
                  <span className="text-[10px] bg-emerald-800 text-emerald-100 px-2 py-0.5 rounded-full">ACTIVE</span>
                </div>
                <div className="flex items-center justify-between gap-2 overflow-x-auto text-xs font-serif font-bold">
                  <div className="bg-[#12221b] px-3 py-2 rounded-xl border border-emerald-400 text-emerald-200">
                    [ Visual Simulation ]
                  </div>
                  <span className="text-emerald-400 font-bold">➔</span>
                  <div className="bg-[#12221b] px-3 py-2 rounded-xl border border-emerald-400 text-emerald-200">
                    [ Practice ]
                  </div>
                  <span className="text-emerald-400 font-bold">➔</span>
                  <div className="bg-[#1f3f31] px-3 py-2 rounded-xl border border-emerald-300 text-yellow-100">
                    [ Challenge ]
                  </div>
                  <span className="text-emerald-400 font-bold">➔</span>
                  <div className="bg-amber-900 px-3 py-2 rounded-xl border border-yellow-300 text-yellow-200">
                    🏆 Mastery
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* FRAME 14: ADAPTIVE DIFFICULTY STEPS */}
        {activeTab === 'difficulty' && (
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-xl bg-gradient-to-b from-[#3a2211] via-[#24150a] to-[#140b05] border-4 border-[#855325] rounded-3xl p-6 sm:p-8 shadow-2xl text-[#f4ecd8]"
          >
            <div className="text-center mb-6">
              <h3 className="font-serif font-black text-xl text-yellow-200 uppercase tracking-wider">
                ADAPTIVE DIFFICULTY ENGINE
              </h3>
              <p className="text-xs font-serif text-[#fed7aa] mt-0.5">
                Dynamic adjustments based on real-time speed, attempts, and accuracy.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
              {/* Ascending Steps matching Frame 14 */}
              <div className="flex flex-col gap-3 w-full sm:w-1/2">
                <div className="p-3 bg-[#26170d] rounded-xl border border-stone-600 text-center font-serif text-xs uppercase text-stone-400">
                  [ CHALLENGE TIER ]
                </div>
                <div className="p-4 bg-gradient-to-r from-amber-600 to-amber-700 rounded-xl border-2 border-yellow-200 text-center font-serif font-black text-sm uppercase text-black shadow-[0_0_20px_rgba(251,191,36,0.8)] scale-105">
                  ★ [ CURRENT LEVEL ] ★
                </div>
                <div className="p-3 bg-[#26170d] rounded-xl border border-stone-600 text-center font-serif text-xs uppercase text-stone-400">
                  [ STARTER FOUNDATION ]
                </div>
              </div>

              {/* Sidebar Metrics Card matching Frame 14 */}
              <div className="w-full sm:w-1/2 bg-[#1b1007] border-2 border-[#855325] rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between text-xs font-serif">
                  <span className="text-[#fed7aa]">Accuracy</span>
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    ▲ {stats.accuracyRate}%
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs font-serif">
                  <span className="text-[#fed7aa]">Attempts Needed</span>
                  <span className="text-cyan-300 font-bold flex items-center gap-1">
                    ▼ 1.2 avg
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs font-serif">
                  <span className="text-[#fed7aa]">Hints Requested</span>
                  <span className="text-amber-300 font-bold flex items-center gap-1">
                    ▼ Low
                  </span>
                </div>
                <div className="pt-2 border-t border-[#5a3617] text-center">
                  <span className="bg-emerald-900/80 text-emerald-300 text-[10px] font-bold px-3 py-1 rounded-full uppercase border border-emerald-500">
                    DIFFICULTY ADAPTED
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* FRAME 15: CAMPFIRE LEARNING PROFILE */}
        {activeTab === 'profile' && (
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-xl bg-gradient-to-b from-[#3a2211] via-[#24150a] to-[#140b05] border-4 border-[#855325] rounded-3xl p-6 sm:p-8 shadow-2xl text-[#f4ecd8]"
          >
            {/* Wooden Bulletin Board Header matching Frame 15 */}
            <div className="text-center mb-5 border-b border-[#5a3617] pb-3">
              <div className="bg-[#523318] text-[#fef9c3] font-serif font-black text-xl px-6 py-1.5 rounded-xl border-2 border-[#855325] inline-block uppercase tracking-widest shadow-md">
                MY LEARNING PROFILE
              </div>
            </div>

            {/* Profile Tiles Grid */}
            <div className="grid grid-cols-2 gap-3 mb-6 font-serif">
              <div className="bg-[#24150b] p-3 rounded-xl border border-[#6b421c]">
                <div className="text-[10px] uppercase font-bold text-emerald-400">Strong Topics</div>
                <div className="font-bold text-sm text-[#fef9c3] mt-1">Algebra & Linear Equations</div>
              </div>

              <div className="bg-[#24150b] p-3 rounded-xl border border-[#6b421c]">
                <div className="text-[10px] uppercase font-bold text-yellow-400">Developing</div>
                <div className="font-bold text-sm text-[#fef9c3] mt-1">Graph Interpretation</div>
              </div>

              <div className="bg-[#24150b] p-3 rounded-xl border border-[#6b421c]">
                <div className="text-[10px] uppercase font-bold text-amber-400">Practice More</div>
                <div className="font-bold text-sm text-[#fef9c3] mt-1">Multi-step Equations</div>
              </div>

              <div className="bg-[#24150b] p-3 rounded-xl border border-[#6b421c]">
                <div className="text-[10px] uppercase font-bold text-cyan-400">Best Activity</div>
                <div className="font-bold text-sm text-[#fef9c3] mt-1">Visual Challenges</div>
              </div>
            </div>

            {/* Bottom Button matching Frame 15 */}
            <button
              onClick={() => {
                sounds.playSuccess();
                onNavigate('parabola');
              }}
              className="w-full py-3.5 px-4 bg-gradient-to-b from-[#854d0e] to-[#542706] hover:from-[#a16207] hover:to-[#653307] text-[#fef9c3] font-serif font-black text-sm tracking-widest uppercase rounded-2xl border-4 border-[#d4af37] shadow-xl transition flex items-center justify-center gap-2"
            >
              <Compass className="w-5 h-5 text-amber-300" />
              <span>NOVA'S NEXT ADVENTURE: VISUAL GRAPH CHALLENGE</span>
            </button>
          </motion.div>
        )}
      </div>

      {/* Bottom Nova Companion */}
      <div className="relative z-10 flex items-center justify-between">
        <NovaCompanion
          size="md"
          mood="speaking"
          speechBubble="Every puzzle you solve reshapes how our world opens up before us!"
        />
      </div>
    </div>
  );
};
