import React, { useState } from 'react';
import { Volume2, VolumeX, Settings, Compass, Sparkles, Sprout, Droplets, FlaskConical, Flame, BookOpen, Layers, TreePine, Globe2 } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { PlayerProfile } from '../types';
import { sounds } from '../utils/soundEffects';

interface NavigationHeaderProps {
  player: PlayerProfile;
  activeScreen?: string;
  currentScreen?: string;
  onNavigate?: (screen: string) => void;
  onSelectScreen?: (screen: string) => void;
  onOpenSettings?: () => void;
}

export const NavigationHeader: React.FC<NavigationHeaderProps> = ({
  player,
  activeScreen,
  currentScreen,
  onNavigate,
  onSelectScreen,
  onOpenSettings,
}) => {
  const [muted, setMuted] = useState(false);
  const [showSceneMenu, setShowSceneMenu] = useState(false);

  const current = activeScreen || currentScreen || 'hub';
  const handleNav = (screen: string) => {
    if (onNavigate) onNavigate(screen);
    else if (onSelectScreen) onSelectScreen(screen);
  };

  const toggleMute = () => {
    sounds.enabled = muted;
    setMuted(!muted);
    if (muted) sounds.playClick();
  };

  const xpPercent = Math.min(100, Math.round((player.xp / player.xpToNextLevel) * 100));

  const SCENE_PRESETS = [
    { id: 'grove', label: 'Save the Planet: Living Forest Sanctuary', category: 'Eco-Sanctuary' },
    { id: 'title', label: 'Adventure Academy Title Portal', category: 'Start Screen' },
    { id: 'login', label: 'Explorer Identification Board', category: 'Authentication' },
    { id: 'setup', label: 'Forest Explorer Expedition Setup', category: 'Character' },
    { id: 'orientation', label: 'Sanctuary Forest Orientation Trial', category: 'Assessment' },
    { id: 'map', label: 'Vintage Forest Sanctuary Map', category: 'World Map' },
    { id: 'hub', label: 'Explorer Camp & Quest Trail', category: 'Expedition Hub' },
    { id: 'bridge', label: 'Curriculum Quest: River Crossing Bridge', category: 'Curriculum Trial' },
    { id: 'parabola', label: 'Parabola Trajectory Field Lab', category: 'Algebra Lab' },
    { id: 'river', label: 'Curriculum Stepping Stones River', category: 'Stepping Stones' },
    { id: 'probability', label: 'Probability Meadow: Dice & Urns', category: 'Probability' },
    { id: 'trigonometry', label: 'Trigonometry Trail: Watchtower Beacon', category: 'Trigonometry' },
    { id: 'geometryCanopy', label: 'Geometry Canopy: Sacred Polygon Shrine', category: 'Geometry' },
    { id: 'crystals', label: 'Exponent Cavern: Crystal Resonance', category: 'Exponents' },
    { id: 'calculus', label: 'Calculus Cascade: Water Fluxions', category: 'Calculus' },
    { id: 'cipher', label: 'Matrix Cryptography Shrine: Sigil Cipher', category: 'Linear Algebra' },
    { id: 'insights', label: 'Terra Forest Intelligence & Insights', category: 'Forest Spirit' },
    { id: 'gate', label: 'Curriculum Knowledge Gate', category: 'Knowledge Gate' },
    { id: 'camp', label: 'Explorer Basecamp & Living Farm', category: 'Camp & Farm' },
    { id: 'master', label: 'The Master Summit: Elemental Altars', category: 'Master Challenge' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-[#182313]/95 backdrop-blur-md border-b-2 border-[#4d7c0f]/60 text-[#f4ecd8] px-3 sm:px-6 py-2 shadow-2xl select-none">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Left: Player Profile Pill */}
        <div className="flex items-center gap-2.5">
          {/* Avatar Ring */}
          <div
            onClick={() => handleNav('hub')}
            className="cursor-pointer relative flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-b from-[#65a30d] to-[#14532d] border-2 border-[#a3e635] shadow-inner shrink-0 overflow-hidden group"
            title="Return to Expedition Hub"
          >
            <img
              src={player.avatar || ASSETS.scholarExplorer}
              alt={player.name}
              className="w-full h-full object-cover object-top group-hover:scale-110 transition duration-300"
              referrerPolicy="no-referrer"
            />
            <span className="absolute bottom-0 right-0 bg-[#365314] text-[#fef08a] font-serif font-black text-[9px] px-1 rounded-tl border-t border-l border-[#84cc16]">
              {player.level}
            </span>
          </div>

          {/* Player info & XP Bar */}
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-serif font-bold text-sm tracking-wide truncate text-[#fef9c3]">
                {player.name}
              </span>
              <span className="text-[10px] font-serif text-[#bef264] bg-[#224818] px-1.5 py-0.2 rounded border border-[#4d7c0f]">
                {player.grade} • {player.mainSubject}
              </span>
              <div className="flex items-center gap-0.5 bg-[#451a03]/80 border border-[#b45309] px-1.5 py-0.2 rounded-full text-[10px] text-amber-300 font-mono">
                <Flame className="w-3 h-3 text-amber-500 fill-amber-500" />
                <span>{player.streakDays}d</span>
              </div>
            </div>

            {/* XP progress track */}
            <div className="flex items-center gap-1.5 text-[10px] text-[#fed7aa] font-mono">
              <div className="w-24 sm:w-32 h-2 bg-[#1c1209] rounded-full border border-[#78350f] overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 rounded-full transition-all duration-500"
                  style={{ width: `${xpPercent}%` }}
                />
              </div>
              <span>{player.xp} XP</span>
            </div>
          </div>
        </div>


        {/* Center: Inventory Resources Pills + Save The Planet Real Tree Counter */}
        <div className="hidden sm:flex items-center gap-2">
          {/* Save the Planet Real Trees Planted Badge */}
          <button
            onClick={() => {
              sounds.playClick();
              handleNav('grove');
            }}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-mono font-bold transition shadow-sm border ${
              current === 'grove'
                ? 'bg-emerald-800 text-white border-emerald-300 shadow-[0_0_15px_rgba(34,197,94,0.6)]'
                : 'bg-[#152e1b] hover:bg-[#1e4227] text-emerald-300 border-emerald-500/60'
            }`}
            title="Save the Planet: Click to open Living Forest Sanctuary & view Real Trees Planted"
          >
            <TreePine className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span>{player.realTreesPlanted || 0} Real Trees</span>
            <span className="hidden lg:inline text-[9px] text-emerald-200 bg-emerald-950 px-1.5 py-0.5 rounded-full border border-emerald-600">
              Planted
            </span>
          </button>

          {/* Seeds */}
          <div className="flex items-center gap-1.5 bg-[#2a1d13] border border-[#784d22] px-2.5 py-1 rounded-lg text-xs font-mono text-[#fdba74] shadow-sm">
            <Sprout className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-bold">{player.resources.seeds}</span>
            <span className="text-[10px] opacity-70">Seeds</span>
          </div>

          {/* Water */}
          <div className="flex items-center gap-1.5 bg-[#2a1d13] border border-[#784d22] px-2.5 py-1 rounded-lg text-xs font-mono text-cyan-300 shadow-sm">
            <Droplets className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-bold">{player.resources.water}</span>
            <span className="text-[10px] opacity-70">Water</span>
          </div>

          {/* Fertilizer */}
          <div className="flex items-center gap-1.5 bg-[#2a1d13] border border-[#784d22] px-2.5 py-1 rounded-lg text-xs font-mono text-emerald-300 shadow-sm">
            <FlaskConical className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-bold">{player.resources.fertilizer}</span>
            <span className="text-[10px] opacity-70">Fertilizer</span>
          </div>
        </div>

        {/* Right: Quick Navigation, Sound & Settings */}
        <div className="flex items-center gap-2 relative">
          {/* Quick Living Forest Shortcut */}
          <button
            onClick={() => {
              handleNav('grove');
              sounds.playClick();
            }}
            className={`p-1.5 rounded-lg border transition ${
              current === 'grove'
                ? 'bg-emerald-800 text-white border-emerald-400 shadow-[0_0_12px_rgba(34,197,94,0.5)]'
                : 'bg-[#152e1b] hover:bg-[#1e4227] text-emerald-300 border-emerald-600/60'
            }`}
            title="Save the Planet: Living Forest Sanctuary (Real Trees Planted)"
          >
            <TreePine className="w-4 h-4 text-emerald-400" />
          </button>

          {/* Quick Scene Jump Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowSceneMenu(!showSceneMenu)}
              className="flex items-center gap-1.5 bg-[#3a2517] hover:bg-[#4a301e] text-[#fef08a] border border-[#855325] px-2.5 py-1.5 rounded-lg text-xs font-serif font-bold transition shadow-md"
              title="Jump to specific screens from the uploaded design"
            >
              <Layers className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden md:inline">Screens</span>
            </button>

            {showSceneMenu && (
              <div className="absolute right-0 mt-2 w-64 bg-[#23170e] border-2 border-[#855325] rounded-xl shadow-2xl p-2 z-50 max-h-96 overflow-y-auto">
                <div className="text-[11px] font-bold text-amber-400 uppercase px-2 py-1 border-b border-[#5c3716] tracking-wider flex items-center justify-between">
                  <span>Expedition Directory</span>
                  <span className="text-[10px] text-amber-300/70 font-mono">20 Realms</span>
                </div>
                {SCENE_PRESETS.map((scene) => (
                  <button
                    key={scene.id}
                    onClick={() => {
                      handleNav(scene.id);
                      setShowSceneMenu(false);
                      sounds.playClick();
                    }}
                    className={`w-full text-left px-2 py-1.5 rounded text-xs transition flex flex-col ${
                      current === scene.id
                        ? 'bg-[#844a14] text-white font-bold'
                        : 'text-[#fed7aa] hover:bg-[#3d2413]'
                    }`}
                  >
                    <span>{scene.label}</span>
                    <span className="text-[9px] text-[#fef08a]/60 font-mono">{scene.category}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* World Map shortcut */}
          <button
            onClick={() => {
              handleNav('map');
              sounds.playClick();
            }}
            className={`p-1.5 rounded-lg border transition ${
              current === 'map'
                ? 'bg-[#844a14] text-white border-amber-400'
                : 'bg-[#2a1b10] hover:bg-[#3b2718] text-[#f4ecd8] border-[#6b421c]'
            }`}
            title="World Map"
          >
            <Compass className="w-4 h-4 text-amber-300" />
          </button>

          {/* Camp & Farm shortcut */}
          <button
            onClick={() => {
              handleNav('camp');
              sounds.playClick();
            }}
            className={`p-1.5 rounded-lg border transition ${
              current === 'camp'
                ? 'bg-[#844a14] text-white border-amber-400'
                : 'bg-[#2a1b10] hover:bg-[#3b2718] text-[#f4ecd8] border-[#6b421c]'
            }`}
            title="Camp & Farm"
          >
            <Sprout className="w-4 h-4 text-emerald-400" />
          </button>

          {/* Sound Toggle */}
          <button
            onClick={toggleMute}
            className="p-1.5 rounded-lg bg-[#2a1b10] hover:bg-[#3b2718] text-[#f4ecd8] border border-[#6b421c] transition"
            title={muted ? 'Unmute Sound FX' : 'Mute Sound FX'}
          >
            {muted ? (
              <VolumeX className="w-4 h-4 text-red-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-amber-300" />
            )}
          </button>

          {/* Settings button */}
          <button
            onClick={onOpenSettings}
            className="p-1.5 rounded-lg bg-[#2a1b10] hover:bg-[#3b2718] text-[#f4ecd8] border border-[#6b421c] transition"
            title="Game Settings"
          >
            <Settings className="w-4 h-4 text-amber-300" />
          </button>
        </div>
      </div>
    </header>
  );
};
