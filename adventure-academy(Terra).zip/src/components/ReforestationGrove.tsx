import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import {
  Globe2,
  TreePine,
  Sprout,
  Droplets,
  FlaskConical,
  Sparkles,
  Award,
  ExternalLink,
  ShieldCheck,
  Leaf,
  Plus,
  RefreshCw,
  MapPin,
  CheckCircle2,
  X,
  Share2,
  Info,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { PlayerProfile, ForestTree, PlantedTreeCertificate } from '../types';
import { sounds } from '../utils/soundEffects';
import { NovaCompanion } from './NovaCompanion';

interface ReforestationGroveProps {
  player: PlayerProfile;
  onUpdatePlayer: (updated: PlayerProfile) => void;
  onNavigate: (screen: string) => void;
}

const REAL_SPECIES_OPTIONS = [
  {
    species: 'Rhizophora mucronata',
    commonName: 'Asiatic Red Mangrove',
    region: 'Mahajanga Estuary, Madagascar',
    lat: -15.7167,
    lng: 46.3167,
    co2PerYearKg: 24,
    description: 'Stabilizes tropical coastlines against cyclone storm surges and traps blue carbon.',
    benefit: 'High coastal biodiversity and fish sanctuary.',
    icon: '🌊',
  },
  {
    species: 'Acacia senegal',
    commonName: 'Gum Acacia',
    region: 'Great Green Wall, Senegal',
    lat: 14.4974,
    lng: -14.4524,
    co2PerYearKg: 20,
    description: 'Pivotal frontline species fighting desertification across the Sahel corridor.',
    benefit: 'Restores degraded soils and enriches nitrogen.',
    icon: '🌾',
  },
  {
    species: 'Sequoiadendron giganteum',
    commonName: 'Giant Sequoia',
    region: 'Sierra Nevada, California, USA',
    lat: 36.5647,
    lng: -118.7734,
    co2PerYearKg: 35,
    description: 'The monarch of carbon sequestration, growing for over 2,000 years.',
    benefit: 'Extreme longevity and deep ecosystem habitat.',
    icon: '🌲',
  },
  {
    species: 'Adansonia digitata',
    commonName: 'African Baobab',
    region: 'Kilifi Coast, Kenya',
    lat: -3.6305,
    lng: 39.8499,
    co2PerYearKg: 22,
    description: 'The ancient "Tree of Life" capable of storing up to 100,000 liters of water.',
    benefit: 'Keystone species sustaining birds, bees, and mammals.',
    icon: '🌿',
  },
  {
    species: 'Swietenia macrophylla',
    commonName: 'Big-Leaf Mahogany',
    region: 'Madre de Dios, Peru (Amazon Basin)',
    lat: -12.5933,
    lng: -69.1891,
    co2PerYearKg: 28,
    description: 'Canopy giant that regulates rainfall and supports indigenous Amazon flora.',
    benefit: 'Rainforest canopy anchor and soil regeneration.',
    icon: '🌴',
  },
];

export const ReforestationGrove: React.FC<ReforestationGroveProps> = ({
  player,
  onUpdatePlayer,
  onNavigate,
}) => {
  const [activeTab, setActiveTab] = useState<'forest' | 'certificates' | 'ecomath'>('forest');
  const [selectedCertificate, setSelectedCertificate] = useState<PlantedTreeCertificate | null>(null);
  const [showPlantModal, setShowPlantModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [celebrationCert, setCelebrationCert] = useState<PlantedTreeCertificate | null>(null);
  const [globalTally, setGlobalTally] = useState<number>(14892);

  // Sync state
  const forestTrees = player.forestTrees?.length ? player.forestTrees : [];
  const certificates = player.plantedTreeCertificates || [];

  // Fetch latest eco status from server
  useEffect(() => {
    async function fetchEcoStatus() {
      try {
        const res = await fetch('/api/eco/status');
        if (res.ok) {
          const data = await res.json();
          if (data.globalTreesPlanted) setGlobalTally(data.globalTreesPlanted);
          if (data.forestTrees) {
            onUpdatePlayer({
              ...player,
              realTreesPlanted: data.realTreesPlanted ?? player.realTreesPlanted,
              co2OffsetKg: data.co2OffsetKg ?? player.co2OffsetKg,
              plantedTreeCertificates: data.certificates ?? player.plantedTreeCertificates,
              forestTrees: data.forestTrees,
            });
          }
        }
      } catch (e) {
        // local state fallback
      }
    }
    fetchEcoStatus();
  }, []);

  // Plant a new sapling
  const handlePlantNewTree = async (speciesKey: string) => {
    if (player.resources.seeds < 2) {
      sounds.playError();
      return;
    }

    sounds.playClick();
    setLoading(true);

    try {
      const res = await fetch('/api/eco/plant-tree', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ speciesKey }),
      });

      if (res.ok) {
        const data = await res.json();
        sounds.playSuccess();
        onUpdatePlayer({
          ...player,
          resources: data.resources,
          forestTrees: data.forestTrees,
          totalSaplingsGrown: (player.totalSaplingsGrown || 0) + 1,
        });
        setShowPlantModal(false);
      }
    } catch (e) {
      // Local fallback
      sounds.playSuccess();
      const preset = REAL_SPECIES_OPTIONS.find((s) => s.commonName === speciesKey) || REAL_SPECIES_OPTIONS[0];
      const newTree: ForestTree = {
        id: `ft-${Date.now()}`,
        species: preset.species,
        commonName: preset.commonName,
        growthPercent: 10,
        seedsInvested: 2,
        waterGiven: 0,
        fertilizerGiven: 0,
        stage: 'sprout',
        completedRealTree: false,
      };

      onUpdatePlayer({
        ...player,
        resources: {
          ...player.resources,
          seeds: Math.max(0, player.resources.seeds - 2),
        },
        forestTrees: [newTree, ...forestTrees],
        totalSaplingsGrown: (player.totalSaplingsGrown || 0) + 1,
      });
      setShowPlantModal(false);
    } finally {
      setLoading(false);
    }
  };

  // Nurture tree with water or fertilizer
  const handleNurture = async (treeId: string, itemType: 'water' | 'fertilizer') => {
    if (itemType === 'water' && player.resources.water < 1) {
      sounds.playError();
      return;
    }
    if (itemType === 'fertilizer' && player.resources.fertilizer < 1) {
      sounds.playError();
      return;
    }

    if (itemType === 'water') sounds.playWaterSplash();
    else sounds.playMagicChime();

    try {
      const res = await fetch('/api/eco/nurture', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ treeId, itemType }),
      });

      if (res.ok) {
        const data = await res.json();
        const updatedTrees = forestTrees.map((t) => (t.id === treeId ? data.tree : t));
        onUpdatePlayer({
          ...player,
          resources: data.resources,
          forestTrees: updatedTrees,
        });
      }
    } catch (e) {
      // Local fallback
      const updatedTrees = forestTrees.map((t) => {
        if (t.id === treeId) {
          const addedGrowth = itemType === 'water' ? 20 : 35;
          const newGrowth = Math.min(100, t.growthPercent + addedGrowth);
          return {
            ...t,
            growthPercent: newGrowth,
            waterGiven: t.waterGiven + (itemType === 'water' ? 1 : 0),
            fertilizerGiven: t.fertilizerGiven + (itemType === 'fertilizer' ? 1 : 0),
            stage: (newGrowth >= 100 ? 'mature' : newGrowth >= 60 ? 'canopy' : newGrowth >= 30 ? 'sapling' : 'sprout') as any,
          };
        }
        return t;
      });

      onUpdatePlayer({
        ...player,
        resources: {
          ...player.resources,
          water: itemType === 'water' ? Math.max(0, player.resources.water - 1) : player.resources.water,
          fertilizer: itemType === 'fertilizer' ? Math.max(0, player.resources.fertilizer - 1) : player.resources.fertilizer,
        },
        forestTrees: updatedTrees,
      });
    }
  };

  // Claim real tree when 100% grown!
  const handleClaimRealTree = async (treeId: string) => {
    sounds.playVictoryFanfare();
    confetti({
      particleCount: 120,
      spread: 90,
      origin: { y: 0.5 },
      colors: ['#22c55e', '#10b981', '#facc15', '#38bdf8', '#fbbf24'],
    });

    try {
      const res = await fetch('/api/eco/claim-real-tree', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ treeId }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.certificate) {
          setCelebrationCert(data.certificate);
          setGlobalTally(data.globalTreesPlanted || globalTally + 1);
          onUpdatePlayer(data.profile || {
            ...player,
            realTreesPlanted: data.realTreesPlanted,
            co2OffsetKg: data.co2OffsetKg,
            plantedTreeCertificates: [data.certificate, ...certificates],
            forestTrees: forestTrees.map((t) => (t.id === treeId ? { ...t, completedRealTree: true } : t)),
          });
        }
      }
    } catch (e) {
      // Fallback
      const tree = forestTrees.find((t) => t.id === treeId);
      const preset = REAL_SPECIES_OPTIONS.find((s) => s.commonName === tree?.commonName) || REAL_SPECIES_OPTIONS[0];

      const fallbackCert: PlantedTreeCertificate = {
        id: `ECO-EARTH-${Math.floor(10000 + Math.random() * 90000)}`,
        species: tree?.species || preset.species,
        commonName: tree?.commonName || preset.commonName,
        region: preset.region,
        coordinates: { lat: preset.lat, lng: preset.lng },
        plantedAt: Date.now(),
        co2PerYearKg: preset.co2PerYearKg,
        partner: 'Eden Reforestation & One Tree Planted Alliance',
        dedicatedTo: player.name || 'Scholar Explorer',
        certificateHash: `sha256-${Math.random().toString(36).substring(2, 10)}`,
        realWorldImpact: preset.description,
      };

      setCelebrationCert(fallbackCert);
      setGlobalTally((prev) => prev + 1);

      onUpdatePlayer({
        ...player,
        realTreesPlanted: (player.realTreesPlanted || 0) + 1,
        co2OffsetKg: (player.co2OffsetKg || 0) + preset.co2PerYearKg,
        xp: player.xp + 250,
        plantedTreeCertificates: [fallbackCert, ...certificates],
        forestTrees: forestTrees.map((t) => (t.id === treeId ? { ...t, completedRealTree: true } : t)),
      });
    }
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex flex-col justify-between p-3 sm:p-6 overflow-hidden select-none bg-[#0d160e]">
      {/* Background with lush emerald forest ambience */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage:
            'radial-gradient(circle at 50% 20%, rgba(34, 197, 94, 0.15), transparent 70%), linear-gradient(to bottom, #09120a, #112214, #081009)',
        }}
      />
      <div className="absolute inset-0 bg-[radial-gradient(#15803d_1px,transparent_1px)] [background-size:24px_24px] opacity-20 pointer-events-none" />

      {/* Top Banner: Save the Planet Mission & Global Ticker */}
      <div className="relative z-10 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3 bg-[#132817]/90 border-2 border-[#22c55e]/40 p-4 rounded-2xl shadow-2xl backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-green-800 border-2 border-emerald-300 flex items-center justify-center text-white shadow-[0_0_20px_rgba(34,197,94,0.5)]">
              <Globe2 className="w-6 h-6 animate-spin-slow" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Save The Planet Hackathon Feature
                </span>
                <span className="text-[11px] text-amber-300 font-mono flex items-center gap-1">
                  <Leaf className="w-3.5 h-3.5 text-emerald-400" />
                  Real-World Eco Impact
                </span>
              </div>
              <h1 className="font-serif font-black text-lg sm:text-2xl text-[#f0fdf4] tracking-wide">
                LIVING FOREST SANCTUARY
              </h1>
            </div>
          </div>

          {/* Impact Runes Bar */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* Real Trees Planted */}
            <div className="flex items-center gap-2 bg-[#1b3820] border border-emerald-400/60 px-3.5 py-1.5 rounded-xl shadow-lg">
              <TreePine className="w-5 h-5 text-emerald-400" />
              <div className="flex flex-col">
                <span className="text-[9px] uppercase font-mono text-emerald-200/80">Real Trees Planted</span>
                <span className="text-base sm:text-lg font-bold font-mono text-emerald-300 leading-tight">
                  {player.realTreesPlanted || 0} Trees
                </span>
              </div>
            </div>

            {/* CO2 Sequestered */}
            <div className="flex items-center gap-2 bg-[#1b3820] border border-cyan-400/50 px-3.5 py-1.5 rounded-xl shadow-lg">
              <Leaf className="w-5 h-5 text-cyan-400" />
              <div className="flex flex-col">
                <span className="text-[9px] uppercase font-mono text-cyan-200/80">CO₂ Sequestered</span>
                <span className="text-base sm:text-lg font-bold font-mono text-cyan-300 leading-tight">
                  {player.co2OffsetKg || 0} kg/yr
                </span>
              </div>
            </div>

            {/* Global Community Counter */}
            <div className="hidden md:flex items-center gap-2 bg-[#0c1a0e] border border-amber-500/50 px-3 py-1.5 rounded-xl shadow-inner">
              <Globe2 className="w-4 h-4 text-amber-400" />
              <div className="flex flex-col">
                <span className="text-[8px] uppercase font-mono text-amber-200/70">Global Student Impact</span>
                <span className="text-xs font-bold font-mono text-amber-300">
                  {globalTally.toLocaleString()} Trees Planted Worldwide
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs (Forest Nursery vs My Real Certificates vs Eco-Math Lab) */}
        <div className="flex items-center justify-between gap-2 border-b border-[#22502c] pb-2">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                sounds.playClick();
                setActiveTab('forest');
              }}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-serif font-bold uppercase tracking-wider transition flex items-center gap-2 ${
                activeTab === 'forest'
                  ? 'bg-emerald-700 text-white shadow-[0_0_15px_rgba(34,197,94,0.4)] border border-emerald-400'
                  : 'bg-[#152a1a] text-[#c7ebd0] hover:bg-[#1f3f26] border border-[#2a5434]'
              }`}
            >
              <TreePine className="w-4 h-4" />
              <span>Living Grove ({forestTrees.length})</span>
            </button>

            <button
              onClick={() => {
                sounds.playClick();
                setActiveTab('certificates');
              }}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-serif font-bold uppercase tracking-wider transition flex items-center gap-2 ${
                activeTab === 'certificates'
                  ? 'bg-emerald-700 text-white shadow-[0_0_15px_rgba(34,197,94,0.4)] border border-emerald-400'
                  : 'bg-[#152a1a] text-[#c7ebd0] hover:bg-[#1f3f26] border border-[#2a5434]'
              }`}
            >
              <Award className="w-4 h-4 text-amber-300" />
              <span>Planted Certificates ({certificates.length})</span>
            </button>

            <button
              onClick={() => {
                sounds.playClick();
                setActiveTab('ecomath');
              }}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-serif font-bold uppercase tracking-wider transition flex items-center gap-2 ${
                activeTab === 'ecomath'
                  ? 'bg-emerald-700 text-white shadow-[0_0_15px_rgba(34,197,94,0.4)] border border-emerald-400'
                  : 'bg-[#152a1a] text-[#c7ebd0] hover:bg-[#1f3f26] border border-[#2a5434]'
              }`}
            >
              <Sparkles className="w-4 h-4 text-cyan-300" />
              <span>Eco-Math Connections</span>
            </button>
          </div>

          {/* Plant new sapling trigger */}
          <button
            onClick={() => {
              sounds.playClick();
              setShowPlantModal(true);
            }}
            className="flex items-center gap-1.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-stone-950 font-serif font-black px-4 py-2 rounded-xl text-xs sm:text-sm uppercase tracking-wide shadow-xl transition active:scale-95 border border-amber-300"
          >
            <Plus className="w-4 h-4" />
            <span>Plant New Sapling (2 Seeds)</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="relative z-10 flex-1 my-4 overflow-y-auto max-h-[60vh] pr-1">
        {/* TAB 1: Forest Nursery */}
        {activeTab === 'forest' && (
          <div className="space-y-4">
            {/* Info Banner on how math powers trees */}
            <div className="bg-[#142d1b]/90 border border-emerald-500/40 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs font-serif text-[#dcfce7]">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-900/60 border border-emerald-400 flex items-center justify-center shrink-0 text-emerald-300">
                  <Sprout className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-[#fef08a] text-sm">
                    How it Works: Solve Math → Nurture Forest → Plant Real Trees on Earth!
                  </div>
                  <p className="text-[#bbf7d0] text-[11px] leading-relaxed">
                    Earn seeds, water, and fertilizer by solving quadratic factorizations, balancing linear steps, and conquering knowledge gates.
                    When your in-game sapling reaches 100% full growth, a verified partner plants a real seedling in our planet's deforested ecosystems!
                  </p>
                </div>
              </div>

              {/* Resource Pill Summary */}
              <div className="flex items-center gap-2 shrink-0 bg-[#0c1f12] px-3 py-1.5 rounded-xl border border-emerald-700">
                <span className="flex items-center gap-1 font-mono text-emerald-300 font-bold">
                  <Sprout className="w-3.5 h-3.5" /> {player.resources.seeds} Seeds
                </span>
                <span className="text-stone-600">|</span>
                <span className="flex items-center gap-1 font-mono text-cyan-300 font-bold">
                  <Droplets className="w-3.5 h-3.5" /> {player.resources.water} Water
                </span>
                <span className="text-stone-600">|</span>
                <span className="flex items-center gap-1 font-mono text-emerald-400 font-bold">
                  <FlaskConical className="w-3.5 h-3.5" /> {player.resources.fertilizer} Fert
                </span>
              </div>
            </div>

            {/* Trees Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {forestTrees.map((tree) => {
                const isComplete = tree.growthPercent >= 100;
                const isRealPlanted = tree.completedRealTree;

                return (
                  <motion.div
                    key={tree.id}
                    whileHover={{ y: -3 }}
                    className={`relative rounded-3xl p-5 border-2 flex flex-col justify-between transition-all ${
                      isRealPlanted
                        ? 'bg-gradient-to-b from-[#193a20] to-[#0f2414] border-emerald-400 shadow-[0_0_25px_rgba(34,197,94,0.3)]'
                        : isComplete
                        ? 'bg-gradient-to-b from-[#243f1f] to-[#122410] border-amber-400 shadow-[0_0_20px_rgba(251,191,36,0.4)] animate-pulse'
                        : 'bg-[#112415]/90 border-[#244f2b]'
                    }`}
                  >
                    {/* Top tree header */}
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="text-[10px] font-mono text-emerald-300/80 uppercase font-bold tracking-wider">
                            {tree.species}
                          </span>
                          <h3 className="font-serif font-bold text-lg text-[#f0fdf4] leading-snug">
                            {tree.commonName}
                          </h3>
                        </div>

                        {/* Stage Badge */}
                        <div
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider border ${
                            isRealPlanted
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400'
                              : isComplete
                              ? 'bg-amber-500/20 text-amber-300 border-amber-400'
                              : 'bg-stone-800/80 text-stone-300 border-stone-600'
                          }`}
                        >
                          {isRealPlanted ? 'Planted on Earth' : isComplete ? 'Ready to Plant!' : tree.stage}
                        </div>
                      </div>

                      {/* Visual Tree Growth Graphic */}
                      <div className="my-5 flex flex-col items-center justify-center relative min-h-[110px]">
                        {/* Environmental aura */}
                        <div
                          className={`w-24 h-24 rounded-full absolute transition-all duration-700 ${
                            isRealPlanted
                              ? 'bg-emerald-500/20 blur-xl scale-125'
                              : isComplete
                              ? 'bg-amber-500/20 blur-xl scale-110'
                              : 'bg-green-500/10 blur-lg'
                          }`}
                        />

                        {/* Animated Tree Icon according to growth */}
                        <div className="relative z-10 transition-transform duration-500">
                          {tree.growthPercent >= 100 ? (
                            <div className="relative flex flex-col items-center">
                              <TreePine className="w-16 h-16 text-emerald-400 drop-shadow-[0_0_12px_rgba(34,197,94,0.8)]" />
                              <Sparkles className="w-5 h-5 text-amber-300 absolute -top-2 -right-2 animate-spin-slow" />
                            </div>
                          ) : tree.growthPercent >= 60 ? (
                            <TreePine className="w-13 h-13 text-green-500 drop-shadow-md" />
                          ) : tree.growthPercent >= 30 ? (
                            <Sprout className="w-11 h-11 text-emerald-400 drop-shadow-md" />
                          ) : (
                            <Sprout className="w-8 h-8 text-emerald-300/80" />
                          )}
                        </div>

                        {/* Stage subtext */}
                        <span className="text-[11px] font-serif text-[#dcfce7]/70 mt-2">
                          {tree.growthPercent >= 100
                            ? 'Mature Sacred Tree (Ecosystem Pillar)'
                            : tree.growthPercent >= 60
                            ? 'Lush Canopy Formed'
                            : tree.growthPercent >= 30
                            ? 'Healthy Branching Sapling'
                            : 'Tender Sprout Germinating'}
                        </span>
                      </div>

                      {/* Growth Bar */}
                      <div className="space-y-1.5 mb-4">
                        <div className="flex justify-between items-center text-[10px] font-mono">
                          <span className="text-emerald-200/80 uppercase">Growth Progress</span>
                          <span className="font-bold text-emerald-300">{tree.growthPercent}%</span>
                        </div>
                        <div className="w-full h-2.5 bg-[#0a170c] rounded-full border border-[#214a28] overflow-hidden">
                          <motion.div
                            className={`h-full rounded-full transition-all duration-500 ${
                              isRealPlanted
                                ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                                : isComplete
                                ? 'bg-gradient-to-r from-amber-400 to-emerald-400'
                                : 'bg-gradient-to-r from-emerald-600 to-green-400'
                            }`}
                            initial={{ width: 0 }}
                            animate={{ width: `${tree.growthPercent}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Action Panel */}
                    <div className="pt-3 border-t border-[#1d4523]">
                      {isRealPlanted ? (
                        <button
                          onClick={() => {
                            sounds.playClick();
                            const cert = certificates.find((c) => c.id === tree.certificateId);
                            if (cert) setSelectedCertificate(cert);
                            else {
                              // fallback
                              const fallback = certificates[0] || null;
                              setSelectedCertificate(fallback);
                            }
                          }}
                          className="w-full py-2 bg-emerald-800/80 hover:bg-emerald-700 text-emerald-100 rounded-xl text-xs font-serif font-bold uppercase tracking-wider border border-emerald-400/80 transition flex items-center justify-center gap-1.5 shadow-md"
                        >
                          <Award className="w-4 h-4 text-amber-300" />
                          <span>View Official Certificate</span>
                        </button>
                      ) : isComplete ? (
                        <button
                          onClick={() => handleClaimRealTree(tree.id)}
                          className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-emerald-500 hover:from-amber-400 hover:to-emerald-400 text-stone-950 rounded-xl text-xs font-serif font-black uppercase tracking-wider border border-amber-200 shadow-xl transition flex items-center justify-center gap-2 active:scale-95 animate-bounce"
                        >
                          <Globe2 className="w-4 h-4" />
                          <span>PLANT REAL TREE ON EARTH!</span>
                        </button>
                      ) : (
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            disabled={player.resources.water < 1}
                            onClick={() => handleNurture(tree.id, 'water')}
                            className="py-2 px-2.5 bg-[#0e3019] hover:bg-[#164726] text-cyan-200 rounded-xl text-xs font-serif font-bold uppercase transition flex items-center justify-center gap-1 border border-cyan-500/40 disabled:opacity-40"
                            title="Water with +20% growth"
                          >
                            <Droplets className="w-3.5 h-3.5 text-cyan-400" />
                            <span>Water (-1)</span>
                          </button>

                          <button
                            disabled={player.resources.fertilizer < 1}
                            onClick={() => handleNurture(tree.id, 'fertilizer')}
                            className="py-2 px-2.5 bg-[#173a1e] hover:bg-[#20522b] text-emerald-200 rounded-xl text-xs font-serif font-bold uppercase transition flex items-center justify-center gap-1 border border-emerald-500/40 disabled:opacity-40"
                            title="Fertilize with +35% growth"
                          >
                            <FlaskConical className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Fertilize (-1)</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: Planted Tree Certificates Gallery */}
        {activeTab === 'certificates' && (
          <div className="space-y-4">
            <div className="bg-[#142d1b]/90 border border-emerald-500/40 rounded-2xl p-4 text-xs font-serif text-[#dcfce7] flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-[#fef08a]">
                  Official Earth Restoration Certificates ({certificates.length})
                </h3>
                <p className="text-[11px] text-[#bbf7d0]">
                  Every certificate represents an actual, verified seedling planted in reforestation projects funded through student academy achievements.
                </p>
              </div>
              <div className="text-right">
                <span className="text-[10px] uppercase font-mono text-emerald-300">Lifetime Carbon Offset</span>
                <div className="text-lg font-bold font-mono text-emerald-400">
                  {certificates.reduce((acc, c) => acc + c.co2PerYearKg, 0)} kg CO₂ / yr
                </div>
              </div>
            </div>

            {certificates.length === 0 ? (
              <div className="text-center py-12 bg-[#122315]/80 rounded-3xl border border-[#234b2a] p-6">
                <TreePine className="w-12 h-12 text-emerald-600 mx-auto mb-3" />
                <h4 className="font-serif font-bold text-base text-[#fef9c3]">No Real Trees Planted Yet</h4>
                <p className="text-xs text-[#a7d8b2] max-w-md mx-auto mt-1 mb-4">
                  Nurture your saplings in the living grove to 100% full maturity by solving math challenges to receive your first official Earth Restoration Certificate!
                </p>
                <button
                  onClick={() => setActiveTab('forest')}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-xs font-serif font-bold uppercase tracking-wider"
                >
                  Return to Living Grove
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {certificates.map((cert) => (
                  <div
                    key={cert.id}
                    onClick={() => {
                      sounds.playClick();
                      setSelectedCertificate(cert);
                    }}
                    className="cursor-pointer bg-[#142b1a] hover:bg-[#1a3822] border-2 border-emerald-500/50 rounded-2xl p-4 transition-all shadow-xl hover:border-amber-400"
                  >
                    <div className="flex items-start justify-between gap-2 border-b border-[#234c2a] pb-2 mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-emerald-900 border border-emerald-400 flex items-center justify-center text-amber-300">
                          <Award className="w-4 h-4" />
                        </div>
                        <div>
                          <span className="text-[10px] font-mono text-amber-300 font-bold">{cert.id}</span>
                          <h4 className="font-serif font-bold text-sm text-[#f0fdf4]">{cert.commonName}</h4>
                        </div>
                      </div>
                      <span className="text-[9px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-700 px-2 py-0.5 rounded-full">
                        Verified & Planted
                      </span>
                    </div>

                    <div className="space-y-1 text-xs text-[#c7ebd0]">
                      <div className="flex items-center gap-1.5 text-[11px]">
                        <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>{cert.region}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-[11px] text-cyan-300">
                        <Globe2 className="w-3.5 h-3.5 shrink-0" />
                        <span>GPS: {cert.coordinates.lat.toFixed(4)}°, {cert.coordinates.lng.toFixed(4)}°</span>
                      </div>
                      <div className="text-[10px] text-stone-400 font-mono mt-2 pt-2 border-t border-[#204526] flex justify-between">
                        <span>Partner: {cert.partner}</span>
                        <span className="text-emerald-300">+{cert.co2PerYearKg} kg CO₂/yr</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: Eco-Math Connections */}
        {activeTab === 'ecomath' && (
          <div className="space-y-4">
            <div className="bg-[#142d1b]/90 border border-emerald-500/40 rounded-2xl p-4 text-xs font-serif text-[#dcfce7]">
              <h3 className="font-bold text-sm text-[#fef08a] mb-1">
                How Mathematics Directly Saves Deforested Earth
              </h3>
              <p className="text-[11px] text-[#bbf7d0]">
                Ecologists and environmental scientists use the exact mathematical concepts you master in Adventure Academy to calculate canopy density, carbon capture, and biodiversity recovery.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Card 1: Quadratic Canopy Models */}
              <div className="bg-[#122415] border border-emerald-600/50 rounded-2xl p-4 space-y-2">
                <div className="flex items-center gap-2 text-amber-300 font-serif font-bold text-sm">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <span>Quadratic Canopy Arc</span>
                </div>
                <div className="bg-[#0b170d] p-3 rounded-xl border border-emerald-800 font-mono text-center text-xs text-emerald-300">
                  y = -a(x - h)² + k
                </div>
                <p className="text-[11px] text-[#bbf7d0] leading-relaxed">
                  Forest canopies form parabolic crowns. The coefficient <em>a</em> governs how sunlight penetrates to the forest floor, dictating how many understory ferns and seedlings can survive.
                </p>
              </div>

              {/* Card 2: Carbon Sequestration Formulas */}
              <div className="bg-[#122415] border border-cyan-600/50 rounded-2xl p-4 space-y-2">
                <div className="flex items-center gap-2 text-cyan-300 font-serif font-bold text-sm">
                  <Leaf className="w-4 h-4 text-cyan-400" />
                  <span>Carbon Capture Biomass</span>
                </div>
                <div className="bg-[#0b170d] p-3 rounded-xl border border-cyan-800 font-mono text-center text-xs text-cyan-300">
                  C = 0.50 × (π r² h × ρ)
                </div>
                <p className="text-[11px] text-[#bbf7d0] leading-relaxed">
                  Trunk circumference and cylindrical tree volume determine exact woody biomass. 50% of tree dry mass is pure sequestered atmospheric carbon dioxide!
                </p>
              </div>

              {/* Card 3: Stepping Stone Linear Growth */}
              <div className="bg-[#122415] border border-emerald-600/50 rounded-2xl p-4 space-y-2">
                <div className="flex items-center gap-2 text-emerald-300 font-serif font-bold text-sm">
                  <TreePine className="w-4 h-4 text-emerald-400" />
                  <span>Growth Velocity</span>
                </div>
                <div className="bg-[#0b170d] p-3 rounded-xl border border-emerald-800 font-mono text-center text-xs text-emerald-300">
                  H(t) = m · t + H₀
                </div>
                <p className="text-[11px] text-[#bbf7d0] leading-relaxed">
                  Mangrove roots grow at balanced linear rates to fight coastal erosion. Linear balance equations calculate when a young forest will withstand oceanic storm surges.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Nova Companion */}
      <div className="relative z-10 flex items-center justify-between pt-2">
        <NovaCompanion
          size="md"
          mood="celebrating"
          speechBubble="Every factoring problem you crack and every equation you balance nourishes real roots on Earth! We're not just doing math—we're regenerating the planet!"
        />

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('hub')}
            className="px-4 py-2 bg-[#203623] hover:bg-[#2b492f] text-emerald-200 border border-emerald-600/60 rounded-xl text-xs font-serif font-bold uppercase transition flex items-center gap-1.5"
          >
            <span>Back to Hub</span>
          </button>
          <button
            onClick={() => onNavigate('bridge')}
            className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-stone-950 font-serif font-black rounded-xl text-xs uppercase tracking-wider transition flex items-center gap-1.5 shadow-lg active:scale-95"
          >
            <span>Solve Math for Seeds</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* MODAL 1: Plant a New Tree Selector */}
      {showPlantModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-[#132817] border-2 border-emerald-400 rounded-3xl p-6 max-w-xl w-full shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between border-b border-[#244f2b] pb-3">
              <div className="flex items-center gap-2.5">
                <Sprout className="w-6 h-6 text-emerald-400" />
                <h3 className="font-serif font-black text-lg text-[#f0fdf4]">
                  CHOOSE A REAL SPECIES TO NURTURE
                </h3>
              </div>
              <button
                onClick={() => setShowPlantModal(false)}
                className="p-1 text-stone-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-[#bbf7d0] font-serif">
              Select an endangered or keystone tree species to plant in your Living Grove. Once nurtured to 100% full growth, a real seedling will be planted in that exact region!
            </p>

            <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
              {REAL_SPECIES_OPTIONS.map((spec) => (
                <div
                  key={spec.species}
                  onClick={() => handlePlantNewTree(spec.commonName)}
                  className="cursor-pointer bg-[#0e1f12] hover:bg-[#193a20] border border-emerald-600/50 hover:border-amber-400 rounded-2xl p-3.5 transition-all flex items-center justify-between gap-3 group"
                >
                  <div className="flex items-start gap-3">
                    <span className="text-2xl shrink-0 p-1 bg-emerald-950 rounded-xl border border-emerald-800">
                      {spec.icon}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-serif font-bold text-sm text-[#f0fdf4] group-hover:text-amber-300">
                          {spec.commonName}
                        </h4>
                        <span className="text-[10px] font-mono text-emerald-400">
                          +{spec.co2PerYearKg} kg CO₂/yr
                        </span>
                      </div>
                      <div className="text-[11px] text-[#a7d8b2] flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 text-emerald-400" />
                        <span>{spec.region}</span>
                      </div>
                      <p className="text-[10px] text-stone-300 mt-1 leading-snug">
                        {spec.benefit}
                      </p>
                    </div>
                  </div>

                  <button
                    disabled={player.resources.seeds < 2 || loading}
                    className="shrink-0 px-3 py-1.5 bg-emerald-700 group-hover:bg-emerald-600 text-white rounded-xl text-xs font-serif font-bold uppercase transition shadow-md disabled:opacity-40"
                  >
                    Plant (-2 Seeds)
                  </button>
                </div>
              ))}
            </div>

            <div className="pt-2 flex justify-between items-center text-xs font-mono text-emerald-300 border-t border-[#244f2b]">
              <span>Your Seeds: {player.resources.seeds}</span>
              <button
                onClick={() => setShowPlantModal(false)}
                className="text-stone-400 hover:text-white"
              >
                Cancel
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* MODAL 2: Celebration / Certificate View */}
      {(selectedCertificate || celebrationCert) && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <motion.div
            initial={{ scale: 0.85, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative bg-gradient-to-b from-[#21160d] via-[#1b120a] to-[#120a05] border-4 border-[#d4af37] rounded-3xl p-6 sm:p-8 max-w-2xl w-full shadow-[0_0_50px_rgba(212,175,55,0.4)] text-[#fef9c3] space-y-6"
          >
            {/* Top Close */}
            <button
              onClick={() => {
                setSelectedCertificate(null);
                setCelebrationCert(null);
              }}
              className="absolute top-4 right-4 p-1 text-[#d4af37] hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Certificate Header Banner */}
            <div className="text-center space-y-1 border-b-2 border-[#855325] pb-4">
              <div className="inline-flex items-center gap-2 bg-[#451a03] border border-[#d4af37] px-3 py-1 rounded-full text-xs font-mono text-amber-300 uppercase tracking-widest">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Verified Earth Reforestation Impact</span>
              </div>
              <h2 className="font-serif font-black text-2xl sm:text-3xl text-[#fef08a] tracking-wide uppercase pt-2">
                CERTIFICATE OF REFORESTATION
              </h2>
              <p className="text-xs font-serif text-[#fed7aa] italic">
                In honor of mathematical dedication in Adventure Academy: Learn. Adapt. Grow.
              </p>
            </div>

            {/* Certificate Body Details */}
            {(() => {
              const c = celebrationCert || selectedCertificate!;
              return (
                <div className="space-y-4 font-serif text-sm bg-[#160d07] p-5 rounded-2xl border border-[#6d411b]">
                  <div className="text-center">
                    <span className="text-xs font-mono uppercase text-[#fed7aa]/70">This certifies that</span>
                    <div className="text-xl sm:text-2xl font-black text-[#fef08a] tracking-wider my-1">
                      {c.dedicatedTo}
                    </div>
                    <p className="text-xs text-[#fef9c3]">
                      has solved mathematical equations and fostered a mature tree in the Academy, funding the real planting of:
                    </p>
                  </div>

                  <div className="my-3 p-4 bg-[#23140a] rounded-xl border border-amber-600/50 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
                    <div>
                      <div className="text-xs font-mono text-emerald-400 uppercase font-bold">{c.species}</div>
                      <div className="text-lg font-bold text-[#fef08a]">{c.commonName}</div>
                      <div className="text-xs text-[#fed7aa] flex items-center justify-center sm:justify-start gap-1 mt-0.5">
                        <MapPin className="w-3.5 h-3.5 text-amber-400" />
                        <span>{c.region}</span>
                      </div>
                    </div>

                    <div className="bg-[#120a05] px-4 py-2 rounded-xl border border-emerald-600 text-center">
                      <span className="text-[10px] uppercase font-mono text-emerald-300">Est. Carbon Capture</span>
                      <div className="text-base font-mono font-bold text-emerald-400">
                        +{c.co2PerYearKg} kg CO₂/year
                      </div>
                    </div>
                  </div>

                  {/* Coordinates and Partner Guarantee */}
                  <div className="grid grid-cols-2 gap-3 text-xs font-mono border-t border-[#4a2b10] pt-3 text-[#fed7aa]">
                    <div>
                      <span className="text-[10px] text-stone-400 uppercase">GPS Planting Site</span>
                      <div className="text-amber-300 font-bold">
                        Lat {c.coordinates.lat.toFixed(4)}°, Lng {c.coordinates.lng.toFixed(4)}°
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-stone-400 uppercase">Reforestation Alliance</span>
                      <div className="text-emerald-300 font-bold truncate">{c.partner}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[10px] font-mono text-stone-400 pt-2 border-t border-[#3b200b]">
                    <span>CERTIFICATE ID: {c.id}</span>
                    <span>TIMESTAMP: {new Date(c.plantedAt).toLocaleDateString()}</span>
                  </div>
                </div>
              );
            })()}

            {/* Certificate Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-1.5 text-xs text-emerald-300 font-mono">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Recorded in Global Earth Restoration Registry</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    sounds.playSuccess();
                    alert('Certificate verified! You can screenshot or present this proof of real-world ecological contribution.');
                  }}
                  className="px-4 py-2 bg-[#2d1b0e] hover:bg-[#3f2715] text-[#fef9c3] rounded-xl text-xs font-serif font-bold uppercase transition border border-[#855325]"
                >
                  Share / Save
                </button>
                <button
                  onClick={() => {
                    setSelectedCertificate(null);
                    setCelebrationCert(null);
                  }}
                  className="px-5 py-2 bg-gradient-to-r from-amber-500 to-amber-700 hover:from-amber-400 hover:to-amber-600 text-black font-serif font-black rounded-xl text-xs uppercase tracking-wider transition shadow-lg"
                >
                  Continue Journey
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};
