export { TerraCompanion, NovaCompanion, default } from './TerraCompanion';
export type { TerraCompanionProps, TerraCompanionProps as NovaCompanionProps } from './TerraCompanion';
