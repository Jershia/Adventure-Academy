import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import confetti from 'canvas-confetti';
import { Crown, Sparkles, Trophy, ArrowRight, RotateCcw, Mountain, ShieldCheck, Leaf, BookOpen } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { TerraCompanion } from './TerraCompanion';
import { TerraDialogueModal } from './TerraDialogueModal';
import { PlayerProfile } from '../types';
import { sounds } from '../utils/soundEffects';
import { getMasterChallenge } from '../data/curriculumData';

interface MasterChallengeProps {
  player: PlayerProfile;
  onComplete: (rewards: { xp: number; seeds: number; water: number; fertilizer: number }) => void;
  onBackToTitle?: () => void;
}

export const MasterChallenge: React.FC<MasterChallengeProps> = ({
  player,
  onComplete,
  onBackToTitle,
}) => {
  const challenge = useMemo(() => {
    return getMasterChallenge(player.grade, player.mainSubject);
  }, [player.grade, player.mainSubject]);

  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isVictorious, setIsVictorious] = useState(false);
  const [showTerraModal, setShowTerraModal] = useState(false);

  const handleSelect = (idx: number, correct: boolean) => {
    setSelectedOption(idx);
    if (correct) {
      sounds.playSuccess();
      sounds.playMagicChime();
      setIsVictorious(true);

      confetti({
        particleCount: 160,
        spread: 110,
        origin: { y: 0.5 },
        colors: ['#a3e635', '#4ade80', '#facc15', '#38bdf8', '#c084fc'],
      });

      onComplete({
        xp: 500,
        seeds: 10,
        water: 5,
        fertilizer: 5,
      });
    } else {
      sounds.playError();
      setShowTerraModal(true);
    }
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex flex-col justify-between p-3 sm:p-6 overflow-hidden select-none">
      {/* High Forest Canopy Summit Background */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-all duration-1000"
        style={{
          backgroundImage: `url(${ASSETS.sacredTree})`,
          filter: isVictorious ? 'brightness(1.15) contrast(1.1)' : 'brightness(0.85) contrast(1.05)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-black/60 pointer-events-none" />

      {/* Top Banner */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-2 bg-[#1b2615]/90 border-2 border-[#84cc16] px-4 sm:px-5 py-2.5 rounded-2xl shadow-xl backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#16240d] border border-lime-400 flex items-center justify-center text-lime-300 shadow-md">
            <Crown className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h2 className="font-serif font-black text-sm sm:text-base text-[#fef9c3] uppercase tracking-wider">
              {challenge.title}
            </h2>
            <p className="text-xs font-serif text-[#d9f99d]">
              Grade: <strong className="text-white">{player.grade}</strong> • Subject: <strong className="text-white">{player.mainSubject}</strong> • The Grand Canopy Examination
            </p>
          </div>
        </div>

        <span className="bg-gradient-to-r from-lime-500 to-emerald-400 text-black text-xs font-sans font-black px-3 py-1 rounded-full uppercase tracking-wider shadow-md flex items-center gap-1">
          <Leaf className="w-3.5 h-3.5" />
          <span>MASTER TRIAL</span>
        </span>
      </div>

      {/* Center Stage: Floating Temple Altar */}
      <div className="relative z-10 my-4 flex-1 flex flex-col items-center justify-center max-w-4xl mx-auto w-full">
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="relative w-full max-w-2xl bg-gradient-to-b from-[#203316] via-[#16240f] to-[#0d1609] border-4 border-[#84cc16] rounded-3xl p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.95)] text-[#f4ecd8] text-center"
          style={{
            boxShadow: '0 0 50px rgba(132,204,22,0.4), inset 0 2px 10px rgba(255,255,255,0.2)',
          }}
        >
          {/* Ornate Corner Accents */}
          <div className="absolute -top-3 -left-3 w-8 h-8 border-t-4 border-l-4 border-lime-400 rounded-tl-lg" />
          <div className="absolute -top-3 -right-3 w-8 h-8 border-t-4 border-r-4 border-lime-400 rounded-tr-lg" />
          <div className="absolute -bottom-3 -left-3 w-8 h-8 border-b-4 border-l-4 border-lime-400 rounded-bl-lg" />
          <div className="absolute -bottom-3 -right-3 w-8 h-8 border-b-4 border-r-4 border-lime-400 rounded-br-lg" />

          {/* Question Inscription */}
          <div className="bg-[#142316] border-2 border-[#365314] rounded-2xl p-6 shadow-inner mb-6">
            <div className="text-xs font-serif font-bold uppercase tracking-widest text-[#a7f3d0] mb-2 flex items-center justify-center gap-1.5">
              <Leaf className="w-4 h-4 text-lime-400" />
              <span>THE SACRED FORESTRY DECREE:</span>
            </div>

            <div className="font-serif font-black text-xl sm:text-2xl text-yellow-200 tracking-wider my-2">
              {challenge.prompt}
            </div>

            <p className="font-serif text-sm text-[#cbd5e1] mt-2">
              {challenge.subtext}
            </p>
          </div>

          {/* 4 Choices */}
          <div className="space-y-3">
            {challenge.options.map((opt, idx) => {
              const isSelected = selectedOption === idx;

              return (
                <button
                  key={opt.id}
                  onClick={() => handleSelect(idx, opt.correct)}
                  className={`w-full p-4 rounded-2xl font-serif font-bold text-sm sm:text-base border-2 transition-all active:scale-98 flex items-center justify-between text-left ${
                    isSelected && opt.correct
                      ? 'bg-gradient-to-r from-emerald-800 to-emerald-900 text-white border-lime-300 shadow-[0_0_20px_rgba(74,222,128,0.7)] scale-102'
                      : isSelected && !opt.correct
                      ? 'bg-gradient-to-r from-red-900 to-red-950 text-white border-red-500'
                      : 'bg-gradient-to-r from-[#283e18] to-[#16240d] hover:from-[#365314] hover:to-[#203316] text-[#fed7aa] border-[#4d7c0f]'
                  }`}
                >
                  <span className="pr-3 leading-snug">{opt.text}</span>
                  <div
                    className={`w-7 h-7 rounded-full border shrink-0 flex items-center justify-center text-xs font-mono font-bold ${
                      isSelected && opt.correct
                        ? 'bg-lime-400 text-black border-lime-300'
                        : 'border-stone-500 text-stone-400'
                    }`}
                  >
                    {String.fromCharCode(65 + idx)}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Victory Modal Overlay when Solved */}
          {isVictorious && (
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="mt-6 p-6 bg-gradient-to-b from-[#142617] to-[#0c180e] border-2 border-lime-300 rounded-2xl shadow-2xl"
            >
              <div className="w-16 h-16 rounded-full bg-gradient-to-b from-lime-400 to-emerald-500 text-black mx-auto flex items-center justify-center shadow-[0_0_25px_rgba(163,230,53,0.9)] mb-3">
                <Trophy className="w-9 h-9" />
              </div>
              <h3 className="font-serif font-black text-2xl text-yellow-200 uppercase tracking-widest">
                FOREST MASTER SCHOLAR!
              </h3>
              <p className="font-serif text-sm text-[#a7f3d0] mt-1">
                You harmonized the highest canopy knowledge of {player.grade} {player.mainSubject}!
              </p>
              <div className="my-3 font-mono text-sm text-lime-300 font-bold">
                +500 XP | +10 Seeds | +5 Water | +5 Fertilizer | Master Forest Crest
              </div>

              {onBackToTitle && (
                <button
                  onClick={() => {
                    sounds.playSuccess();
                    onBackToTitle();
                  }}
                  className="mt-3 py-3 px-6 bg-gradient-to-b from-[#65a30d] to-[#365314] hover:from-[#84cc16] hover:to-[#3f6212] text-[#fef9c3] rounded-xl text-xs font-serif font-black uppercase tracking-widest border-2 border-lime-300 shadow-xl transition active:scale-95"
                >
                  RETURN TO TITLE & EXPEDITION ARCHIVES
                </button>
              )}
            </motion.div>
          )}
        </motion.div>
      </div>

      {/* Terra Companion */}
      <div className="relative z-10 flex items-center justify-between">
        <TerraCompanion
          size="md"
          mood={isVictorious ? 'excited' : 'speaking'}
          speechBubble={
            isVictorious
              ? 'Astounding triumph! You stand at the pinnacle of the Whispering Woods with ultimate mastery!'
              : `Terra: "Review the evidence carefully, Explorer: ${challenge.prompt}"`
          }
        />
      </div>

      {/* Terra Hint Modal */}
      <TerraDialogueModal
        isOpen={showTerraModal}
        onClose={() => setShowTerraModal(false)}
        problemContext={{
          question: challenge.prompt,
          topic: `${player.grade} ${player.mainSubject} Master Challenge`,
          currentInput: selectedOption !== null ? challenge.options[selectedOption].text : '',
          grade: player.grade,
          subject: player.mainSubject,
        }}
        onTryAgain={() => {
          setSelectedOption(null);
          setShowTerraModal(false);
        }}
      />
    </div>
  );
};

