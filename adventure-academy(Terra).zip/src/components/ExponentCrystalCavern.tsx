import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { Sparkles, Trophy, HelpCircle, CheckCircle2, ChevronRight, Gem, Flame, Zap } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { NovaDialogueModal } from './NovaDialogueModal';
import { PlayerProfile } from '../types';
import { sounds } from '../utils/soundEffects';

interface ExponentCrystalCavernProps {
  player: PlayerProfile;
  onComplete: (rewards: { xp: number; seeds: number; water: number; fertilizer: number }) => void;
  onNext?: () => void;
  onBackToMap?: () => void;
}

interface CavernStage {
  id: number;
  title: string;
  subtitle: string;
  prompt: string;
  formula: string;
  options: { label: string; value: string; correct: boolean; explanation: string }[];
  hint: string;
}

export const ExponentCrystalCavern: React.FC<ExponentCrystalCavernProps> = ({
  player,
  onComplete,
  onNext,
  onBackToMap,
}) => {
  const [currentStageIdx, setCurrentStageIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [stageCleared, setStageCleared] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [showNovaModal, setShowNovaModal] = useState(false);

  const STAGES: CavernStage[] = [
    {
      id: 1,
      title: 'Stage 1: Luminescent Crystal Lattice Growth',
      subtitle: 'Exponential Growth: N(t) = N₀ · 2^(t/k)',
      prompt: 'An ancient cavern mana crystal starts with an initial power yield of N₀ = 4 units. Its crystal lattice duplicates every 2 hours (k = 2). What will be its energy yield after t = 6 hours?',
      formula: 'N(6) = 4 \\times 2^{(6 / 2)} = 4 \\times 2^3 = 4 \\times 8',
      options: [
        {
          label: '32 units (4 × 2³ = 4 × 8)',
          value: '32',
          correct: true,
          explanation: 'Brilliant calculation! 6 / 2 = 3 doubling cycles. 2³ = 8, and 4 × 8 = 32 power units!',
        },
        {
          label: '24 units (4 × 6 linear growth)',
          value: '24',
          correct: false,
          explanation: 'Careful: crystals grow exponentially with powers of 2, not by linear multiplication (4 × 6)!',
        },
        {
          label: '16 units (4 × 2²)',
          value: '16',
          correct: false,
          explanation: 'At 4 hours (2 cycles), the yield would be 16. At 6 hours (3 cycles), it reaches 32!',
        },
        {
          label: '64 units (4 × 2⁴)',
          value: '64',
          correct: false,
          explanation: '64 units would occur after 8 hours (4 doubling cycles), not 6 hours.',
        },
      ],
      hint: 'First find the number of doubling periods: 6 hours / 2 hours = 3 cycles. Then calculate 4 × (2³).',
    },
    {
      id: 2,
      title: 'Stage 2: Harmonic Crystal Resonator Tuning',
      subtitle: 'Logarithmic Inverse Scaling: log₃(x) = 4',
      prompt: 'To shatter the granite seal blocking the deeper cavern, you must tune the acoustic crystal resonator. The resonant frequency x satisfies the equation log₃(x) = 4. What frequency in Hertz must you channel?',
      formula: '\\log_3(x) = 4 \\iff x = 3^4',
      options: [
        {
          label: '81 Hz (x = 3⁴ = 3 × 3 × 3 × 3)',
          value: '81',
          correct: true,
          explanation: 'Precision harmony! By the definition of logarithms, log_b(x) = y means x = b^y. Thus 3⁴ = 81 Hz!',
        },
        {
          label: '12 Hz (3 × 4)',
          value: '12',
          correct: false,
          explanation: 'Remember that exponents represent repeated multiplication (3 × 3 × 3 × 3 = 81), not 3 × 4 = 12.',
        },
        {
          label: '64 Hz (4³)',
          value: '64',
          correct: false,
          explanation: 'Do not flip base and exponent: the base is 3 and the exponent is 4 (3⁴ = 81, not 4³ = 64)!',
        },
        {
          label: '27 Hz (3³)',
          value: '27',
          correct: false,
          explanation: '3³ is 27 (log₃(27) = 3). For log₃(x) = 4, multiply by 3 one more time to reach 81!',
        },
      ],
      hint: 'Convert logarithmic form log_b(x) = y into exponential form x = b^y. Here base is 3 and power is 4.',
    },
    {
      id: 3,
      title: 'Stage 3: Arcane Radiation Half-Life',
      subtitle: 'Exponential Decay: A(t) = A₀ · (1/2)^(t/h)',
      prompt: 'A rare glowing mana ore emits 120 millirems of arcane radiation with a half-life of h = 5 minutes. How much radiation remains after t = 15 minutes (3 half-lives)?',
      formula: 'A(15) = 120 \\times \\left(\\frac{1}{2}\\right)^3 = 120 \\times \\frac{1}{8} = 15',
      options: [
        {
          label: '15 millirems (120 ÷ 8)',
          value: '15',
          correct: true,
          explanation: 'Exceptional mastery! After 15 minutes (3 half-lives), the radiation halves 3 times: 120 → 60 → 30 → 15 millirems!',
        },
        {
          label: '40 millirems (120 ÷ 3)',
          value: '40',
          correct: false,
          explanation: 'Half-life divides by 2 each cycle (halved 3 times is divided by 8), not divided by 3!',
        },
        {
          label: '30 millirems (After 2 half-lives)',
          value: '30',
          correct: false,
          explanation: '30 millirems is the amount remaining at 10 minutes (2 half-lives). After 15 minutes it halves again to 15!',
        },
        {
          label: '0 millirems (Decayed completely)',
          value: '0',
          correct: false,
          explanation: 'Exponential decay approaches zero asymptotically; after 3 half-lives, 12.5% of the original activity remains.',
        },
      ],
      hint: 'Track the three 5-minute half-life steps: 120 divided by 2 is 60; 60 divided by 2 is 30; 30 divided by 2 is...',
    },
  ];

  const currentStage = STAGES[currentStageIdx];

  const handleSelectOption = (idx: number) => {
    setSelectedOption(idx);
    const opt = currentStage.options[idx];

    if (opt.correct) {
      sounds.playSuccess();
      sounds.playMagicChime();
      setStageCleared(true);

      if (currentStageIdx === STAGES.length - 1) {
        confetti({
          particleCount: 110,
          spread: 85,
          origin: { y: 0.6 },
          colors: ['#a855f7', '#ec4899', '#38bdf8', '#facc15'],
        });
        setTimeout(() => {
          setShowCelebration(true);
          onComplete({
            xp: 260,
            seeds: 6,
            water: 4,
            fertilizer: 4,
          });
        }, 1200);
      }
    } else {
      sounds.playError();
      setShowNovaModal(true);
    }
  };

  const handleNextStage = () => {
    if (currentStageIdx < STAGES.length - 1) {
      sounds.playClick();
      setCurrentStageIdx((prev) => prev + 1);
      setSelectedOption(null);
      setStageCleared(false);
    }
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex items-center justify-center p-3 sm:p-6 overflow-hidden select-none">
      {/* Background Painted Bioluminescent Crystal Cavern */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${ASSETS.forestBackground})`,
          filter: 'hue-rotate(240deg) brightness(0.65) contrast(1.2)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-purple-950/40 to-black/75 pointer-events-none" />

      {/* Main Altar Board */}
      <div className="relative z-10 w-full max-w-4xl bg-gradient-to-b from-[#231230] via-[#170a22] to-[#0d0414] border-4 border-purple-500/70 rounded-3xl p-4 sm:p-7 shadow-[0_25px_60px_rgba(0,0,0,0.9)] flex flex-col justify-between">
        {/* Header Ribbon */}
        <div className="flex flex-wrap items-center justify-between border-b-2 border-purple-800/60 pb-3 gap-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-950/90 border border-purple-400 flex items-center justify-center text-purple-300 shadow-md">
              <Gem className="w-6 h-6 animate-pulse text-fuchsia-400" />
            </div>
            <div>
              <div className="text-[11px] font-mono uppercase tracking-widest text-purple-300">
                EXPONENT CAVERN • REALM CHALLENGE
              </div>
              <h2 className="font-serif font-black text-xl sm:text-2xl text-purple-100">
                Luminescent Crystal Lattice & Logarithm Resonator
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="bg-[#15091f] border border-purple-600/60 px-3 py-1.5 rounded-xl text-xs font-mono text-purple-200">
              Stage {currentStageIdx + 1} of {STAGES.length}
            </div>
            <button
              onClick={() => {
                sounds.playClick();
                setShowNovaModal(true);
              }}
              className="p-2 bg-purple-900/40 hover:bg-purple-800/60 border border-purple-500/60 rounded-xl text-purple-200 transition"
              title="Ask Nova for a hint"
            >
              <HelpCircle className="w-5 h-5 text-purple-300" />
            </button>
          </div>
        </div>

        {/* Challenge Stage Content */}
        <div className="my-5 grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
          {/* Left: Interactive Diagram / Visual for Stage */}
          <div className="md:col-span-5 bg-[#0e0516]/95 border-2 border-purple-800/60 rounded-2xl p-4 flex flex-col items-center justify-center min-h-[270px] shadow-inner">
            <div className="text-xs font-serif font-bold text-purple-300/80 uppercase tracking-wider mb-2">
              {currentStageIdx === 0 && 'Crystal Duplication Lattice'}
              {currentStageIdx === 1 && 'Acoustic Frequency Spectrum'}
              {currentStageIdx === 2 && 'Decay Half-Life Curve'}
            </div>

            {/* STAGE 1: Exponential Growth Crystal Lattice */}
            {currentStageIdx === 0 && (
              <svg width="220" height="150" viewBox="0 0 220 150">
                {/* Generation 0: 1 cluster */}
                <circle cx="35" cy="75" r="14" fill="#a855f7" fillOpacity="0.4" stroke="#c084fc" strokeWidth="2" />
                <text x="35" y="79" fill="#f5d0fe" fontSize="10" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  t=0h (4)
                </text>

                {/* Arrow 1 */}
                <line x1="52" y1="75" x2="72" y2="75" stroke="#ec4899" strokeWidth="2" markerEnd="url(#arrow)" />

                {/* Generation 1: 8 */}
                <circle cx="90" cy="50" r="12" fill="#9333ea" fillOpacity="0.4" stroke="#a855f7" strokeWidth="2" />
                <circle cx="90" cy="95" r="12" fill="#9333ea" fillOpacity="0.4" stroke="#a855f7" strokeWidth="2" />
                <text x="90" y="125" fill="#e9d5ff" fontSize="9" textAnchor="middle" fontFamily="monospace">
                  t=2h (8)
                </text>

                {/* Arrow 2 */}
                <line x1="105" y1="75" x2="125" y2="75" stroke="#ec4899" strokeWidth="2" />

                {/* Generation 2: 16 */}
                <rect x="130" y="40" width="18" height="70" rx="9" fill="#7e22ce" fillOpacity="0.4" stroke="#a855f7" strokeWidth="2" />
                <text x="139" y="125" fill="#e9d5ff" fontSize="9" textAnchor="middle" fontFamily="monospace">
                  t=4h (16)
                </text>

                {/* Arrow 3 */}
                <line x1="152" y1="75" x2="172" y2="75" stroke="#ec4899" strokeWidth="2" />

                {/* Target Generation: 32 */}
                <rect x="175" y="25" width="30" height="100" rx="8" fill="#581c87" stroke="#f472b6" strokeWidth="2.5" />
                <text x="190" y="75" fill="#fdf2f8" fontSize="11" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  t=6h
                </text>
                <text x="190" y="90" fill="#f472b6" fontSize="10" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  ? (32)
                </text>
              </svg>
            )}

            {/* STAGE 2: Logarithm Frequency Resonator */}
            {currentStageIdx === 1 && (
              <svg width="220" height="150" viewBox="0 0 220 150">
                {/* Resonator Base Tuning Bar */}
                <line x1="20" y1="120" x2="200" y2="120" stroke="#a855f7" strokeWidth="3" />

                {/* Base 3 logarithmic steps: 1, 3, 9, 27, 81 */}
                <circle cx="30" cy="120" r="4" fill="#c084fc" />
                <text x="30" y="135" fill="#e9d5ff" fontSize="9" textAnchor="middle">1</text>

                <circle cx="65" cy="120" r="5" fill="#c084fc" />
                <text x="65" y="135" fill="#e9d5ff" fontSize="9" textAnchor="middle">3¹</text>

                <circle cx="105" cy="120" r="6" fill="#c084fc" />
                <text x="105" y="135" fill="#e9d5ff" fontSize="9" textAnchor="middle">3²</text>

                <circle cx="145" cy="120" r="7" fill="#c084fc" />
                <text x="145" y="135" fill="#e9d5ff" fontSize="9" textAnchor="middle">3³</text>

                {/* Target Step 3⁴ = 81 */}
                <circle cx="185" cy="120" r="9" fill="#f472b6" stroke="#fff" strokeWidth="2" />
                <text x="185" y="138" fill="#f472b6" fontSize="10" fontWeight="bold" textAnchor="middle">3⁴=81</text>

                {/* Acoustic Sine Wave Resonance */}
                <path
                  d="M 20 60 Q 60 20, 100 60 T 180 60"
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="2.5"
                  strokeDasharray="4 2"
                />
                <text x="110" y="30" fill="#67e8f9" fontSize="11" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  log₃(x) = 4 ⟹ x = 81 Hz
                </text>
              </svg>
            )}

            {/* STAGE 3: Half-Life Exponential Decay Curve */}
            {currentStageIdx === 2 && (
              <svg width="220" height="150" viewBox="0 0 220 150">
                {/* Axes */}
                <line x1="30" y1="20" x2="30" y2="120" stroke="#a855f7" strokeWidth="2" />
                <line x1="30" y1="120" x2="200" y2="120" stroke="#a855f7" strokeWidth="2" />

                {/* Curve points: (0, 120) -> (5m, 60) -> (10m, 30) -> (15m, 15) */}
                <path
                  d="M 30 25 Q 70 70, 110 95 T 190 115"
                  fill="none"
                  stroke="#f43f5e"
                  strokeWidth="3"
                />

                {/* Points */}
                <circle cx="30" cy="25" r="4" fill="#fb7185" />
                <text x="10" y="28" fill="#fda4af" fontSize="9" fontFamily="monospace">120</text>

                <circle cx="70" cy="70" r="4" fill="#fb7185" />
                <text x="65" y="60" fill="#fda4af" fontSize="8" fontFamily="monospace">60</text>

                <circle cx="110" cy="95" r="4" fill="#fb7185" />
                <text x="105" y="85" fill="#fda4af" fontSize="8" fontFamily="monospace">30</text>

                <circle cx="150" cy="108" r="5" fill="#facc15" stroke="#fff" strokeWidth="1.5" />
                <text x="155" y="105" fill="#fde047" fontSize="10" fontWeight="bold" fontFamily="monospace">
                  15m: 15
                </text>

                {/* X labels */}
                <text x="70" y="132" fill="#cbd5e1" fontSize="8">5m</text>
                <text x="110" y="132" fill="#cbd5e1" fontSize="8">10m</text>
                <text x="150" y="132" fill="#fde047" fontSize="8" fontWeight="bold">15m</text>
              </svg>
            )}
          </div>

          {/* Right: Question & Multiple Choice */}
          <div className="md:col-span-7 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono uppercase tracking-widest text-purple-400 mb-1">
                {currentStage.subtitle}
              </div>
              <h3 className="font-serif font-bold text-lg sm:text-xl text-purple-50 leading-snug mb-3">
                {currentStage.prompt}
              </h3>

              <div className="bg-[#12071a] border border-purple-600/40 rounded-xl px-3 py-2 text-xs font-mono text-purple-300 mb-4 inline-block">
                Formula: {currentStage.formula}
              </div>
            </div>

            {/* Options Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 my-2">
              {currentStage.options.map((option, idx) => {
                const isSelected = selectedOption === idx;
                const isCorrect = option.correct;
                let btnStyle = 'bg-[#180b22] hover:bg-[#220f30] border-purple-800/60 text-purple-100';

                if (isSelected) {
                  btnStyle = isCorrect
                    ? 'bg-emerald-950/90 border-emerald-400 text-emerald-100 ring-2 ring-emerald-500'
                    : 'bg-red-950/90 border-red-400 text-red-100 ring-2 ring-red-500';
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(idx)}
                    disabled={stageCleared}
                    className={`p-3 border-2 rounded-xl text-left transition-all active:scale-[0.98] shadow-md flex items-center justify-between text-xs sm:text-sm font-serif font-bold ${btnStyle}`}
                  >
                    <span>{option.label}</span>
                    {isSelected && isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 ml-2" />}
                  </button>
                );
              })}
            </div>

            {/* Advance / Next Stage Footer */}
            <div className="mt-4 flex items-center justify-between pt-2 border-t border-purple-900/60">
              {stageCleared ? (
                <div className="flex items-center justify-between w-full">
                  <div className="text-xs font-mono text-emerald-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Crystal Resonance Tuned!</span>
                  </div>

                  {currentStageIdx < STAGES.length - 1 ? (
                    <button
                      onClick={handleNextStage}
                      className="px-5 py-2 bg-gradient-to-r from-purple-600 to-fuchsia-700 hover:from-purple-500 hover:to-fuchsia-600 text-white font-serif font-bold text-xs rounded-xl shadow-lg flex items-center gap-1.5 active:scale-95 transition"
                    >
                      <span>Next Stage</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        sounds.playVictoryFanfare();
                        setShowCelebration(true);
                      }}
                      className="px-5 py-2 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black font-serif font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 active:scale-95 transition"
                    >
                      <Trophy className="w-4 h-4" />
                      <span>Claim Exponent Treasures</span>
                    </button>
                  )}
                </div>
              ) : (
                <div className="text-xs font-serif text-purple-200/60 italic">
                  Select the exponential or logarithmic frequency to activate the crystal lattice.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom Companion Footer & Back to Map */}
        <div className="flex items-center justify-between border-t border-purple-900/60 pt-3 text-xs">
          <button
            onClick={() => {
              sounds.playClick();
              if (onBackToMap) onBackToMap();
            }}
            className="text-purple-300 hover:text-purple-100 font-serif font-bold transition flex items-center gap-1"
          >
            ← Return to World Map
          </button>

          <div className="flex items-center gap-2">
            <span className="text-purple-300 font-mono text-[11px]">Resonance Level:</span>
            <span className="text-fuchsia-400 font-serif font-bold">100% Harmonic Exponential Stability</span>
          </div>
        </div>
      </div>

      {/* Nova Hint Modal */}
      <AnimatePresence>
        {showNovaModal && (
          <NovaDialogueModal
            isOpen={showNovaModal}
            onClose={() => setShowNovaModal(false)}
            onTryAgain={() => {
              setShowNovaModal(false);
              setSelectedOption(null);
            }}
            question={currentStage.prompt}
            topic="Exponents & Logarithms"
            playerGrade={player.grade}
          />
        )}
      </AnimatePresence>

      {/* Final Victory Celebration Modal */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="w-full max-w-md bg-gradient-to-b from-[#210d30] to-[#0d0414] border-4 border-purple-400 rounded-3xl p-6 shadow-2xl text-center flex flex-col items-center"
            >
              <div className="w-16 h-16 rounded-2xl bg-purple-500/20 border-2 border-purple-400 flex items-center justify-center text-purple-300 mb-3 animate-bounce">
                <Trophy className="w-8 h-8 text-fuchsia-400" />
              </div>

              <div className="text-xs font-mono uppercase tracking-widest text-purple-400">
                EXPONENT CAVERN CLEARED
              </div>
              <h2 className="font-serif font-black text-2xl sm:text-3xl text-purple-100 mt-1 mb-2">
                Master of Powers & Logarithms!
              </h2>

              <p className="text-sm text-purple-100/90 font-serif leading-relaxed mb-4">
                You mastered doubling crystal lattice cycles, resonated base-3 frequencies, and charted radioactive half-life decays!
              </p>

              {/* Rewards Box */}
              <div className="w-full bg-[#0d0414] border-2 border-purple-600/60 rounded-2xl p-3.5 mb-5 flex justify-around text-center font-mono">
                <div>
                  <div className="text-lg font-bold text-yellow-400">+260</div>
                  <div className="text-[10px] text-purple-200/80">XP</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-emerald-400">+6</div>
                  <div className="text-[10px] text-purple-200/80">SEEDS</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-cyan-400">+4</div>
                  <div className="text-[10px] text-purple-200/80">WATER</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-orange-400">+4</div>
                  <div className="text-[10px] text-purple-200/80">FERTILIZER</div>
                </div>
              </div>

              <div className="flex gap-2 w-full">
                <button
                  onClick={() => {
                    sounds.playClick();
                    if (onNext) onNext();
                    else if (onBackToMap) onBackToMap();
                  }}
                  className="flex-1 py-3 bg-gradient-to-r from-purple-500 to-fuchsia-600 hover:from-purple-400 hover:to-fuchsia-500 text-white font-serif font-black text-sm rounded-xl shadow-lg active:scale-95 transition"
                >
                  Continue Expedition
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
