import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { Key, Sparkles, CheckCircle2, Lock, ArrowRight, RotateCcw, Leaf } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { TerraCompanion } from './TerraCompanion';
import { TerraDialogueModal } from './TerraDialogueModal';
import { PlayerProfile } from '../types';
import { sounds } from '../utils/soundEffects';
import { getGateCurriculum } from '../data/curriculumData';

interface KnowledgeGateProps {
  player: PlayerProfile;
  onUnlockRealm: (realmName: string, rewards: { xp: number; seeds: number; water: number; fertilizer: number }) => void;
  onNext?: () => void;
}

export const KnowledgeGate: React.FC<KnowledgeGateProps> = ({
  player,
  onUnlockRealm,
  onNext,
}) => {
  const gatePuzzles = useMemo(() => {
    return getGateCurriculum(player.grade, player.mainSubject);
  }, [player.grade, player.mainSubject]);

  const [activePuzzleIndex, setActivePuzzleIndex] = useState(0);
  const [unlockedRunes, setUnlockedRunes] = useState<number[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isGateOpen, setIsGateOpen] = useState(false);
  const [showTerraModal, setShowTerraModal] = useState(false);

  const currentPuzzle = gatePuzzles[activePuzzleIndex] || gatePuzzles[0];

  const handleSelectOption = (opt: { label: string; text: string; correct: boolean }) => {
    setSelectedAnswer(opt.label);
    if (opt.correct) {
      sounds.playSuccess();
      sounds.playMagicChime();
      const updatedRunes = [...unlockedRunes, currentPuzzle.id];
      setUnlockedRunes(updatedRunes);

      if (updatedRunes.length === gatePuzzles.length) {
        setIsGateOpen(true);
        confetti({
          particleCount: 110,
          spread: 85,
          origin: { y: 0.5 },
          colors: ['#a3e635', '#4ade80', '#facc15', '#38bdf8'],
        });
        onUnlockRealm(`${player.mainSubject} Canopy`, {
          xp: 150,
          seeds: 4,
          water: 2,
          fertilizer: 2,
        });
      } else {
        setTimeout(() => {
          setActivePuzzleIndex(activePuzzleIndex + 1);
          setSelectedAnswer(null);
        }, 1000);
      }
    } else {
      sounds.playError();
      setShowTerraModal(true);
    }
  };

  const handleReset = () => {
    setActivePuzzleIndex(0);
    setUnlockedRunes([]);
    setSelectedAnswer(null);
    setIsGateOpen(false);
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex flex-col justify-between p-3 sm:p-6 overflow-hidden select-none">
      {/* Ancient Gate Ruins Background */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-all duration-1000"
        style={{
          backgroundImage: `url(${ASSETS.ruinsGate})`,
          filter: isGateOpen ? 'brightness(1.1) contrast(1.15)' : 'brightness(0.85) contrast(1.05)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-black/60 pointer-events-none" />

      {/* Top Banner Header */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-2 bg-[#1b2615]/90 border-2 border-[#4d7c0f] px-4 sm:px-5 py-2.5 rounded-2xl shadow-xl backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#4d7c0f] text-[#ecfccb] text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider flex items-center gap-1">
              <Leaf className="w-3 h-3 text-[#bef264]" />
              <span>FOREST PORTAL</span>
            </span>
            <h2 className="font-serif font-black text-sm sm:text-base text-[#fef9c3] uppercase tracking-wider">
              KNOWLEDGE GATE OF {player.mainSubject.toUpperCase()} ({player.grade})
            </h2>
          </div>
          <p className="text-xs font-serif text-[#d9f99d] mt-0.5">
            {gatePuzzles.length - unlockedRunes.length > 0
              ? `${player.mainSubject}: ${gatePuzzles.length - unlockedRunes.length} RUNES REMAINING TO OPEN GATE`
              : 'ALL RUNES ACTIVATED — THE FOREST PASSAGE OPENS!'}
          </p>
        </div>

        <button
          onClick={handleReset}
          className="p-2 bg-[#2d4a1d] hover:bg-[#365314] text-[#ecfccb] rounded-xl border border-[#65a30d] transition"
          title="Reset Gate Runes"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Center Stage: Gate Portal & Triangular Runes */}
      <div className="relative z-10 my-4 flex-1 flex flex-col items-center justify-center max-w-4xl mx-auto w-full">
        {/* Stone Archway Portal Frame */}
        <div className="relative w-full max-w-xl bg-gradient-to-b from-[#1c2e17] via-[#132010] to-[#0a1208] border-4 border-[#65a30d] rounded-3xl p-6 shadow-[0_25px_60px_rgba(0,0,0,0.95)] text-center text-[#f4ecd8] overflow-hidden">
          {/* Radiant Gate Light rays when open */}
          {isGateOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="absolute inset-0 bg-gradient-to-b from-lime-400/30 via-emerald-300/20 to-transparent pointer-events-none"
            />
          )}

          {/* Rune Slots in Gate Keystone */}
          <div className="flex items-center justify-center gap-4 mb-5">
            {gatePuzzles.map((puzzle, idx) => {
              const isFilled = unlockedRunes.includes(puzzle.id);
              const isCurrent = idx === activePuzzleIndex && !isGateOpen;

              return (
                <div
                  key={puzzle.id}
                  className={`w-14 h-14 rounded-2xl border-3 flex flex-col items-center justify-center transition-all ${
                    isFilled
                      ? 'bg-gradient-to-b from-[#65a30d] to-[#365314] border-lime-300 shadow-[0_0_15px_rgba(163,230,53,0.9)] text-[#ecfccb]'
                      : isCurrent
                      ? 'bg-[#203316] border-lime-400 text-lime-300 animate-pulse'
                      : 'bg-[#101a0d] border-[#2b441c] text-stone-600'
                  }`}
                >
                  <Sparkles className="w-5 h-5" />
                  <span className="text-[9px] font-mono font-bold mt-0.5">
                    {isFilled ? 'ACTIVE' : `RUNE ${idx + 1}`}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Gate Slate / Puzzle Board */}
          {!isGateOpen ? (
            <motion.div
              key={currentPuzzle.id}
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-[#142316] border-2 border-[#365314] rounded-2xl p-5 shadow-inner"
            >
              <div className="text-xs font-serif font-bold uppercase tracking-widest text-[#a7f3d0] mb-1">
                {currentPuzzle.runeName}
              </div>
              <h3 className="font-serif font-black text-lg text-yellow-200 mb-2">
                {currentPuzzle.question}
              </h3>
              <div className="p-3 bg-[#0c180e] rounded-xl border border-[#234220] font-mono text-sm text-lime-300 mb-4">
                {currentPuzzle.figureDescription}
              </div>

              {/* 4 Choices */}
              <div className="grid grid-cols-2 gap-3">
                {currentPuzzle.options.map((opt) => {
                  const isSelected = selectedAnswer === opt.label;
                  return (
                    <button
                      key={opt.label}
                      onClick={() => handleSelectOption(opt)}
                      className={`py-3 px-4 rounded-xl font-serif font-bold text-sm border-2 transition-all active:scale-95 flex items-center justify-center gap-2 ${
                        isSelected && opt.correct
                          ? 'bg-emerald-700 text-white border-lime-300 shadow-lg'
                          : 'bg-[#203316] hover:bg-[#2c471f] text-[#fed7aa] border-[#4d7c0f]'
                      }`}
                    >
                      <span className="w-5 h-5 rounded-full bg-black/40 flex items-center justify-center text-xs">
                        {opt.label}
                      </span>
                      <span>{opt.text}</span>
                    </button>
                  );
                })}
              </div>
            </motion.div>
          ) : (
            /* GATE UNLOCKED CELEBRATION */
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="py-6 px-4 bg-[#142316]/95 border-2 border-lime-400 rounded-2xl shadow-2xl flex flex-col items-center"
            >
              <div className="w-16 h-16 rounded-full bg-lime-400 text-black flex items-center justify-center shadow-[0_0_30px_rgba(163,230,53,0.9)] mb-3 animate-bounce">
                <Key className="w-8 h-8" />
              </div>
              <h3 className="font-serif font-black text-2xl text-yellow-200 uppercase tracking-widest">
                GATE UNLOCKED!
              </h3>
              <p className="font-serif text-sm text-[#fed7aa] mt-1">
                The massive forest doors grind open. The lush realm of <span className="text-white font-bold">{player.mainSubject} Canopy</span> is revealed!
              </p>
              <div className="my-4 p-2.5 bg-emerald-950 border border-emerald-500 rounded-xl font-mono text-xs text-emerald-300 font-bold">
                +150 XP | +4 Seeds | +2 Water | +2 Fertilizer | Area Unlocked!
              </div>

              {onNext && (
                <button
                  onClick={() => {
                    sounds.playSuccess();
                    onNext();
                  }}
                  className="py-3 px-6 bg-gradient-to-b from-[#15803d] to-[#14532d] hover:from-[#16a34a] hover:to-[#15803d] text-[#fef9c3] rounded-xl text-xs font-serif font-bold uppercase tracking-wider border-2 border-emerald-400 shadow-lg transition active:scale-95 flex items-center gap-2"
                >
                  <span>STEP THROUGH TO CANOPY</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </motion.div>
          )}
        </div>
      </div>

      {/* Terra Companion */}
      <div className="relative z-10 flex items-center justify-between">
        <TerraCompanion
          size="md"
          mood={isGateOpen ? 'excited' : 'speaking'}
          speechBubble={
            isGateOpen
              ? 'The knowledge gate is unsealed! Sunlight flows through to the canopy!'
              : `Terra: "Review the rune inscribed above — let each clue guide you!"`
          }
        />
      </div>

      {/* Terra Modal */}
      <TerraDialogueModal
        isOpen={showTerraModal}
        onClose={() => setShowTerraModal(false)}
        problemContext={{
          question: currentPuzzle.question,
          topic: `${player.grade} ${player.mainSubject}: ${currentPuzzle.runeName}`,
          currentInput: selectedAnswer || '',
          grade: player.grade,
          subject: player.mainSubject,
        }}
        onTryAgain={() => {
          setSelectedAnswer(null);
          setShowTerraModal(false);
        }}
      />
    </div>
  );
};

