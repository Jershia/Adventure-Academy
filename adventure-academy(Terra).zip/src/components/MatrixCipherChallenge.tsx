import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { Sparkles, Trophy, HelpCircle, CheckCircle2, ChevronRight, Grid, Key, Shield } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { NovaDialogueModal } from './NovaDialogueModal';
import { PlayerProfile } from '../types';
import { sounds } from '../utils/soundEffects';

interface MatrixCipherChallengeProps {
  player: PlayerProfile;
  onComplete: (rewards: { xp: number; seeds: number; water: number; fertilizer: number }) => void;
  onNext?: () => void;
  onBackToMap?: () => void;
}

interface MatrixStage {
  id: number;
  title: string;
  subtitle: string;
  prompt: string;
  formula: string;
  options: { label: string; value: string; correct: boolean; explanation: string }[];
  hint: string;
}

export const MatrixCipherChallenge: React.FC<MatrixCipherChallengeProps> = ({
  player,
  onComplete,
  onNext,
  onBackToMap,
}) => {
  const [currentStageIdx, setCurrentStageIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [stageCleared, setStageCleared] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [showNovaModal, setShowNovaModal] = useState(false);

  const STAGES: MatrixStage[] = [
    {
      id: 1,
      title: 'Stage 1: Determinant of the Guardian Sigil',
      subtitle: '2×2 Determinant: det(A) = ad - bc',
      prompt: 'The granite vault of the Matrix Cryptography Shrine is sealed by an arcane 2×2 rune stone: [ [5, 3], [2, 4] ]. What is the scalar determinant key needed to unlock the rune?',
      formula: '\\det \\begin{bmatrix} 5 & 3 \\\\ 2 & 4 \\end{bmatrix} = (5 \\times 4) - (3 \\times 2) = 20 - 6',
      options: [
        {
          label: 'det(M) = 14 (20 - 6 = 14)',
          value: '14',
          correct: true,
          explanation: 'Precisely unlocked! For a 2×2 matrix [[a,b],[c,d]], the determinant is ad - bc = (5×4) - (3×2) = 20 - 6 = 14!',
        },
        {
          label: 'det(M) = 26 (20 + 6 with addition)',
          value: '26',
          correct: false,
          explanation: 'Remember that determinants subtract the off-diagonal product: ad - bc, not ad + bc!',
        },
        {
          label: 'det(M) = 20 (Only the main diagonal)',
          value: '20',
          correct: false,
          explanation: '20 is only 5 × 4; you must subtract the off-diagonal product 3 × 2 = 6.',
        },
        {
          label: 'det(M) = 10',
          value: '10',
          correct: false,
          explanation: 'Double check the arithmetic: 20 - 6 is 14.',
        },
      ],
      hint: 'Multiply the top-left and bottom-right numbers (5 × 4 = 20). Then subtract the product of the other diagonal (3 × 2 = 6).',
    },
    {
      id: 2,
      title: 'Stage 2: Spatial Coordinate Vector Warping',
      subtitle: 'Matrix-Vector Multiplication: M · v = v\'',
      prompt: 'The ancient teleportation circle warps a spatial position vector v = [4, 2]^T using the transformation matrix T = [ [2, 1], [1, 3] ]. Where does the teleported coordinate vector land?',
      formula: '\\begin{bmatrix} 2 & 1 \\\\ 1 & 3 \\end{bmatrix} \\begin{bmatrix} 4 \\\\ 2 \\end{bmatrix} = \\begin{bmatrix} 2(4) + 1(2) \\\\ 1(4) + 3(2) \\end{bmatrix} = \\begin{bmatrix} 10 \\\\ 10 \\end{bmatrix}',
      options: [
        {
          label: '[10, 10]^T (Row dot products: 8+2 and 4+6)',
          value: '10,10',
          correct: true,
          explanation: 'Spot-on spatial alignment! Row 1: 2(4) + 1(2) = 10. Row 2: 1(4) + 3(2) = 10. The coordinate lands at (10, 10)!',
        },
        {
          label: '[8, 6]^T (Component-wise without cross-products)',
          value: '8,6',
          correct: false,
          explanation: 'Matrix multiplication takes the full inner dot product across each row, not component-wise multiplication!',
        },
        {
          label: '[12, 8]^T',
          value: '12,8',
          correct: false,
          explanation: 'Check row 1: 2×4 + 1×2 = 10, not 12.',
        },
        {
          label: '[6, 6]^T',
          value: '6,6',
          correct: false,
          explanation: 'Do not simply add the matrix entries to the vector; compute row-by-column products.',
        },
      ],
      hint: 'Multiply Row 1 [2, 1] by Column [4, 2] to get 2(4) + 1(2). Then Row 2 [1, 3] by [4, 2] to get 1(4) + 3(2).',
    },
    {
      id: 3,
      title: 'Stage 3: The Singular Matrix Seal',
      subtitle: 'Matrix Invertibility: A⁻¹ exists ⟺ det(A) ≠ 0',
      prompt: 'A matrix cannot be inverted (it is singular) when its determinant equals zero, collapsing dimension space. Which of these four stone glyph matrices is singular (det = 0)?',
      formula: '\\det \\begin{bmatrix} 6 & 3 \\\\ 4 & 2 \\end{bmatrix} = (6 \\times 2) - (3 \\times 4) = 12 - 12 = 0',
      options: [
        {
          label: '[[6, 3], [4, 2]] (det = 12 - 12 = 0)',
          value: 'singular',
          correct: true,
          explanation: 'Incredible insight! (6 × 2) - (3 × 4) = 12 - 12 = 0. Because det = 0, this matrix has no inverse and collapses spatial dimension!',
        },
        {
          label: '[[5, 1], [2, 3]] (det = 15 - 2 = 13)',
          value: '13',
          correct: false,
          explanation: 'Det = 15 - 2 = 13 ≠ 0, so this matrix is invertible!',
        },
        {
          label: '[[2, 0], [0, 2]] (Identity scaled, det = 4)',
          value: '4',
          correct: false,
          explanation: 'Det = (2×2) - 0 = 4 ≠ 0, this represents an invertible isotropic expansion.',
        },
        {
          label: '[[3, 2], [1, 4]] (det = 12 - 2 = 10)',
          value: '10',
          correct: false,
          explanation: 'Det = (3×4) - (2×1) = 10 ≠ 0, which is non-singular and invertible.',
        },
      ],
      hint: 'Calculate ad - bc for each matrix. Find the one where the diagonal product equals the off-diagonal product!',
    },
  ];

  const currentStage = STAGES[currentStageIdx];

  const handleSelectOption = (idx: number) => {
    setSelectedOption(idx);
    const opt = currentStage.options[idx];

    if (opt.correct) {
      sounds.playSuccess();
      sounds.playMagicChime();
      setStageCleared(true);

      if (currentStageIdx === STAGES.length - 1) {
        confetti({
          particleCount: 110,
          spread: 85,
          origin: { y: 0.6 },
          colors: ['#eab308', '#f97316', '#10b981', '#6366f1'],
        });
        setTimeout(() => {
          setShowCelebration(true);
          onComplete({
            xp: 290,
            seeds: 8,
            water: 5,
            fertilizer: 5,
          });
        }, 1200);
      }
    } else {
      sounds.playError();
      setShowNovaModal(true);
    }
  };

  const handleNextStage = () => {
    if (currentStageIdx < STAGES.length - 1) {
      sounds.playClick();
      setCurrentStageIdx((prev) => prev + 1);
      setSelectedOption(null);
      setStageCleared(false);
    }
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex items-center justify-center p-3 sm:p-6 overflow-hidden select-none">
      {/* Background Painted Ancient Cipher Shrine */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${ASSETS.ruinsGate})`,
          filter: 'hue-rotate(290deg) brightness(0.7) contrast(1.15)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-amber-950/40 to-black/75 pointer-events-none" />

      {/* Main Altar Board */}
      <div className="relative z-10 w-full max-w-4xl bg-gradient-to-b from-[#2a1b0c] via-[#1a1006] to-[#0d0702] border-4 border-amber-500/70 rounded-3xl p-4 sm:p-7 shadow-[0_25px_60px_rgba(0,0,0,0.9)] flex flex-col justify-between">
        {/* Header Ribbon */}
        <div className="flex flex-wrap items-center justify-between border-b-2 border-amber-800/60 pb-3 gap-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-950/90 border border-amber-400 flex items-center justify-center text-amber-300 shadow-md">
              <Grid className="w-6 h-6 animate-pulse text-yellow-400" />
            </div>
            <div>
              <div className="text-[11px] font-mono uppercase tracking-widest text-amber-300">
                MATRIX CIPHER • REALM CHALLENGE
              </div>
              <h2 className="font-serif font-black text-xl sm:text-2xl text-amber-100">
                The Cryptographic Shrine & Sigil Determinant
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="bg-[#180e05] border border-amber-600/60 px-3 py-1.5 rounded-xl text-xs font-mono text-amber-200">
              Stage {currentStageIdx + 1} of {STAGES.length}
            </div>
            <button
              onClick={() => {
                sounds.playClick();
                setShowNovaModal(true);
              }}
              className="p-2 bg-amber-900/40 hover:bg-amber-800/60 border border-amber-500/60 rounded-xl text-amber-200 transition"
              title="Ask Nova for a hint"
            >
              <HelpCircle className="w-5 h-5 text-amber-300" />
            </button>
          </div>
        </div>

        {/* Challenge Stage Content */}
        <div className="my-5 grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
          {/* Left: Interactive Diagram / Visual for Stage */}
          <div className="md:col-span-5 bg-[#120a03]/95 border-2 border-amber-800/60 rounded-2xl p-4 flex flex-col items-center justify-center min-h-[270px] shadow-inner">
            <div className="text-xs font-serif font-bold text-amber-300/80 uppercase tracking-wider mb-2">
              {currentStageIdx === 0 && 'Matrix Sigil Determinant Cross'}
              {currentStageIdx === 1 && 'Coordinate Vector Warping'}
              {currentStageIdx === 2 && 'Singular Dimension Collapse'}
            </div>

            {/* STAGE 1: Determinant Matrix Diagram */}
            {currentStageIdx === 0 && (
              <svg width="220" height="150" viewBox="0 0 220 150">
                {/* Left bracket */}
                <path d="M 45 35 L 35 35 L 35 115 L 45 115" fill="none" stroke="#f59e0b" strokeWidth="3" />
                {/* Right bracket */}
                <path d="M 175 35 L 185 35 L 185 115 L 175 115" fill="none" stroke="#f59e0b" strokeWidth="3" />

                {/* Matrix entries */}
                <text x="75" y="65" fill="#fef08a" fontSize="24" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  5
                </text>
                <text x="145" y="65" fill="#fef08a" fontSize="24" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  3
                </text>
                <text x="75" y="105" fill="#fef08a" fontSize="24" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  2
                </text>
                <text x="145" y="105" fill="#fef08a" fontSize="24" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  4
                </text>

                {/* Main diagonal cross line (green) */}
                <line x1="75" y1="65" x2="145" y2="105" stroke="#10b981" strokeWidth="2" strokeDasharray="3 2" />
                {/* Off diagonal cross line (red) */}
                <line x1="145" y1="65" x2="75" y2="105" stroke="#f43f5e" strokeWidth="2" strokeDasharray="3 2" />

                <text x="110" y="135" fill="#fbbf24" fontSize="11" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  det = (5×4) - (3×2) = 14
                </text>
              </svg>
            )}

            {/* STAGE 2: Matrix Vector Transformation */}
            {currentStageIdx === 1 && (
              <svg width="220" height="150" viewBox="0 0 220 150">
                {/* Coordinate grid */}
                <line x1="20" y1="120" x2="190" y2="120" stroke="#78350f" strokeWidth="1.5" />
                <line x1="40" y1="20" x2="40" y2="130" stroke="#78350f" strokeWidth="1.5" />

                {/* Original vector: v = (4, 2) -> mapped to (70, 105) */}
                <line x1="40" y1="120" x2="80" y2="100" stroke="#38bdf8" strokeWidth="3" markerEnd="url(#arrow)" />
                <circle cx="80" cy="100" r="4" fill="#38bdf8" />
                <text x="85" y="95" fill="#7dd3fc" fontSize="9" fontWeight="bold" fontFamily="monospace">
                  v = (4, 2)
                </text>

                {/* Warped vector: T·v = (10, 10) -> mapped to (140, 45) */}
                <line x1="40" y1="120" x2="150" y2="45" stroke="#f59e0b" strokeWidth="3" strokeDasharray="3 2" />
                <circle cx="150" cy="45" r="5" fill="#facc15" stroke="#fff" strokeWidth="1.5" />
                <text x="155" y="40" fill="#fde047" fontSize="10" fontWeight="bold" fontFamily="monospace">
                  T·v = (10, 10)
                </text>

                <text x="110" y="138" fill="#fbbf24" fontSize="10" textAnchor="middle" fontFamily="monospace">
                  Warped Vector Output: [10, 10]
                </text>
              </svg>
            )}

            {/* STAGE 3: Singular Matrix Collapse */}
            {currentStageIdx === 2 && (
              <svg width="220" height="150" viewBox="0 0 220 150">
                {/* 2D Plane collapsed to 1D line */}
                <polygon points="40,30 180,40 160,110 20,100" fill="#78350f" fillOpacity="0.2" stroke="#d97706" strokeWidth="1" />
                <line x1="30" y1="110" x2="180" y2="35" stroke="#f43f5e" strokeWidth="3" />
                <text x="110" y="80" fill="#fda4af" fontSize="10" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  Collapsed into Line!
                </text>
                <text x="110" y="98" fill="#fde047" fontSize="10" textAnchor="middle" fontFamily="monospace">
                  det = (6×2) - (3×4) = 0
                </text>
                <text x="110" y="135" fill="#ef4444" fontSize="11" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  A⁻¹ Does Not Exist
                </text>
              </svg>
            )}
          </div>

          {/* Right: Question & Multiple Choice */}
          <div className="md:col-span-7 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono uppercase tracking-widest text-amber-400 mb-1">
                {currentStage.subtitle}
              </div>
              <h3 className="font-serif font-bold text-lg sm:text-xl text-amber-50 leading-snug mb-3">
                {currentStage.prompt}
              </h3>

              <div className="bg-[#1c0f05] border border-amber-600/40 rounded-xl px-3 py-2 text-xs font-mono text-amber-300 mb-4 inline-block">
                Formula: {currentStage.formula}
              </div>
            </div>

            {/* Options Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 my-2">
              {currentStage.options.map((option, idx) => {
                const isSelected = selectedOption === idx;
                const isCorrect = option.correct;
                let btnStyle = 'bg-[#1e1106] hover:bg-[#2c1a0c] border-amber-800/60 text-amber-100';

                if (isSelected) {
                  btnStyle = isCorrect
                    ? 'bg-emerald-950/90 border-emerald-400 text-emerald-100 ring-2 ring-emerald-500'
                    : 'bg-red-950/90 border-red-400 text-red-100 ring-2 ring-red-500';
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(idx)}
                    disabled={stageCleared}
                    className={`p-3 border-2 rounded-xl text-left transition-all active:scale-[0.98] shadow-md flex items-center justify-between text-xs sm:text-sm font-serif font-bold ${btnStyle}`}
                  >
                    <span>{option.label}</span>
                    {isSelected && isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 ml-2" />}
                  </button>
                );
              })}
            </div>

            {/* Advance / Next Stage Footer */}
            <div className="mt-4 flex items-center justify-between pt-2 border-t border-amber-900/60">
              {stageCleared ? (
                <div className="flex items-center justify-between w-full">
                  <div className="text-xs font-mono text-emerald-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Sigil Cipher Unlocked!</span>
                  </div>

                  {currentStageIdx < STAGES.length - 1 ? (
                    <button
                      onClick={handleNextStage}
                      className="px-5 py-2 bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-black font-serif font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 active:scale-95 transition"
                    >
                      <span>Next Stage</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        sounds.playVictoryFanfare();
                        setShowCelebration(true);
                      }}
                      className="px-5 py-2 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-serif font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 active:scale-95 transition"
                    >
                      <Trophy className="w-4 h-4" />
                      <span>Claim Matrix Treasures</span>
                    </button>
                  )}
                </div>
              ) : (
                <div className="text-xs font-serif text-amber-200/60 italic">
                  Select the determinant or vector result to decipher the stone sigils.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom Companion Footer & Back to Map */}
        <div className="flex items-center justify-between border-t border-amber-900/60 pt-3 text-xs">
          <button
            onClick={() => {
              sounds.playClick();
              if (onBackToMap) onBackToMap();
            }}
            className="text-amber-300 hover:text-amber-100 font-serif font-bold transition flex items-center gap-1"
          >
            ← Return to World Map
          </button>

          <div className="flex items-center gap-2">
            <span className="text-amber-300 font-mono text-[11px]">Vault Status:</span>
            <span className="text-yellow-400 font-serif font-bold">100% Determinant Integrity</span>
          </div>
        </div>
      </div>

      {/* Nova Hint Modal */}
      <AnimatePresence>
        {showNovaModal && (
          <NovaDialogueModal
            isOpen={showNovaModal}
            onClose={() => setShowNovaModal(false)}
            onTryAgain={() => {
              setShowNovaModal(false);
              setSelectedOption(null);
            }}
            question={currentStage.prompt}
            topic="Matrices & Linear Algebra"
            playerGrade={player.grade}
          />
        )}
      </AnimatePresence>

      {/* Final Victory Celebration Modal */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="w-full max-w-md bg-gradient-to-b from-[#2e1c0d] to-[#0f0702] border-4 border-amber-400 rounded-3xl p-6 shadow-2xl text-center flex flex-col items-center"
            >
              <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-amber-300 mb-3 animate-bounce">
                <Trophy className="w-8 h-8 text-yellow-400" />
              </div>

              <div className="text-xs font-mono uppercase tracking-widest text-amber-400">
                MATRIX CIPHER SHRINE CLEARED
              </div>
              <h2 className="font-serif font-black text-2xl sm:text-3xl text-amber-100 mt-1 mb-2">
                Grand Cryptographer!
              </h2>

              <p className="text-sm text-amber-100/90 font-serif leading-relaxed mb-4">
                You evaluated 2×2 determinants, transformed spatial vector coordinates, and discovered singular zero-determinant conditions!
              </p>

              {/* Rewards Box */}
              <div className="w-full bg-[#120803] border-2 border-amber-600/60 rounded-2xl p-3.5 mb-5 flex justify-around text-center font-mono">
                <div>
                  <div className="text-lg font-bold text-yellow-400">+290</div>
                  <div className="text-[10px] text-amber-200/80">XP</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-emerald-400">+8</div>
                  <div className="text-[10px] text-amber-200/80">SEEDS</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-cyan-400">+5</div>
                  <div className="text-[10px] text-amber-200/80">WATER</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-orange-400">+5</div>
                  <div className="text-[10px] text-amber-200/80">FERTILIZER</div>
                </div>
              </div>

              <div className="flex gap-2 w-full">
                <button
                  onClick={() => {
                    sounds.playClick();
                    if (onNext) onNext();
                    else if (onBackToMap) onBackToMap();
                  }}
                  className="flex-1 py-3 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-serif font-black text-sm rounded-xl shadow-lg active:scale-95 transition"
                >
                  Continue Expedition
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
