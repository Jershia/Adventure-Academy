import React, { useState } from 'react';
import { motion } from 'motion/react';
import confetti from 'canvas-confetti';
import { Sprout, Droplets, FlaskConical, Sparkles, Hammer, Home, MapPin, BookOpen, Plus, CheckCircle2, TreePine } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { NovaCompanion } from './NovaCompanion';
import { PlayerProfile, PlantData } from '../types';
import { sounds } from '../utils/soundEffects';

interface CampGardenViewProps {
  player: PlayerProfile;
  onUpdatePlayer: (updated: PlayerProfile) => void;
  onNavigate: (screen: string) => void;
}

export const CampGardenView: React.FC<CampGardenViewProps> = ({
  player,
  onUpdatePlayer,
  onNavigate,
}) => {
  const [selectedPlotIndex, setSelectedPlotIndex] = useState<number | null>(0);
  const [loadingAction, setLoadingAction] = useState(false);

  // Default 4 garden plots if none exist
  const plots: PlantData[] = player.camp.plants?.length
    ? player.camp.plants
    : [
        { id: 'plant-1', name: 'Algebra Bloom', stage: 'harvestable', waterLevel: 3, fertilizerApplied: true },
        { id: 'plant-2', name: 'Geometry Vine', stage: 'growing', waterLevel: 2, fertilizerApplied: false },
        { id: 'plant-3', name: 'Calculus Sprout', stage: 'sprout', waterLevel: 1, fertilizerApplied: false },
        { id: 'plant-4', name: 'Empty Bed', stage: 'seed', waterLevel: 0, fertilizerApplied: false },
      ];

  const handleCampAction = async (actionType: 'plant' | 'water' | 'fertilize' | 'harvest' | 'upgrade_building', payload?: any) => {
    sounds.playClick();
    setLoadingAction(true);

    try {
      const res = await fetch('/api/camp/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: actionType, payload }),
      });
      const data = await res.json();
      if (data.camp && data.resources) {
        if (actionType === 'harvest') {
          sounds.playMagicChime();
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.7 },
            colors: ['#4ade80', '#facc15', '#38bdf8'],
          });
        } else if (actionType === 'water') {
          sounds.playWaterSplash();
        } else {
          sounds.playSuccess();
        }

        onUpdatePlayer({
          ...player,
          resources: data.resources,
          camp: data.camp,
          xp: player.xp + (actionType === 'harvest' ? 50 : 10),
        });
      }
    } catch (err) {
      // Local fallback
      sounds.playSuccess();
      const newResources = { ...player.resources };
      if (actionType === 'plant' && newResources.seeds > 0) newResources.seeds -= 1;
      if (actionType === 'water' && newResources.water > 0) newResources.water -= 1;
      if (actionType === 'fertilize' && newResources.fertilizer > 0) newResources.fertilizer -= 1;

      onUpdatePlayer({
        ...player,
        resources: newResources,
        xp: player.xp + 25,
      });
    } finally {
      setLoadingAction(false);
    }
  };

  const activePlant = selectedPlotIndex !== null ? plots[selectedPlotIndex] : null;

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex flex-col justify-between p-3 sm:p-6 overflow-hidden select-none">
      {/* Camp Clearing Background matching Frame 18 & 19 */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${ASSETS.campFire})`,
          filter: 'brightness(0.9) contrast(1.05)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-black/50 pointer-events-none" />

      {/* Top Banner & Resource Strip matching Frame 18 */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 bg-[#24170e]/95 border-2 border-[#855325] px-5 py-2.5 rounded-2xl shadow-xl backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-900/60 border border-amber-500 flex items-center justify-center text-amber-300">
            <Home className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-serif font-black text-sm sm:text-base text-[#fef9c3] uppercase tracking-wider">
              EXPLORER BASE CAMP & MATHEMATIC GARDEN
            </h2>
            <p className="text-xs font-serif text-[#fed7aa]">
              Camp Level {player.camp.level} • Cultivate seeds earned from math quests!
            </p>
          </div>
        </div>

        {/* Inventory Bag Badges & Living Forest Portal matching Frame 18 */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Living Forest: Save the Planet Button */}
          <button
            onClick={() => {
              sounds.playClick();
              onNavigate('grove');
            }}
            className="bg-[#122b17] hover:bg-[#1a3d21] border-2 border-emerald-500/80 px-3 py-1.5 rounded-xl flex items-center gap-1.5 text-xs font-serif font-bold text-emerald-300 transition shadow-lg active:scale-95"
            title="Visit Living Forest Sanctuary — Plant Real Trees!"
          >
            <TreePine className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span>Living Grove ({player.realTreesPlanted || 0} Real Trees)</span>
          </button>

          <div className="bg-[#1b1007] border border-amber-600/60 px-3 py-1.5 rounded-xl flex items-center gap-1.5 text-xs font-mono text-amber-200">
            <Sprout className="w-4 h-4 text-emerald-400" />
            <span className="font-bold">{player.resources.seeds} Seeds</span>
          </div>
          <div className="bg-[#1b1007] border border-cyan-600/60 px-3 py-1.5 rounded-xl flex items-center gap-1.5 text-xs font-mono text-cyan-200">
            <Droplets className="w-4 h-4 text-cyan-400" />
            <span className="font-bold">{player.resources.water} Water</span>
          </div>
          <div className="bg-[#1b1007] border border-purple-600/60 px-3 py-1.5 rounded-xl flex items-center gap-1.5 text-xs font-mono text-purple-200">
            <FlaskConical className="w-4 h-4 text-purple-400" />
            <span className="font-bold">{player.resources.fertilizer} Fertilizer</span>
          </div>
        </div>
      </div>

      {/* Center Stage: Camp Buildings & Garden Soil Beds matching Frame 18 & 19 */}
      <div className="relative z-10 my-4 flex-1 grid grid-cols-1 lg:grid-cols-12 gap-5 max-w-5xl mx-auto w-full">
        {/* Left Col (4): Camp Structures */}
        <div className="lg:col-span-4 bg-[#24170e]/90 border-2 border-[#855325] rounded-3xl p-5 shadow-2xl flex flex-col justify-between backdrop-blur-sm">
          <div>
            <div className="flex items-center gap-2 border-b border-[#5a3617] pb-3 mb-3">
              <Hammer className="w-4 h-4 text-amber-400" />
              <h3 className="font-serif font-black text-sm text-[#fef9c3] uppercase tracking-wider">
                CAMP BUILDINGS
              </h3>
            </div>

            <div className="space-y-3">
              {/* Explorer Tent */}
              <div className="bg-[#1b1007] p-3 rounded-2xl border border-[#523318] flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#3a2211] flex items-center justify-center text-amber-300">
                    <Home className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-serif font-bold text-xs text-[#fed7aa]">Explorer Tent</div>
                    <div className="text-[10px] text-stone-400 font-mono">Rest & daily streak booster</div>
                  </div>
                </div>
                <span className="text-[10px] font-mono bg-amber-950 text-amber-300 px-2 py-0.5 rounded-md font-bold">
                  Lv. 1
                </span>
              </div>

              {/* Map Table */}
              <div
                onClick={() => {
                  sounds.playClick();
                  onNavigate('map');
                }}
                className="cursor-pointer bg-[#1b1007] hover:bg-[#2e1b0d] p-3 rounded-2xl border border-[#523318] flex items-center justify-between transition"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#3a2211] flex items-center justify-center text-cyan-300">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-serif font-bold text-xs text-[#fed7aa]">Cartographer's Table</div>
                    <div className="text-[10px] text-stone-400 font-mono">View realm boundaries</div>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-cyan-300 font-bold">OPEN ➔</span>
              </div>

              {/* Knowledge Board */}
              <div
                onClick={() => {
                  sounds.playClick();
                  onNavigate('insights');
                }}
                className="cursor-pointer bg-[#1b1007] hover:bg-[#2e1b0d] p-3 rounded-2xl border border-[#523318] flex items-center justify-between transition"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#3a2211] flex items-center justify-center text-yellow-300">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-serif font-bold text-xs text-[#fed7aa]">Knowledge Board</div>
                    <div className="text-[10px] text-stone-400 font-mono">Review mastered topics</div>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-yellow-300 font-bold">VIEW ➔</span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-[#5a3617]">
            <button
              onClick={() => handleCampAction('upgrade_building', { building: 'camp' })}
              className="w-full py-2.5 bg-gradient-to-b from-[#b45309] to-[#78350f] hover:from-[#d97706] hover:to-[#92400e] text-[#fef9c3] rounded-xl text-xs font-serif font-bold uppercase tracking-wider border border-[#d4af37] shadow-md transition active:scale-95"
            >
              UPGRADE CAMP (+200 XP)
            </button>
          </div>
        </div>

        {/* Right Col (8): Interactive Garden Beds matching Frame 19 */}
        <div className="lg:col-span-8 bg-[#24170e]/95 border-2 border-[#855325] rounded-3xl p-5 shadow-2xl flex flex-col justify-between backdrop-blur-sm">
          <div>
            <div className="flex items-center justify-between border-b border-[#5a3617] pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Sprout className="w-5 h-5 text-emerald-400" />
                <h3 className="font-serif font-black text-sm sm:text-base text-[#fef9c3] uppercase tracking-wider">
                  SANCTUARY SOIL BEDS
                </h3>
              </div>
              <span className="text-xs font-serif text-[#fed7aa]">
                Select a plot to water, fertilize, or harvest
              </span>
            </div>

            {/* 4 Soil Beds matching Frame 19 */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {plots.map((plot, idx) => {
                const isSelected = selectedPlotIndex === idx;

                return (
                  <motion.div
                    key={plot.id || idx}
                    whileHover={{ scale: 1.04 }}
                    onClick={() => {
                      sounds.playClick();
                      setSelectedPlotIndex(idx);
                    }}
                    className={`cursor-pointer rounded-2xl p-4 border-3 flex flex-col items-center justify-between min-h-[140px] text-center transition-all ${
                      isSelected
                        ? 'bg-gradient-to-b from-[#3a2211] to-[#24150a] border-amber-300 shadow-[0_0_20px_rgba(251,191,36,0.6)]'
                        : 'bg-[#1b1007] hover:bg-[#26160a] border-[#5a3617]'
                    }`}
                  >
                    <span className="text-[10px] font-mono text-stone-400 font-bold uppercase">
                      PLOT {idx + 1}
                    </span>

                    {/* Stage icon representation */}
                    <div className="my-2">
                      {plot.stage === 'harvestable' ? (
                        <div className="w-12 h-12 rounded-full bg-emerald-900/80 border-2 border-emerald-400 flex items-center justify-center text-yellow-300 shadow-[0_0_15px_rgba(52,211,153,0.8)] animate-bounce">
                          <Sparkles className="w-6 h-6" />
                        </div>
                      ) : plot.stage === 'growing' ? (
                        <div className="w-10 h-10 rounded-full bg-[#2a4436] border border-emerald-500 flex items-center justify-center text-emerald-300">
                          <Sprout className="w-5 h-5" />
                        </div>
                      ) : plot.stage === 'sprout' ? (
                        <div className="w-8 h-8 rounded-full bg-[#1b2b23] border border-emerald-600 flex items-center justify-center text-emerald-400">
                          <Sprout className="w-4 h-4" />
                        </div>
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-[#2a1b10] border border-dashed border-stone-600 flex items-center justify-center text-stone-500">
                          <Plus className="w-4 h-4" />
                        </div>
                      )}
                    </div>

                    <div>
                      <div className="font-serif font-bold text-xs text-[#fef9c3]">
                        {plot.name}
                      </div>
                      <div className="text-[9px] font-mono text-emerald-400 capitalize">
                        {plot.stage}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Plant Action Controls */}
          {activePlant && (
            <div className="mt-5 p-4 bg-[#180e06] border border-[#523318] rounded-2xl flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="font-serif font-bold text-sm text-[#fef9c3]">
                  Selected: {activePlant.name}
                </div>
                <div className="text-xs font-serif text-[#fed7aa] flex items-center gap-3 mt-0.5">
                  <span>Water Level: {activePlant.waterLevel}/3</span>
                  <span>Fertilized: {activePlant.fertilizerApplied ? 'Yes' : 'No'}</span>
                </div>
              </div>

              {/* Action Buttons: Plant, Water, Fertilize, Harvest */}
              <div className="flex items-center gap-2">
                {activePlant.stage === 'seed' ? (
                  <button
                    disabled={player.resources.seeds <= 0 || loadingAction}
                    onClick={() => handleCampAction('plant', { plotIndex: selectedPlotIndex })}
                    className="py-2 px-3 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-xs font-serif font-bold uppercase transition flex items-center gap-1.5 shadow-md disabled:opacity-50"
                  >
                    <Sprout className="w-3.5 h-3.5" />
                    <span>PLANT SEED (-1)</span>
                  </button>
                ) : activePlant.stage === 'harvestable' ? (
                  <button
                    disabled={loadingAction}
                    onClick={() => handleCampAction('harvest', { plotIndex: selectedPlotIndex })}
                    className="py-2 px-4 bg-gradient-to-b from-amber-500 to-amber-700 hover:from-amber-400 hover:to-amber-600 text-black font-serif font-black rounded-xl text-xs uppercase tracking-wider shadow-lg transition flex items-center gap-1.5 animate-pulse"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>HARVEST (+50 XP)</span>
                  </button>
                ) : (
                  <>
                    <button
                      disabled={player.resources.water <= 0 || loadingAction}
                      onClick={() => handleCampAction('water', { plotIndex: selectedPlotIndex })}
                      className="py-2 px-3 bg-cyan-700 hover:bg-cyan-600 text-white rounded-xl text-xs font-serif font-bold uppercase transition flex items-center gap-1.5 shadow-md disabled:opacity-50"
                    >
                      <Droplets className="w-3.5 h-3.5" />
                      <span>WATER (-1)</span>
                    </button>
                    <button
                      disabled={player.resources.fertilizer <= 0 || loadingAction}
                      onClick={() => handleCampAction('fertilize', { plotIndex: selectedPlotIndex })}
                      className="py-2 px-3 bg-purple-700 hover:bg-purple-600 text-white rounded-xl text-xs font-serif font-bold uppercase transition flex items-center gap-1.5 shadow-md disabled:opacity-50"
                    >
                      <FlaskConical className="w-3.5 h-3.5" />
                      <span>FERTILIZE (-1)</span>
                    </button>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Nova Companion */}
      <div className="relative z-10 flex items-center justify-between">
        <NovaCompanion
          size="md"
          mood="speaking"
          speechBubble="Every puzzle you solve rewards you with seeds to nourish your camp and blossom new knowledge!"
        />
      </div>
    </div>
  );
};
