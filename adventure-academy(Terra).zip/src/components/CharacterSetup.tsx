import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Leaf, Compass, BookOpen, Atom, Calculator, CheckCircle2 } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { PlayerProfile, GradeLevel, MainSubject } from '../types';
import { sounds } from '../utils/soundEffects';

interface CharacterSetupProps {
  player: PlayerProfile;
  onComplete: (updated: Partial<PlayerProfile>) => void;
  onBack: () => void;
}

export const CharacterSetup: React.FC<CharacterSetupProps> = ({
  player,
  onComplete,
  onBack,
}) => {
  const [name, setName] = useState(player.name || 'Explorer Rowan');
  const [grade, setGrade] = useState<GradeLevel>(player.grade || '6-8');
  const [mainSubject, setMainSubject] = useState<MainSubject>(player.mainSubject || 'Math');

  const GRADES: { id: GradeLevel; title: string; subtitle: string }[] = [
    { id: 'K-2', title: 'Grade K-2', subtitle: 'Early Explorer' },
    { id: '3-5', title: 'Grade 3-5', subtitle: 'Junior Explorer' },
    { id: '6-8', title: 'Grade 6-8', subtitle: 'Middle Explorer' },
    { id: '9-12', title: 'Grade 9-12', subtitle: 'Advanced Scholar' },
  ];

  const SUBJECTS: { label: MainSubject; icon: any; desc: string }[] = [
    { label: 'Math', icon: Calculator, desc: 'Puzzles, Geometry & Equations' },
    { label: 'Science', icon: Atom, desc: 'Ecosystems, Forces & Biology' },
    { label: 'Language Arts', icon: BookOpen, desc: 'Etymology, Rhetoric & Verbs' },
  ];

  const handleContinue = () => {
    sounds.playSuccess();
    onComplete({
      name,
      grade,
      mainSubject,
      avatar: ASSETS.scholarExplorer,
    });
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex items-center justify-center p-4 overflow-hidden select-none">
      {/* Campfire forest background */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${ASSETS.campFire})`,
          filter: 'brightness(0.85) contrast(1.05)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-black/65 pointer-events-none" />

      {/* Main Parchment Plaque */}
      <motion.div
        initial={{ y: 25, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="relative z-10 w-full max-w-xl bg-gradient-to-b from-[#2d1c10] via-[#201309] to-[#140b04] border-4 border-[#65a30d] rounded-3xl p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.9)] text-[#f4ecd8]"
        style={{
          boxShadow: '0 25px 50px -12px rgba(0,0,0,0.95), inset 0 2px 14px rgba(163,230,53,0.25)',
        }}
      >
        {/* Ornate Leaf Trim Corners */}
        <div className="absolute -top-3 -left-3 w-7 h-7 border-t-4 border-l-4 border-[#a3e635] rounded-tl-lg" />
        <div className="absolute -top-3 -right-3 w-7 h-7 border-t-4 border-r-4 border-[#a3e635] rounded-tr-lg" />
        <div className="absolute -bottom-3 -left-3 w-7 h-7 border-b-4 border-l-4 border-[#a3e635] rounded-bl-lg" />
        <div className="absolute -bottom-3 -right-3 w-7 h-7 border-b-4 border-r-4 border-[#a3e635] rounded-br-lg" />

        {/* Header Ribbon */}
        <div className="text-center mb-5 border-b border-[#4d7c0f]/40 pb-4">
          <div className="bg-[#365314] text-[#ecfccb] font-serif font-black text-xl sm:text-2xl px-6 py-2 rounded-2xl border-2 border-[#84cc16] shadow-md inline-flex items-center gap-2 uppercase tracking-widest">
            <Leaf className="w-5 h-5 text-[#bef264]" />
            <span>CHOOSE YOUR EXPEDITION</span>
            <Leaf className="w-5 h-5 text-[#bef264]" />
          </div>
          <p className="text-xs font-serif text-[#bef264] mt-2">
            Configure your explorer identity so Terra can tune curriculum challenges to your grade and subject!
          </p>
        </div>

        {/* Explorer Identity Visual Preview */}
        <div className="flex items-center gap-4 bg-[#1b2a14]/80 p-3 rounded-2xl border-2 border-[#4d7c0f] mb-5">
          <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden border-2 border-[#a3e635] shadow-lg shrink-0">
            <img
              src={ASSETS.scholarExplorer}
              alt="Forest Scholar Explorer"
              className="w-full h-full object-cover object-top"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex-1">
            <div className="text-xs font-bold uppercase tracking-wider text-[#a3e635] flex items-center gap-1.5">
              <span>Sanctuary Forest Explorer</span>
              <CheckCircle2 className="w-3.5 h-3.5 text-lime-400" />
            </div>
            <div className="font-serif font-black text-base text-[#fef08a]">
              {name || 'Forest Explorer'}
            </div>
            <div className="text-[11px] text-[#d9f99d] font-serif">
              Guided by Terra • {grade} • {mainSubject}
            </div>
          </div>
        </div>

        {/* Form Body */}
        <div className="space-y-4">
          {/* Name Field */}
          <div>
            <label className="block text-xs font-serif font-bold uppercase tracking-wider text-[#fed7aa] mb-1">
              Explorer Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#f4ebd6] text-[#28180e] placeholder-[#855325]/60 font-serif px-4 py-2 rounded-xl border-2 border-[#855325] focus:outline-none focus:ring-2 focus:ring-lime-500 font-bold text-sm shadow-inner"
              placeholder="e.g. Explorer Rowan"
            />
          </div>

          {/* Grade Level Selector */}
          <div>
            <label className="block text-xs font-serif font-bold uppercase tracking-wider text-[#fed7aa] mb-1">
              Select Grade Level (Difficulty & Depth)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {GRADES.map((g) => (
                <button
                  key={g.id}
                  type="button"
                  onClick={() => {
                    sounds.playClick();
                    setGrade(g.id);
                  }}
                  className={`p-2.5 rounded-xl font-serif border-2 transition active:scale-95 text-center flex flex-col items-center justify-center ${
                    grade === g.id
                      ? 'bg-gradient-to-b from-[#65a30d] to-[#3f6212] text-[#fef9c3] border-[#a3e635] shadow-lg scale-105'
                      : 'bg-[#1e130a] hover:bg-[#2e1d0f] text-[#fed7aa] border-[#5a3617]'
                  }`}
                >
                  <span className="font-black text-sm uppercase">{g.title}</span>
                  <span className="text-[10px] opacity-80 mt-0.5">{g.subtitle}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Main Subject Selector */}
          <div>
            <label className="block text-xs font-serif font-bold uppercase tracking-wider text-[#fed7aa] mb-1">
              Main Subject Focus
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {SUBJECTS.map((sub) => {
                const Icon = sub.icon;
                const active = mainSubject === sub.label;
                return (
                  <button
                    key={sub.label}
                    type="button"
                    onClick={() => {
                      sounds.playClick();
                      setMainSubject(sub.label);
                    }}
                    className={`p-3 rounded-xl font-serif border-2 transition flex flex-col items-center text-center gap-1 ${
                      active
                        ? 'bg-gradient-to-b from-[#15803d] to-[#14532d] text-white border-lime-400 shadow-lg scale-105'
                        : 'bg-[#1e130a] hover:bg-[#2e1d0f] text-[#fed7aa] border-[#5a3617]'
                    }`}
                  >
                    <Icon className="w-5 h-5 text-[#a3e635]" />
                    <span className="font-bold text-xs uppercase">{sub.label}</span>
                    <span className="text-[10px] text-[#fef9c3]/70">{sub.desc}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Continue Button */}
          <div className="pt-2">
            <button
              onClick={handleContinue}
              className="w-full py-3.5 px-6 bg-gradient-to-b from-[#65a30d] via-[#4d7c0f] to-[#365314] hover:from-[#84cc16] hover:to-[#3f6212] text-[#fef9c3] font-serif font-black text-base sm:text-lg tracking-widest rounded-2xl border-2 border-[#bef264] shadow-xl transition active:scale-95 flex items-center justify-center gap-3 uppercase"
            >
              <span>ENTER THE FOREST SANCTUARY</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

