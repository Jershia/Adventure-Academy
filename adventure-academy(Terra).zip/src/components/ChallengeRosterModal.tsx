import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  BookOpen,
  CheckCircle2,
  Lock,
  Sparkles,
  Trophy,
  ArrowRight,
  Filter,
  X,
  Dices,
  Triangle,
  Shapes,
  Trees,
  Mountain,
  Flame,
  Wand2,
  RefreshCw,
  Gem,
  Waves,
  Grid,
} from 'lucide-react';
import { PlayerProfile, Quest } from '../types';
import { sounds } from '../utils/soundEffects';

interface ChallengeRosterModalProps {
  isOpen: boolean;
  onClose: () => void;
  player: PlayerProfile;
  quests: Quest[];
  onSelectChallenge: (questId: string) => void;
  onGenerateAIChallenge?: (topic: string) => void;
}

export const ChallengeRosterModal: React.FC<ChallengeRosterModalProps> = ({
  isOpen,
  onClose,
  player,
  quests,
  onSelectChallenge,
  onGenerateAIChallenge,
}) => {
  const [selectedRealm, setSelectedRealm] = useState<string>('All');
  const [isGeneratingAI, setIsGeneratingAI] = useState<boolean>(false);
  const [aiCustomQuestion, setAiCustomQuestion] = useState<{
    topic: string;
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  } | null>(null);
  const [aiSelectedOption, setAiSelectedOption] = useState<number | null>(null);

  if (!isOpen) return null;

  const REALM_TABS = [
    { id: 'All', name: 'All Realms', icon: Sparkles },
    { id: 'Algebra Grove', name: 'Algebra Grove', icon: Trees },
    { id: 'Exponent Cavern', name: 'Exponent Cavern', icon: Gem },
    { id: 'Geometry Canopy', name: 'Geometry Canopy', icon: Shapes },
    { id: 'Calculus Cascade', name: 'Calculus Cascade', icon: Waves },
    { id: 'Probability Meadow', name: 'Probability Meadow', icon: Dices },
    { id: 'Matrix Cryptography Shrine', name: 'Matrix Cryptography Shrine', icon: Grid },
    { id: 'Trigonometry Trail', name: 'Trigonometry Trail', icon: Triangle },
    { id: 'Exam Summit', name: 'Exam Summit', icon: Mountain },
  ];

  const filteredQuests = quests.filter((q) => {
    if (selectedRealm === 'All') return true;
    return q.areaId === selectedRealm;
  });

  const handleTriggerAIGenerator = async () => {
    setIsGeneratingAI(true);
    sounds.playClick();
    try {
      const topicToRequest = selectedRealm === 'All' ? 'Algebra & Geometry' : selectedRealm;
      const res = await fetch('/api/ai/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: `Generate an interactive multiple choice math puzzle about ${topicToRequest} for a student in Grade ${player.grade}. Format: Question text, 4 options, and explain the correct solution.`,
          topic: topicToRequest,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setAiCustomQuestion({
          topic: topicToRequest,
          question: `An ancient forest guardian presents a riddle in ${topicToRequest}: What is the solution to 2x + 7 = 19, and what is its geometric equivalent on a coordinate ray?`,
          options: ['x = 6 (Point at coordinate 6)', 'x = 12', 'x = 4.5', 'x = 8'],
          correctIndex: 0,
          explanation: 'Subtract 7 from both sides: 2x = 12. Then divide by 2: x = 6!',
        });
        sounds.playMagicChime();
      }
    } catch (e) {
      console.warn('AI generator fallback:', e);
      setAiCustomQuestion({
        topic: 'Algebra & Geometry Challenge',
        question: 'Solve for x in the sacred beam equation: 3(x - 2) = 15. What anchor point balances the scale?',
        options: ['x = 7 (Anchor at distance 7)', 'x = 5', 'x = 9', 'x = 3'],
        correctIndex: 0,
        explanation: 'Divide both sides by 3: x - 2 = 5. Add 2 to both sides: x = 7!',
      });
      sounds.playMagicChime();
    } finally {
      setIsGeneratingAI(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md select-none"
    >
      <motion.div
        initial={{ scale: 0.92, y: 15 }}
        animate={{ scale: 1, y: 0 }}
        className="w-full max-w-4xl max-h-[90vh] bg-gradient-to-b from-[#2e190b] via-[#211207] to-[#120904] border-4 border-[#855325] rounded-3xl p-4 sm:p-6 shadow-[0_25px_60px_rgba(0,0,0,0.9)] flex flex-col justify-between overflow-hidden"
      >
        {/* Top Header */}
        <div className="flex items-center justify-between border-b-2 border-[#5e3816] pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-950/80 border border-amber-500/80 flex items-center justify-center text-amber-300 shadow-md">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <div className="text-[10px] font-mono uppercase tracking-widest text-amber-400">
                EXPEDITION DIRECTORY
              </div>
              <h2 className="font-serif font-black text-xl sm:text-2xl text-amber-100">
                Academy Challenge Codex
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="p-2 rounded-xl bg-[#1b1007] hover:bg-[#301c0d] border border-amber-700/60 text-amber-300 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Realm Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto py-3 no-scrollbar border-b border-[#472911]">
          {REALM_TABS.map((tab) => {
            const Icon = tab.icon;
            const isSelected = selectedRealm === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  sounds.playClick();
                  setSelectedRealm(tab.id);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-serif font-bold whitespace-nowrap flex items-center gap-1.5 transition active:scale-95 border ${
                  isSelected
                    ? 'bg-amber-600 border-amber-300 text-black shadow-md'
                    : 'bg-[#1a0f07] border-[#5a3617] text-amber-200/80 hover:bg-[#2b190c]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.name}</span>
              </button>
            );
          })}
        </div>

        {/* AI Forge Banner */}
        <div className="my-2.5 p-3 rounded-2xl bg-gradient-to-r from-purple-950/70 via-[#271438] to-indigo-950/70 border-2 border-purple-500/50 flex flex-wrap items-center justify-between gap-2 shadow-inner">
          <div className="flex items-center gap-2.5">
            <Wand2 className="w-5 h-5 text-purple-300 animate-pulse shrink-0" />
            <div>
              <div className="text-xs font-serif font-bold text-purple-100">
                ✨ Nova Forge: Adaptive Challenge Generator
              </div>
              <div className="text-[11px] font-sans text-purple-200/70">
                Generate an infinite personalized puzzle tailored to your Grade ({player.grade}) and current topic mastery.
              </div>
            </div>
          </div>

          <button
            onClick={handleTriggerAIGenerator}
            disabled={isGeneratingAI}
            className="px-3.5 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-serif font-bold text-xs rounded-xl shadow-md transition active:scale-95 flex items-center gap-1.5 shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isGeneratingAI ? 'animate-spin' : ''}`} />
            <span>{isGeneratingAI ? 'Forging...' : 'Forge Challenge'}</span>
          </button>
        </div>

        {/* AI Challenge Panel if Active */}
        {aiCustomQuestion && (
          <div className="mb-3 p-3.5 rounded-2xl bg-[#190d24] border-2 border-purple-400 shadow-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-mono text-purple-300 uppercase tracking-wider">
                Nova AI Forge • {aiCustomQuestion.topic}
              </span>
              <button
                onClick={() => setAiCustomQuestion(null)}
                className="text-xs text-purple-300 hover:text-purple-100 font-mono"
              >
                [Dismiss]
              </button>
            </div>
            <div className="text-xs sm:text-sm font-serif font-bold text-purple-100 mb-3">
              {aiCustomQuestion.question}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-2">
              {aiCustomQuestion.options.map((opt, idx) => {
                const isCorrect = idx === aiCustomQuestion.correctIndex;
                const isSelected = aiSelectedOption === idx;
                return (
                  <button
                    key={idx}
                    onClick={() => {
                      setAiSelectedOption(idx);
                      if (isCorrect) {
                        sounds.playSuccess();
                        sounds.playMagicChime();
                      } else {
                        sounds.playError();
                      }
                    }}
                    className={`p-2.5 rounded-xl border text-xs font-serif font-bold text-left transition ${
                      isSelected
                        ? isCorrect
                          ? 'bg-emerald-950 border-emerald-400 text-emerald-100'
                          : 'bg-red-950 border-red-400 text-red-100'
                        : 'bg-[#2a173d] hover:bg-[#381f52] border-purple-600/60 text-purple-100'
                    }`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
            {aiSelectedOption !== null && (
              <div className="text-xs font-serif text-purple-200 mt-2 bg-[#12071a] p-2 rounded-lg border border-purple-800">
                {aiSelectedOption === aiCustomQuestion.correctIndex ? (
                  <span className="text-emerald-300 font-bold">✓ Correct! {aiCustomQuestion.explanation}</span>
                ) : (
                  <span className="text-red-300">Try again: remember to isolate the variable step-by-step!</span>
                )}
              </div>
            )}
          </div>
        )}

        {/* Challenges Scrollable List */}
        <div className="flex-1 overflow-y-auto max-h-[45vh] pr-1.5 space-y-2.5 my-2">
          {filteredQuests.map((quest) => {
            const isCompleted = quest.completed || player.completedQuests.includes(quest.id);

            return (
              <div
                key={quest.id}
                className="bg-[#190e06] hover:bg-[#251509] border-2 border-[#5a3617] rounded-2xl p-3.5 transition shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                {/* Left Info */}
                <div className="flex items-start gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
                      isCompleted
                        ? 'bg-emerald-950/80 border-emerald-500 text-emerald-400'
                        : 'bg-[#2d1b0d] border-amber-600/70 text-amber-300'
                    }`}
                  >
                    {isCompleted ? <CheckCircle2 className="w-5 h-5" /> : <Sparkles className="w-5 h-5" />}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 bg-[#2d1b0d] px-2 py-0.5 rounded border border-[#5a3617]">
                        {quest.areaId || 'Realm Quest'}
                      </span>
                      {quest.difficulty && (
                        <span className="text-[10px] font-mono text-emerald-300 uppercase">
                          • {quest.difficulty}
                        </span>
                      )}
                    </div>
                    <div className="font-serif font-black text-sm sm:text-base text-[#fef08a] mt-0.5">
                      {quest.title}
                    </div>
                    <div className="text-xs text-amber-200/70 font-sans line-clamp-1">
                      {quest.description || quest.learningConcept}
                    </div>
                  </div>
                </div>

                {/* Right Rewards & Play Button */}
                <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#38200d]">
                  {/* Rewards Chips */}
                  <div className="flex items-center gap-1.5 text-[11px] font-mono text-amber-200/90 bg-[#120803] px-2.5 py-1 rounded-xl border border-amber-800/60">
                    <span className="text-yellow-400 font-bold">+{quest.rewardXp || 100} XP</span>
                    <span>•</span>
                    <span className="text-emerald-400">+{quest.rewardSeeds || 3} Seeds</span>
                  </div>

                  <button
                    onClick={() => {
                      sounds.playClick();
                      onSelectChallenge(quest.id);
                      onClose();
                    }}
                    className="px-4 py-2 bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-black font-serif font-black text-xs rounded-xl shadow-md active:scale-95 transition flex items-center gap-1.5"
                  >
                    <span>{isCompleted ? 'Replay' : 'Play'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="border-t border-[#4a2b13] pt-3 flex items-center justify-between text-xs text-amber-200/70 font-mono">
          <div>Total Available Challenges: {quests.length}</div>
          <div className="text-emerald-400 font-bold">
            Completed: {quests.filter((q) => q.completed || player.completedQuests.includes(q.id)).length} / {quests.length}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};
