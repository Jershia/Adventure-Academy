export { TerraDialogueModal, NovaDialogueModal, default } from './TerraDialogueModal';
export type { TerraDialogueModalProps, TerraDialogueModalProps as NovaDialogueModalProps } from './TerraDialogueModal';
