import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { Sparkles, Trophy, ArrowRight, CheckCircle2, RotateCcw, Leaf, BookOpen } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { TerraCompanion } from './TerraCompanion';
import { TerraDialogueModal } from './TerraDialogueModal';
import { PlayerProfile } from '../types';
import { sounds } from '../utils/soundEffects';
import { getBridgeCurriculum } from '../data/curriculumData';

interface BridgeQuestProps {
  player: PlayerProfile;
  onCompleteQuest: (rewards: { xp: number; seeds: number; water: number; fertilizer: number }) => void;
  onNextQuest?: () => void;
}

export const BridgeQuest: React.FC<BridgeQuestProps> = ({
  player,
  onCompleteQuest,
  onNextQuest,
}) => {
  const [problemIndex, setProblemIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isRepaired, setIsRepaired] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [showTerraModal, setShowTerraModal] = useState(false);

  // Load grade- and subject-aligned problems
  const problems = useMemo(() => {
    return getBridgeCurriculum(player.grade, player.mainSubject);
  }, [player.grade, player.mainSubject]);

  const currentProblem = problems[problemIndex] || problems[0];

  const handleSelectOption = (optionText: string, correct: boolean) => {
    setSelectedAnswer(optionText);
    if (correct) {
      sounds.playSuccess();
      sounds.playMagicChime();
      setIsRepaired(true);

      // Trigger festive forest confetti
      confetti({
        particleCount: 85,
        spread: 75,
        origin: { y: 0.6 },
        colors: ['#a3e635', '#4ade80', '#facc15', '#38bdf8'],
      });

      setTimeout(() => {
        setShowCelebration(true);
        onCompleteQuest({
          xp: 120,
          seeds: 4,
          water: 2,
          fertilizer: 2,
        });
      }, 1200);
    } else {
      sounds.playError();
      setShowTerraModal(true);
    }
  };

  const handleReset = () => {
    setSelectedAnswer(null);
    setIsRepaired(false);
    setShowCelebration(false);
  };

  const handleNextProblem = () => {
    handleReset();
    setProblemIndex((prev) => (prev + 1) % problems.length);
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex flex-col justify-between p-3 sm:p-6 overflow-hidden select-none">
      {/* Rushing River & Wooden Bridge Background */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-all duration-1000"
        style={{
          backgroundImage: `url(${ASSETS.forestPath})`,
          filter: isRepaired ? 'brightness(1.05) contrast(1.1)' : 'brightness(0.9) contrast(1.0)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-black/60 pointer-events-none" />

      {/* Quest Banner Header */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-2 bg-[#1b2615]/90 border-2 border-[#4d7c0f] px-4 sm:px-5 py-2.5 rounded-2xl shadow-xl backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#4d7c0f] text-[#ecfccb] text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider flex items-center gap-1">
              <Leaf className="w-3 h-3 text-[#bef264]" />
              <span>QUEST 01</span>
            </span>
            <h2 className="font-serif font-black text-sm sm:text-base text-[#fef9c3] uppercase tracking-wider">
              {currentProblem.title}
            </h2>
          </div>
          <p className="text-xs font-serif text-[#d9f99d] mt-0.5">
            Grade: <strong className="text-white">{player.grade}</strong> • Subject: <strong className="text-white">{player.mainSubject}</strong> • Topic: <strong className="text-[#fef08a]">{currentProblem.topic}</strong>
          </p>
        </div>

        <div className="flex items-center gap-2">
          {problems.length > 1 && (
            <button
              onClick={handleNextProblem}
              className="px-2.5 py-1.5 bg-[#2d4a1d] hover:bg-[#365314] text-[#ecfccb] rounded-xl border border-[#65a30d] text-xs font-serif transition flex items-center gap-1"
              title="Next challenge at this grade level"
            >
              <BookOpen className="w-3.5 h-3.5 text-[#bef264]" />
              <span>Next Timber ({problemIndex + 1}/{problems.length})</span>
            </button>
          )}
          <button
            onClick={handleReset}
            className="p-2 bg-[#2d4a1d] hover:bg-[#365314] text-[#ecfccb] rounded-xl border border-[#65a30d] transition"
            title="Reset Problem Attempt"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Center Stage: Suspended Wooden Chalkboard Sign & River Bridge */}
      <div className="relative z-10 my-4 flex-1 flex flex-col items-center justify-center max-w-4xl mx-auto w-full">
        {/* Suspended Wooden Chalkboard Sign */}
        <motion.div
          key={currentProblem.id}
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="relative max-w-lg w-full bg-gradient-to-b from-[#2d1c10] via-[#201309] to-[#140b04] border-4 border-[#65a30d] rounded-3xl p-6 shadow-[0_20px_50px_rgba(0,0,0,0.95)] text-center text-[#f4ecd8] mb-6"
          style={{
            boxShadow: '0 25px 50px -12px rgba(0,0,0,0.95), inset 0 2px 12px rgba(163,230,53,0.2)',
          }}
        >
          {/* Hanging Chains from Top */}
          <div className="absolute -top-6 left-12 w-2 h-6 border-x-2 border-stone-400 bg-stone-700" />
          <div className="absolute -top-6 right-12 w-2 h-6 border-x-2 border-stone-400 bg-stone-700" />

          {/* Slate Surface */}
          <div className="bg-[#142316] border-2 border-[#365314] rounded-2xl p-5 shadow-inner">
            <div className="font-serif font-black text-xl sm:text-2xl text-yellow-200 tracking-wider">
              {currentProblem.prompt}
            </div>
            <div className="font-serif text-sm text-[#cbd5e1] mt-2 italic">
              {currentProblem.subtext}
            </div>
          </div>
        </motion.div>

        {/* Bridge Visualization with Magic Spores & Planks */}
        <div className="relative w-full max-w-lg h-32 sm:h-40 rounded-2xl bg-gradient-to-b from-[#142617]/80 to-[#0c180e]/95 border-2 border-[#3f6212] flex items-center justify-center p-4 shadow-2xl overflow-hidden mb-6">
          {/* Rushing Blue/Emerald River Water Graphic */}
          <div className="absolute inset-0 bg-gradient-to-r from-teal-900/40 via-emerald-700/30 to-blue-900/40 opacity-80" />

          {/* Wooden Bridge Planks */}
          <div className="relative z-10 flex items-center gap-2 sm:gap-3">
            {[1, 2, 3, 4, 5, 6].map((plank) => {
              const broken = !isRepaired && (plank === 3 || plank === 4);
              return (
                <motion.div
                  key={plank}
                  animate={{
                    y: broken ? [0, 4, 0] : 0,
                    rotate: broken ? [0, -3, 0] : 0,
                  }}
                  className={`w-10 sm:w-14 h-20 sm:h-24 rounded-lg border-2 shadow-lg flex items-center justify-center transition-all duration-700 ${
                    broken
                      ? 'bg-[#3b2313] border-[#5a3617] opacity-60 translate-y-3'
                      : isRepaired
                      ? 'bg-gradient-to-b from-[#65a30d] to-[#365314] border-lime-300 shadow-[0_0_18px_rgba(163,230,53,0.7)]'
                      : 'bg-[#683f1d] border-[#8e5c2b]'
                  }`}
                >
                  {isRepaired && (
                    <Sparkles className="w-4 h-4 text-lime-200 animate-spin" style={{ animationDuration: '4s' }} />
                  )}
                </motion.div>
              );
            })}
          </div>

          {/* Glowing Green/Gold Magic Energy Spores */}
          {isRepaired && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-52 h-16 bg-lime-400/25 rounded-full blur-xl animate-pulse" />
            </div>
          )}
        </div>

        {/* 4 Wooden Sign Choices on Signposts */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 w-full max-w-2xl">
          {currentProblem.options.map((opt) => {
            const isSelected = selectedAnswer === opt.text;
            return (
              <button
                key={opt.text}
                onClick={() => handleSelectOption(opt.text, opt.correct)}
                className={`py-3.5 px-3 rounded-2xl font-serif font-black text-sm sm:text-base border-2 transition-all active:scale-95 shadow-xl flex items-center justify-center text-center ${
                  isSelected && opt.correct
                    ? 'bg-gradient-to-b from-[#15803d] to-[#14532d] text-[#fef9c3] border-lime-400 shadow-[0_0_20px_rgba(74,222,128,0.7)] scale-105'
                    : isSelected && !opt.correct
                    ? 'bg-gradient-to-b from-[#991b1b] to-[#7f1d1d] text-white border-red-400'
                    : 'bg-gradient-to-b from-[#2e1c10] to-[#1e120a] hover:from-[#3e2717] hover:to-[#2b180d] text-[#fed7aa] border-[#5a3617]'
                }`}
              >
                <span>{opt.text}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Explorer and Terra Companion at Riverbank */}
      <div className="relative z-10 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <TerraCompanion
            size="md"
            mood={isRepaired ? 'excited' : 'speaking'}
            speechBubble={
              isRepaired
                ? `Brilliant work, Explorer! The bridge timbers locked into place with ${currentProblem.topic} wisdom!`
                : `Terra whispers: "Examine the timber problem carefully: ${currentProblem.topic} (${player.grade} Level)"`
            }
          />
        </div>
      </div>

      {/* Quest Complete Celebration Banner */}
      <AnimatePresence>
        {showCelebration && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.8, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              className="relative w-full max-w-lg bg-gradient-to-b from-[#203316] via-[#16240f] to-[#0c1408] border-4 border-[#84cc16] rounded-3xl p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.95)] text-center text-[#f4ecd8]"
              style={{
                boxShadow: '0 0 50px rgba(132,204,22,0.45), inset 0 2px 12px rgba(255,255,255,0.2)',
              }}
            >
              {/* Golden Foliage Graphic */}
              <div className="w-16 h-16 rounded-full bg-gradient-to-b from-lime-400 to-emerald-600 border-2 border-lime-200 mx-auto flex items-center justify-center shadow-lg mb-3">
                <Trophy className="w-9 h-9 text-[#052e16]" />
              </div>

              {/* QUEST COMPLETE! Title */}
              <h2 className="font-serif font-black text-2xl sm:text-3xl text-yellow-200 uppercase tracking-widest drop-shadow-md">
                BRIDGE RESTORED!
              </h2>

              <p className="font-serif text-sm text-[#d9f99d] mt-1">
                {currentProblem.topic} mastered for {player.grade} {player.mainSubject}!
              </p>

              {/* Rewards List */}
              <div className="my-4 p-3 bg-[#0d1c0e]/80 rounded-xl border border-[#4d7c0f] font-mono text-xs sm:text-sm text-lime-300 font-bold">
                +120 XP | +4 Seeds | +2 Water | +2 Fertilizer
              </div>

              {/* Explanation of correct answer */}
              <div className="bg-[#142316] border border-[#365314] rounded-xl p-3 mb-5 text-left text-xs font-serif text-[#fef9c3]">
                <div className="font-bold text-[#bef264] uppercase mb-1 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-lime-400" />
                  <span>Terra's Key Insight:</span>
                </div>
                {currentProblem.explanation}
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setShowCelebration(false)}
                  className="py-3 px-4 bg-[#233816] hover:bg-[#2e4a1d] text-[#d9f99d] border-2 border-[#4d7c0f] rounded-xl text-xs font-serif font-bold uppercase transition"
                >
                  STAY AT BRIDGE
                </button>

                <button
                  onClick={() => {
                    sounds.playSuccess();
                    setShowCelebration(false);
                    if (onNextQuest) onNextQuest();
                  }}
                  className="py-3 px-4 bg-gradient-to-b from-[#65a30d] to-[#365314] hover:from-[#84cc16] hover:to-[#3f6212] text-[#fef9c3] border-2 border-lime-300 rounded-xl text-xs font-serif font-bold uppercase tracking-wider shadow-lg transition flex items-center justify-center gap-1.5"
                >
                  <span>NEXT QUEST</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Terra AI Assistance Dialogue Modal for mistakes */}
      <TerraDialogueModal
        isOpen={showTerraModal}
        onClose={() => setShowTerraModal(false)}
        problemContext={{
          question: currentProblem.prompt,
          topic: currentProblem.topic,
          currentInput: selectedAnswer || '',
          grade: player.grade,
          subject: player.mainSubject,
        }}
        onTryAgain={() => {
          setSelectedAnswer(null);
          setShowTerraModal(false);
        }}
      />
    </div>
  );
};

