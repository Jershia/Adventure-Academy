import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Play, UserPlus, KeyRound, Sparkles, ArrowLeft, X } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { NovaCompanion } from './NovaCompanion';
import { PlayerProfile } from '../types';
import { sounds } from '../utils/soundEffects';

interface LoginModalProps {
  onSuccess: (profile: PlayerProfile) => void;
  onBack: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ onSuccess, onBack }) => {
  const [email, setEmail] = useState('scholar@academy.org');
  const [password, setPassword] = useState('passcode123');
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('Scholar Ash');
  const [loading, setLoading] = useState(false);
  const [showForgotNotice, setShowForgotNotice] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    sounds.playClick();
    setLoading(true);

    const endpoint = isRegister ? '/api/auth/register' : '/api/auth/login';
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, name }),
      });
      const data = await res.json();
      if (data.profile) {
        sounds.playSuccess();
        onSuccess(data.profile);
      }
    } catch (err) {
      // Offline fallback
      sounds.playSuccess();
      onSuccess({
        id: 'explorer-1',
        name: name || 'Scholar Ash',
        email,
        grade: '6-8',
        mainSubject: 'Math',
        level: 1,
        xp: 120,
        xpToNextLevel: 500,
        streakDays: 5,
        resources: { seeds: 6, water: 5, fertilizer: 3 },
        unlockedAreas: ['Algebra Grove'],
        currentArea: 'Algebra Grove',
        completedQuests: [],
        skillMastery: { 'Quadratic Equations': 78 },
        learningStats: {
          visualSpeedScore: 80,
          textSpeedScore: 50,
          visualChallengesSolved: 14,
          textChallengesSolved: 6,
          accuracyRate: 88,
          totalAttempts: 22,
          hintsRequested: 4,
          strongTopics: ['Algebra'],
          developingTopics: ['Graph Interpretation'],
          recommendedPath: 'visual',
        },
        camp: {
          level: 2,
          buildings: {
            mapTable: { built: true, level: 1 },
            knowledgeBoard: { built: true, level: 1 },
            explorerTent: { built: true, level: 1 },
            plantBed: { built: true, level: 1, plantsCount: 2 },
          },
          plants: [],
        },
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = () => {
    sounds.playClick();
    setEmail('scholar.google@academy.org');
    setName('Scholar Orion');
    handleSubmit({ preventDefault: () => {} } as any);
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex items-center justify-center p-4 overflow-hidden select-none">
      {/* Painted Forest Background with wooden fence and mossy logs */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${ASSETS.forestPath})`,
          filter: 'brightness(0.85) contrast(1.1)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/60 pointer-events-none" />

      {/* Back button */}
      <button
        onClick={() => {
          sounds.playClick();
          onBack();
        }}
        className="absolute top-6 left-6 z-20 flex items-center gap-2 bg-[#2a1b10]/90 hover:bg-[#3d2717] text-[#fef08a] border-2 border-[#855325] px-3.5 py-2 rounded-xl text-xs font-serif font-bold transition shadow-xl"
      >
        <ArrowLeft className="w-4 h-4" />
        BACK TO TITLE
      </button>

      {/* Floating Nova in the background clearing */}
      <div className="hidden lg:block absolute left-16 top-1/3 z-10">
        <NovaCompanion
          size="md"
          mood="speaking"
          speechBubble="Welcome back, Scholar! Your journal and tools are waiting."
        />
      </div>

      {/* Center Wood-Framed Billboard Form (Matching Image 4) */}
      <motion.div
        initial={{ scale: 0.95, opacity: 0, y: 15 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        className="relative z-10 w-full max-w-xl bg-gradient-to-b from-[#3a2413] via-[#2a190c] to-[#1a0f07] border-4 border-[#855325] rounded-3xl p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.9)] text-[#f4ecd8]"
        style={{
          boxShadow: '0 25px 50px -12px rgba(0,0,0,0.9), inset 0 2px 8px rgba(255,255,255,0.15)',
        }}
      >
        {/* Ornate Golden Trim Corners */}
        <div className="absolute -top-3 -left-3 w-7 h-7 border-t-4 border-l-4 border-[#d4af37] rounded-tl-lg" />
        <div className="absolute -top-3 -right-3 w-7 h-7 border-t-4 border-r-4 border-[#d4af37] rounded-tr-lg" />
        <div className="absolute -bottom-3 -left-3 w-7 h-7 border-b-4 border-l-4 border-[#d4af37] rounded-bl-lg" />
        <div className="absolute -bottom-3 -right-3 w-7 h-7 border-b-4 border-r-4 border-[#d4af37] rounded-br-lg" />

        {/* Board Header plaque */}
        <div className="text-center mb-6 border-b border-[#5a3617] pb-4">
          <div className="bg-[#523318] text-[#fef9c3] font-serif font-black text-xl sm:text-2xl px-6 py-2 rounded-xl border-2 border-[#855325] shadow-md inline-block uppercase tracking-widest">
            ADVENTURE ACADEMY
          </div>

          <div className="mt-3 bg-[#f6ebd5] text-[#2c1a0e] font-serif font-bold text-sm sm:text-base py-1.5 px-4 rounded-lg border border-[#8e693b] shadow-inner inline-block">
            {isRegister ? 'CREATE EXPLORER CREDENTIALS' : 'WELCOME BACK, EXPLORER!'}
          </div>
        </div>

        {/* Form Inputs */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegister && (
            <div>
              <label className="block text-xs font-serif font-bold uppercase tracking-wider text-[#fed7aa] mb-1">
                Explorer Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full bg-[#f4ebd6] text-[#28180e] placeholder-[#855325]/60 font-serif px-4 py-2.5 rounded-xl border-2 border-[#855325] focus:outline-none focus:ring-2 focus:ring-amber-500 font-semibold text-sm shadow-inner"
                placeholder="e.g. Scholar Lin"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-serif font-bold uppercase tracking-wider text-[#fed7aa] mb-1">
              Explorer Email / Username
            </label>
            <input
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full bg-[#f4ebd6] text-[#28180e] placeholder-[#855325]/60 font-mono px-4 py-2.5 rounded-xl border-2 border-[#855325] focus:outline-none focus:ring-2 focus:ring-amber-500 font-semibold text-sm shadow-inner"
              placeholder="scholar@academy.org"
            />
          </div>

          <div>
            <label className="block text-xs font-serif font-bold uppercase tracking-wider text-[#fed7aa] mb-1">
              Secret Passcode
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full bg-[#f4ebd6] text-[#28180e] placeholder-[#855325]/60 font-mono px-4 py-2.5 rounded-xl border-2 border-[#855325] focus:outline-none focus:ring-2 focus:ring-amber-500 font-semibold text-sm shadow-inner"
              placeholder="••••••••"
            />
          </div>

          {/* Buttons: Green Enter Game, Brown Create Account, Google */}
          <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Green ENTER GAME button */}
            <button
              type="submit"
              disabled={loading}
              className="py-3 px-4 bg-gradient-to-b from-[#15803d] to-[#14532d] hover:from-[#16a34a] hover:to-[#15803d] text-[#fef9c3] font-serif font-bold text-sm tracking-wider uppercase rounded-xl border-2 border-emerald-400 shadow-lg transition active:scale-95 flex items-center justify-center gap-2"
            >
              <Play className="w-4 h-4 fill-[#fef9c3]" />
              {isRegister ? 'REGISTER & ENTER' : 'ENTER GAME'}
            </button>

            {/* Brown CREATE NEW ACCOUNT button */}
            <button
              type="button"
              onClick={() => {
                sounds.playClick();
                setIsRegister(!isRegister);
              }}
              className="py-3 px-4 bg-gradient-to-b from-[#5c3717] to-[#3a210c] hover:from-[#6e421c] hover:to-[#45270e] text-[#fed7aa] font-serif font-bold text-sm tracking-wider uppercase rounded-xl border-2 border-[#855325] shadow-lg transition active:scale-95 flex items-center justify-center gap-2"
            >
              <UserPlus className="w-4 h-4 text-amber-400" />
              {isRegister ? 'EXISTING ACCOUNT' : 'CREATE NEW ACCOUNT'}
            </button>
          </div>

          {/* SIGN IN WITH GOOGLE button */}
          <button
            type="button"
            onClick={handleGoogleSignIn}
            className="w-full py-2.5 px-4 bg-[#f8f5ee] hover:bg-white text-[#2a1a0f] font-serif font-bold text-xs tracking-wider uppercase rounded-xl border-2 border-[#855325] shadow-md transition active:scale-95 flex items-center justify-center gap-2"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
              />
              <path
                fill="#34A853"
                d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.35 24 12 24z"
              />
              <path
                fill="#FBBC05"
                d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
              />
              <path
                fill="#EA4335"
                d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
              />
            </svg>
            SIGN IN WITH GOOGLE
          </button>
        </form>

        {/* Wooden Post Sign: FORGOT PASSCODE? */}
        <div className="mt-5 text-center">
          <button
            onClick={() => {
              sounds.playClick();
              setShowForgotNotice(true);
            }}
            className="inline-block bg-[#422913] hover:bg-[#523418] text-[#fef08a] px-4 py-1.5 rounded-lg border border-[#855325] text-xs font-serif font-bold uppercase tracking-wider transition shadow-sm"
          >
            FORGOT PASSCODE?
          </button>
        </div>

        {showForgotNotice && (
          <div className="mt-3 p-3 bg-[#1e1208] border border-amber-600/40 rounded-xl text-xs text-amber-200 text-center font-serif">
            Expedition passcodes are stored securely. Since this is an educational academy, your default passcode is prefilled as <span className="font-mono font-bold text-white">passcode123</span>!
          </div>
        )}
      </motion.div>
    </div>
  );
};
