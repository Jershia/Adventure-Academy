import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Compass,
  Lock,
  Trees,
  Sprout,
  Leaf,
  Gem,
  Flame,
  Triangle,
  Waves,
  Droplets,
  Dices,
  Dna,
  Grid,
  Atom,
  Mountain,
  Sun,
  BookOpen,
  Scroll,
  Music,
  Feather,
  Shield,
  Eye,
  Award,
  Sparkles,
  Play,
  ArrowLeft,
  Check,
  MapPin,
  BookMarked,
} from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { PlayerProfile, MainSubject } from '../types';
import { SUBJECT_MAPS, MapRegionNode } from '../data/mapData';
import { sounds } from '../utils/soundEffects';

interface WorldMapProps {
  player: PlayerProfile;
  onSelectArea: (areaId: string, targetScreen?: string, subject?: MainSubject) => void;
  onBack: () => void;
  onUpdateSubject?: (newSubject: MainSubject) => void;
}

const ICON_MAP: Record<string, React.FC<{ className?: string }>> = {
  Trees,
  Sprout,
  Leaf,
  Gem,
  Flame,
  Shapes: Triangle,
  Triangle,
  Waves,
  Droplets,
  Dices,
  Dna,
  Grid,
  Atom,
  Mountain,
  Sun,
  BookOpen,
  Scroll,
  Music,
  Feather,
  Shield,
  Eye,
  Award,
  Sparkles,
};

export const WorldMap: React.FC<WorldMapProps> = ({
  player,
  onSelectArea,
  onBack,
  onUpdateSubject,
}) => {
  // Start with player's active subject
  const [activeSubject, setActiveSubject] = useState<MainSubject>(player.mainSubject || 'Math');
  const [selectedNode, setSelectedNode] = useState<MapRegionNode | null>(null);

  const currentMap = SUBJECT_MAPS[activeSubject] || SUBJECT_MAPS.Math;

  // Background map asset according to subject
  const mapBackgroundUrl =
    activeSubject === 'Science'
      ? ASSETS.scienceMap
      : activeSubject === 'Language Arts'
      ? ASSETS.literatureMap
      : ASSETS.mathMap;

  // Sync active subject if player profile updates
  useEffect(() => {
    if (player.mainSubject && !selectedNode) {
      setActiveSubject(player.mainSubject);
    }
  }, [player.mainSubject]);

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex items-center justify-center p-2 sm:p-5 overflow-hidden select-none">
      {/* Dynamic Hand-Painted Subject Map Background */}
      <motion.div
        key={activeSubject}
        initial={{ opacity: 0, scale: 1.02 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6 }}
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${mapBackgroundUrl})`,
          filter: 'brightness(0.92) contrast(1.08)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-black/60 pointer-events-none" />

      {/* Main Map Parchment Board Frame */}
      <div className="relative z-10 w-full max-w-5xl h-[86vh] min-h-[600px] bg-[#dfcca7]/85 backdrop-blur-sm border-4 sm:border-8 border-[#5e3b1f] rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col justify-between p-3 sm:p-5">
        
        {/* Top Parchment Map Navigation & Subject Switcher Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b-2 border-[#855325]/70 pb-3">
          
          {/* Title & Explorer Location */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#3a2211] border-2 border-[#d4af37] flex items-center justify-center text-amber-300 shadow-md">
              <Compass className="w-6 h-6 animate-spin" style={{ animationDuration: '24s' }} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-serif font-black text-lg sm:text-xl text-[#361e0d] tracking-wider uppercase drop-shadow-sm">
                  {currentMap.title}
                </h2>
                <span className="text-xs px-2 py-0.5 rounded-md font-mono font-bold bg-[#3a2211] text-amber-300 border border-[#855325]">
                  Grade {player.grade}
                </span>
              </div>
              <p className="text-xs font-serif font-bold text-[#6a3f18] flex items-center gap-1.5 mt-0.5">
                <MapPin className="w-3.5 h-3.5 text-amber-700" />
                <span>Zone: <strong className="text-[#361e0d]">{player.currentArea || currentMap.nodes[0].name}</strong></span>
                <span className="text-[#855325]">•</span>
                <span className="text-[11px] font-sans text-stone-700 font-semibold">{currentMap.subtitle}</span>
              </p>
            </div>
          </div>

          {/* Subject Switcher Tabs */}
          <div className="flex items-center gap-1.5 bg-[#25150a]/95 border-2 border-[#855325] rounded-2xl p-1 shadow-inner self-start sm:self-auto">
            {(['Math', 'Science', 'Language Arts'] as MainSubject[]).map((subj) => {
              const isSelected = activeSubject === subj;
              const isPlayerActive = player.mainSubject === subj;
              const icon = subj === 'Math' ? '📐' : subj === 'Science' ? '🌿' : '📜';
              const label = subj === 'Language Arts' ? 'Language' : subj;

              return (
                <button
                  key={subj}
                  onClick={() => {
                    sounds.playClick();
                    setActiveSubject(subj);
                    setSelectedNode(null);
                  }}
                  className={`relative px-2.5 sm:px-3.5 py-1.5 rounded-xl text-xs font-serif font-bold uppercase transition flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-gradient-to-b from-[#854d0e] to-[#451f04] text-[#fef9c3] border border-amber-300/80 shadow-md transform scale-[1.02]'
                      : 'text-[#fed7aa] hover:text-white hover:bg-[#3a2211]'
                  }`}
                >
                  <span className="text-sm">{icon}</span>
                  <span className="tracking-wider">{label} Map</span>
                  {isPlayerActive && (
                    <span
                      className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.9)]"
                      title="Current Player Subject"
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Map Interactive Canvas / Nodes & Dotted Paths */}
        <div className="relative flex-1 w-full h-full my-1 overflow-hidden">
          {/* Vintage Nautical / Cartographer Compass Rose */}
          <div className="absolute top-2 right-3 w-16 h-16 sm:w-20 sm:h-20 opacity-40 pointer-events-none">
            <svg viewBox="0 0 100 100" fill="none">
              <circle cx="50" cy="50" r="46" stroke="#4a2c14" strokeWidth="1.5" strokeDasharray="3 3" />
              <polygon points="50,8 57,43 50,50 43,43" fill="#4a2c14" />
              <polygon points="50,92 57,57 50,50 43,57" fill="#784419" />
              <polygon points="92,50 57,57 50,50 57,43" fill="#784419" />
              <polygon points="8,50 43,57 50,50 43,43" fill="#4a2c14" />
              <circle cx="50" cy="50" r="5" fill="#fef08a" stroke="#4a2c14" strokeWidth="1.5" />
              <text x="46" y="6" fontSize="9" fontWeight="bold" fill="#3a2211">N</text>
            </svg>
          </div>

          {/* Dotted Expedition Trail Lines connecting map regions */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
            {/* Trail from Node 1 to Node 3 to Node 4 to Node 8 */}
            <path
              d="M 220 340 Q 320 280 430 220 T 660 110"
              fill="none"
              stroke="#543114"
              strokeWidth="2.5"
              strokeDasharray="6 6"
              opacity="0.55"
            />
            {/* Trail from Node 2 to Node 5 to Node 6 */}
            <path
              d="M 300 420 Q 500 420 660 410 T 840 370"
              fill="none"
              stroke="#543114"
              strokeWidth="2.5"
              strokeDasharray="6 6"
              opacity="0.55"
            />
            {/* Trail from Node 6 to Node 7 to Node 8 */}
            <path
              d="M 840 370 Q 820 280 810 210 T 660 110"
              fill="none"
              stroke="#543114"
              strokeWidth="2.5"
              strokeDasharray="6 6"
              opacity="0.55"
            />
          </svg>

          {/* Interactive Subject Map Nodes */}
          {currentMap.nodes.map((node) => {
            const isUnlocked =
              player.unlockedAreas.includes(node.id) ||
              player.level >= node.requiredLevel ||
              node.requiredLevel === 1;

            const isCurrent = player.currentArea === node.id;
            const isSelected = selectedNode?.id === node.id;
            const NodeIcon = ICON_MAP[node.iconName] || Compass;

            return (
              <motion.div
                key={node.id}
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => {
                  sounds.playClick();
                  setSelectedNode(node);
                }}
                className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10"
                style={{
                  left: `${node.xPercent}%`,
                  top: `${node.yPercent}%`,
                }}
              >
                <div
                  className={`relative p-2 sm:p-2.5 rounded-2xl border-2 sm:border-3 transition-all shadow-xl flex flex-col items-center gap-1 ${
                    isSelected
                      ? 'bg-gradient-to-b from-[#1b4332] to-[#081c15] text-emerald-200 border-emerald-400 shadow-[0_0_25px_rgba(52,211,153,0.8)]'
                      : isCurrent
                      ? 'bg-gradient-to-b from-[#854d0e] to-[#451f04] text-amber-200 border-amber-300 shadow-[0_0_20px_rgba(251,191,36,0.8)]'
                      : isUnlocked
                      ? 'bg-gradient-to-b from-[#3a2211] to-[#201107] text-[#fed7aa] border-[#8e693b]'
                      : 'bg-[#221309]/90 text-stone-400 border-stone-600 opacity-75'
                  }`}
                >
                  {/* Current explorer location marker indicator */}
                  {isCurrent && (
                    <span className="absolute -top-3 bg-amber-400 text-black text-[9px] font-sans font-black px-2 py-0.5 rounded-full uppercase tracking-wider animate-bounce shadow-md">
                      YOU ARE HERE
                    </span>
                  )}

                  <div className="flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-black/35">
                    {isUnlocked ? (
                      <NodeIcon
                        className={`w-5 h-5 sm:w-6 sm:h-6 ${
                          isSelected
                            ? 'text-emerald-300'
                            : isCurrent
                            ? 'text-yellow-300'
                            : 'text-amber-200'
                        }`}
                      />
                    ) : (
                      <Lock className="w-4 h-4 sm:w-5 sm:h-5 text-stone-400" />
                    )}
                  </div>

                  <span className="font-serif font-bold text-[10px] sm:text-xs tracking-wide whitespace-nowrap drop-shadow">
                    {node.name}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Bottom Node Inspector or Area Quick Launch Banner */}
        <div className="bg-[#24170e]/95 border-2 border-[#855325] rounded-2xl p-3 sm:p-4 text-[#f4ecd8] flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl z-20">
          {selectedNode ? (
            <>
              <div className="flex-1">
                <div className="flex items-center gap-2.5 flex-wrap">
                  <h3 className="font-serif font-black text-base sm:text-lg text-[#fef9c3]">
                    {selectedNode.name}
                  </h3>
                  
                  {player.unlockedAreas.includes(selectedNode.id) ||
                  player.level >= selectedNode.requiredLevel ||
                  selectedNode.requiredLevel === 1 ? (
                    <span className="bg-emerald-900/90 text-emerald-200 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-emerald-500 uppercase tracking-wider">
                      UNLOCKED
                    </span>
                  ) : (
                    <span className="bg-amber-950/90 text-amber-200 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-amber-600 uppercase tracking-wider">
                      Requires Level {selectedNode.requiredLevel}
                    </span>
                  )}

                  <span className="text-xs text-amber-400/90 font-mono">
                    {currentMap.subject} Realm
                  </span>
                </div>

                <p className="text-xs font-serif text-[#fed7aa] mt-0.5 line-clamp-1 sm:line-clamp-2">
                  {selectedNode.lore}
                </p>
                <p className="text-[11px] font-sans text-stone-400 mt-0.5">
                  Focus: <strong className="text-stone-300">{selectedNode.subtitle}</strong> • {selectedNode.questCount} Exploration Challenges
                </p>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                {/* Switch Player Active Subject if viewing a different subject map */}
                {player.mainSubject !== activeSubject && onUpdateSubject && (
                  <button
                    onClick={() => {
                      sounds.playSuccess();
                      onUpdateSubject(activeSubject);
                    }}
                    className="py-2 px-3 bg-[#3a2211] hover:bg-[#4a2e18] text-amber-300 border border-amber-600/60 rounded-xl text-xs font-serif font-bold uppercase transition flex items-center gap-1.5"
                    title={`Make ${activeSubject} your active learning subject`}
                  >
                    <BookMarked className="w-3.5 h-3.5" />
                    Set as Active
                  </button>
                )}

                <button
                  onClick={() => {
                    sounds.playSuccess();
                    // If viewing a different subject, update player subject as well so challenges match
                    if (player.mainSubject !== activeSubject && onUpdateSubject) {
                      onUpdateSubject(activeSubject);
                    }
                    onSelectArea(selectedNode.id, selectedNode.targetScreen, activeSubject);
                  }}
                  className="py-2.5 px-5 bg-gradient-to-b from-[#2d6a4f] via-[#1b4332] to-[#081c15] hover:from-[#40916c] hover:to-[#1b4332] text-[#fef9c3] font-serif font-bold text-xs uppercase tracking-wider rounded-xl border-2 border-emerald-400 shadow-md transition active:scale-95 flex items-center gap-2"
                >
                  <Play className="w-4 h-4 fill-[#fef9c3]" />
                  ENTER REGION
                </button>
              </div>
            </>
          ) : (
            <div className="flex flex-col sm:flex-row items-center justify-between w-full gap-2">
              <div className="text-xs font-serif text-[#fed7aa] text-center sm:text-left">
                <span className="font-bold text-amber-300">Tip:</span> Switch between <strong>Math</strong>, <strong>Science</strong>, and <strong>Language Arts</strong> tabs above to explore every realm's unique cartography and challenges.
              </div>
              <button
                onClick={() => {
                  sounds.playClick();
                  onBack();
                }}
                className="py-2 px-4 bg-[#3a2211] hover:bg-[#4a2e18] text-[#fef08a] border border-[#855325] rounded-xl text-xs font-serif font-bold uppercase transition flex items-center gap-1.5 shrink-0"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                BACK TO HUB
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
