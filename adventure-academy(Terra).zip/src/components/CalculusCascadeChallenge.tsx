import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { Sparkles, Trophy, HelpCircle, CheckCircle2, ChevronRight, Waves, Droplet, TrendingUp } from 'lucide-react';
import { ASSETS } from '../assets/assets';
import { NovaDialogueModal } from './NovaDialogueModal';
import { PlayerProfile } from '../types';
import { sounds } from '../utils/soundEffects';

interface CalculusCascadeChallengeProps {
  player: PlayerProfile;
  onComplete: (rewards: { xp: number; seeds: number; water: number; fertilizer: number }) => void;
  onNext?: () => void;
  onBackToMap?: () => void;
}

interface CalculusStage {
  id: number;
  title: string;
  subtitle: string;
  prompt: string;
  formula: string;
  options: { label: string; value: string; correct: boolean; explanation: string }[];
  hint: string;
}

export const CalculusCascadeChallenge: React.FC<CalculusCascadeChallengeProps> = ({
  player,
  onComplete,
  onNext,
  onBackToMap,
}) => {
  const [currentStageIdx, setCurrentStageIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [stageCleared, setStageCleared] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [showNovaModal, setShowNovaModal] = useState(false);

  const STAGES: CalculusStage[] = [
    {
      id: 1,
      title: 'Stage 1: Instantaneous Water Current Velocity',
      subtitle: 'Derivatives & Velocity: v(t) = s\'(t) = ds/dt',
      prompt: 'A sacred ceremonial leaf boat drifts down the mystical mountain waterfall. Its position along the flume is modeled by s(t) = 2t³ - 4t + 5 meters. What is the instantaneous velocity v(t) of the leaf at t = 3 seconds?',
      formula: 'v(t) = s\'(t) = 6t^2 - 4 \\implies v(3) = 6(3^2) - 4',
      options: [
        {
          label: '50 m/s (6 × 9 - 4 = 54 - 4)',
          value: '50',
          correct: true,
          explanation: 'Phenomenal! Power rule: derivative of 2t³ is 6t², derivative of -4t is -4. At t = 3: 6(9) - 4 = 54 - 4 = 50 m/s!',
        },
        {
          label: '54 m/s (Forgot the -4 constant term)',
          value: '54',
          correct: false,
          explanation: 'Close! 6 × 9 = 54, but do not forget to subtract 4 from the derivative: 54 - 4 = 50.',
        },
        {
          label: '36 m/s (4t² - 4)',
          value: '36',
          correct: false,
          explanation: 'Remember the power rule: d/dt [2t³] = 2 × 3t² = 6t², not 4t².',
        },
        {
          label: '47 m/s (Calculated position s(3) instead of velocity)',
          value: '47',
          correct: false,
          explanation: 's(3) = 2(27) - 12 + 5 = 47 is the position, whereas velocity is the derivative rate of change v(3) = 50 m/s!',
        },
      ],
      hint: 'Apply the power rule to 2t³ - 4t + 5: bring the power 3 down to multiply 2, giving 6t² - 4. Then substitute t = 3.',
    },
    {
      id: 2,
      title: 'Stage 2: Tangent Slope of the Aqueduct Chute',
      subtitle: 'Tangent Line Gradient: m = f\'(x)',
      prompt: 'The stone aqueduct curves along the parabolic trajectory f(x) = x² - 6x + 8. At what slope m must the canal gate be positioned at coordinate x = 5 to match the flowing water trajectory?',
      formula: 'm = f\'(x) = 2x - 6 \\implies f\'(5) = 2(5) - 6',
      options: [
        {
          label: 'Slope m = 4 (2 × 5 - 6 = 10 - 6)',
          value: '4',
          correct: true,
          explanation: 'Masterful! f\'(x) = 2x - 6. Evaluating at x = 5 gives 2(5) - 6 = 4. The tangent line ascends with a slope of 4!',
        },
        {
          label: 'Slope m = 10 (2 × 5 without subtracting 6)',
          value: '10',
          correct: false,
          explanation: 'Do not forget the second term: derivative of -6x is -6, so 10 - 6 = 4!',
        },
        {
          label: 'Slope m = 3 (f(5) = 25 - 30 + 8)',
          value: '3',
          correct: false,
          explanation: '3 is the elevation height f(5), not the instantaneous slope of inclination f\'(5)!',
        },
        {
          label: 'Slope m = -1',
          value: '-1',
          correct: false,
          explanation: 'At x = 5, the curve has already passed the minimum at x = 3 and is rising with positive slope m = 4.',
        },
      ],
      hint: 'Differentiate x² - 6x + 8 with respect to x. The derivative is 2x - 6. Plug in x = 5.',
    },
    {
      id: 3,
      title: 'Stage 3: Water Flow Accumulation Basin',
      subtitle: 'Definite Integration & Area: Total = ∫ R(t) dt',
      prompt: 'Water flows into the ancient mountain cistern at a flow rate of R(t) = 3t² liters per minute. How many total liters fill the cistern over the first 4 minutes (from t = 0 to t = 4)?',
      formula: '\\int_0^4 3t^2 \\, dt = \\left[ t^3 \\right]_0^4 = 4^3 - 0^3',
      options: [
        {
          label: '64 Liters ([t³] from 0 to 4 = 4³ = 64)',
          value: '64',
          correct: true,
          explanation: 'Flawless accumulation! The antiderivative of 3t² is t³. Evaluating from 0 to 4 gives 4³ - 0³ = 64 Liters!',
        },
        {
          label: '48 Liters (3 × 4² = 48 instantaneous rate)',
          value: '48',
          correct: false,
          explanation: '48 L/min is only the instantaneous rate at the final minute t = 4, not the accumulated total volume over all 4 minutes!',
        },
        {
          label: '32 Liters',
          value: '32',
          correct: false,
          explanation: 'Check your power calculation: 4³ = 4 × 4 × 4 = 64, not 32.',
        },
        {
          label: '192 Liters (3 × 64 without dividing by 3)',
          value: '192',
          correct: false,
          explanation: 'The power rule for integration adds 1 to exponent and divides by 3: ∫ 3t² dt = 3(t³/3) = t³!',
        },
      ],
      hint: 'Find the antiderivative of 3t². Since d/dt[t³] = 3t², the integral is simply t³. Evaluate 4³ - 0.',
    },
  ];

  const currentStage = STAGES[currentStageIdx];

  const handleSelectOption = (idx: number) => {
    setSelectedOption(idx);
    const opt = currentStage.options[idx];

    if (opt.correct) {
      sounds.playSuccess();
      sounds.playWater();
      sounds.playMagicChime();
      setStageCleared(true);

      if (currentStageIdx === STAGES.length - 1) {
        confetti({
          particleCount: 110,
          spread: 85,
          origin: { y: 0.6 },
          colors: ['#06b6d4', '#3b82f6', '#10b981', '#f59e0b'],
        });
        setTimeout(() => {
          setShowCelebration(true);
          onComplete({
            xp: 280,
            seeds: 7,
            water: 6,
            fertilizer: 4,
          });
        }, 1200);
      }
    } else {
      sounds.playError();
      setShowNovaModal(true);
    }
  };

  const handleNextStage = () => {
    if (currentStageIdx < STAGES.length - 1) {
      sounds.playClick();
      setCurrentStageIdx((prev) => prev + 1);
      setSelectedOption(null);
      setStageCleared(false);
    }
  };

  return (
    <div className="relative min-h-[calc(100vh-56px)] flex items-center justify-center p-3 sm:p-6 overflow-hidden select-none">
      {/* Background Painted Cascading Waterfall */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${ASSETS.forestBackground})`,
          filter: 'hue-rotate(180deg) brightness(0.75) contrast(1.15)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-sky-950/40 to-black/75 pointer-events-none" />

      {/* Main Altar Board */}
      <div className="relative z-10 w-full max-w-4xl bg-gradient-to-b from-[#0c202a] via-[#071720] to-[#040d12] border-4 border-cyan-500/70 rounded-3xl p-4 sm:p-7 shadow-[0_25px_60px_rgba(0,0,0,0.9)] flex flex-col justify-between">
        {/* Header Ribbon */}
        <div className="flex flex-wrap items-center justify-between border-b-2 border-cyan-800/60 pb-3 gap-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-950/90 border border-cyan-400 flex items-center justify-center text-cyan-300 shadow-md">
              <Waves className="w-6 h-6 animate-pulse text-cyan-400" />
            </div>
            <div>
              <div className="text-[11px] font-mono uppercase tracking-widest text-cyan-300">
                CALCULUS CASCADE • REALM CHALLENGE
              </div>
              <h2 className="font-serif font-black text-xl sm:text-2xl text-cyan-100">
                The River of Fluxions & Integral Basin
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="bg-[#05141b] border border-cyan-600/60 px-3 py-1.5 rounded-xl text-xs font-mono text-cyan-200">
              Stage {currentStageIdx + 1} of {STAGES.length}
            </div>
            <button
              onClick={() => {
                sounds.playClick();
                setShowNovaModal(true);
              }}
              className="p-2 bg-cyan-900/40 hover:bg-cyan-800/60 border border-cyan-500/60 rounded-xl text-cyan-200 transition"
              title="Ask Nova for a hint"
            >
              <HelpCircle className="w-5 h-5 text-cyan-300" />
            </button>
          </div>
        </div>

        {/* Challenge Stage Content */}
        <div className="my-5 grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
          {/* Left: Interactive Diagram / Visual for Stage */}
          <div className="md:col-span-5 bg-[#030d12]/95 border-2 border-cyan-800/60 rounded-2xl p-4 flex flex-col items-center justify-center min-h-[270px] shadow-inner">
            <div className="text-xs font-serif font-bold text-cyan-300/80 uppercase tracking-wider mb-2">
              {currentStageIdx === 0 && 'Velocity Vector along Flume'}
              {currentStageIdx === 1 && 'Aqueduct Tangent Line Slope'}
              {currentStageIdx === 2 && 'Accumulation of Fluid Area'}
            </div>

            {/* STAGE 1: Leaf boat on velocity curve */}
            {currentStageIdx === 0 && (
              <svg width="220" height="150" viewBox="0 0 220 150">
                {/* Flume stream */}
                <path
                  d="M 20 120 Q 80 110, 130 60 T 200 20"
                  fill="none"
                  stroke="#0284c7"
                  strokeWidth="6"
                  strokeLinecap="round"
                />

                {/* Leaf Boat at t = 3 */}
                <ellipse cx="130" cy="60" rx="12" ry="6" fill="#10b981" stroke="#34d399" strokeWidth="2" transform="rotate(-35 130 60)" />
                <text x="130" y="50" fill="#a7f3d0" fontSize="9" fontWeight="bold" textAnchor="middle">
                  t = 3s
                </text>

                {/* Velocity Vector Arrow: tangent line */}
                <line x1="130" y1="60" x2="185" y2="25" stroke="#f59e0b" strokeWidth="3" markerEnd="url(#arrow)" />
                <text x="175" y="18" fill="#fde047" fontSize="10" fontWeight="bold" fontFamily="monospace">
                  v(3) = 50 m/s
                </text>

                <text x="110" y="135" fill="#7dd3fc" fontSize="9" textAnchor="middle" fontFamily="monospace">
                  s'(t) = 6t² - 4
                </text>
              </svg>
            )}

            {/* STAGE 2: Tangent Slope at x = 5 */}
            {currentStageIdx === 1 && (
              <svg width="220" height="150" viewBox="0 0 220 150">
                {/* Parabola curve */}
                <path
                  d="M 30 40 Q 100 130, 180 30"
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="3"
                />

                {/* Tangent line at x = 5 (near x=150, y=55) */}
                <line x1="120" y1="110" x2="180" y2="20" stroke="#f43f5e" strokeWidth="3" strokeDasharray="3 2" />

                {/* Point of tangency */}
                <circle cx="150" cy="65" r="5" fill="#f43f5e" stroke="#fff" strokeWidth="1.5" />
                <text x="160" y="80" fill="#fecdd3" fontSize="10" fontWeight="bold" fontFamily="monospace">
                  (5, f(5))
                </text>

                <text x="110" y="140" fill="#67e8f9" fontSize="11" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  m = f'(5) = 2(5) - 6 = 4
                </text>
              </svg>
            )}

            {/* STAGE 3: Definite Integral Area Accumulation */}
            {currentStageIdx === 2 && (
              <svg width="220" height="150" viewBox="0 0 220 150">
                {/* Coordinate Axes */}
                <line x1="30" y1="20" x2="30" y2="120" stroke="#0284c7" strokeWidth="2" />
                <line x1="30" y1="120" x2="190" y2="120" stroke="#0284c7" strokeWidth="2" />

                {/* Shaded Area under 3t^2 from 0 to 4 */}
                <path
                  d="M 30 120 Q 90 115, 150 40 L 150 120 Z"
                  fill="#06b6d4"
                  fillOpacity="0.4"
                  stroke="#22d3ee"
                  strokeWidth="2"
                />

                {/* Vertical bound at t = 4 */}
                <line x1="150" y1="40" x2="150" y2="120" stroke="#f59e0b" strokeWidth="2" strokeDasharray="2 2" />
                <text x="150" y="135" fill="#fde047" fontSize="10" fontWeight="bold" textAnchor="middle">
                  t = 4
                </text>
                <text x="30" y="135" fill="#7dd3fc" fontSize="9" textAnchor="middle">
                  t = 0
                </text>

                {/* Integral Area Label */}
                <text x="95" y="90" fill="#e0f2fe" fontSize="11" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  Area = 64 L
                </text>
              </svg>
            )}
          </div>

          {/* Right: Question & Multiple Choice */}
          <div className="md:col-span-7 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono uppercase tracking-widest text-cyan-400 mb-1">
                {currentStage.subtitle}
              </div>
              <h3 className="font-serif font-bold text-lg sm:text-xl text-cyan-50 leading-snug mb-3">
                {currentStage.prompt}
              </h3>

              <div className="bg-[#051a24] border border-cyan-600/40 rounded-xl px-3 py-2 text-xs font-mono text-cyan-300 mb-4 inline-block">
                Formula: {currentStage.formula}
              </div>
            </div>

            {/* Options Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 my-2">
              {currentStage.options.map((option, idx) => {
                const isSelected = selectedOption === idx;
                const isCorrect = option.correct;
                let btnStyle = 'bg-[#0a1e27] hover:bg-[#0e2a37] border-cyan-800/60 text-cyan-100';

                if (isSelected) {
                  btnStyle = isCorrect
                    ? 'bg-emerald-950/90 border-emerald-400 text-emerald-100 ring-2 ring-emerald-500'
                    : 'bg-red-950/90 border-red-400 text-red-100 ring-2 ring-red-500';
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(idx)}
                    disabled={stageCleared}
                    className={`p-3 border-2 rounded-xl text-left transition-all active:scale-[0.98] shadow-md flex items-center justify-between text-xs sm:text-sm font-serif font-bold ${btnStyle}`}
                  >
                    <span>{option.label}</span>
                    {isSelected && isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 ml-2" />}
                  </button>
                );
              })}
            </div>

            {/* Advance / Next Stage Footer */}
            <div className="mt-4 flex items-center justify-between pt-2 border-t border-cyan-900/60">
              {stageCleared ? (
                <div className="flex items-center justify-between w-full">
                  <div className="text-xs font-mono text-emerald-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Cascade Flux Harmonized!</span>
                  </div>

                  {currentStageIdx < STAGES.length - 1 ? (
                    <button
                      onClick={handleNextStage}
                      className="px-5 py-2 bg-gradient-to-r from-cyan-600 to-blue-700 hover:from-cyan-500 hover:to-blue-600 text-white font-serif font-bold text-xs rounded-xl shadow-lg flex items-center gap-1.5 active:scale-95 transition"
                    >
                      <span>Next Stage</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        sounds.playVictoryFanfare();
                        setShowCelebration(true);
                      }}
                      className="px-5 py-2 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black font-serif font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 active:scale-95 transition"
                    >
                      <Trophy className="w-4 h-4" />
                      <span>Claim Calculus Treasures</span>
                    </button>
                  )}
                </div>
              ) : (
                <div className="text-xs font-serif text-cyan-200/60 italic">
                  Select the derivative or integral solution to balance the mountain cascade.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom Companion Footer & Back to Map */}
        <div className="flex items-center justify-between border-t border-cyan-900/60 pt-3 text-xs">
          <button
            onClick={() => {
              sounds.playClick();
              if (onBackToMap) onBackToMap();
            }}
            className="text-cyan-300 hover:text-cyan-100 font-serif font-bold transition flex items-center gap-1"
          >
            ← Return to World Map
          </button>

          <div className="flex items-center gap-2">
            <span className="text-cyan-300 font-mono text-[11px]">Flow Status:</span>
            <span className="text-cyan-400 font-serif font-bold">100% Laminar Flux Balance</span>
          </div>
        </div>
      </div>

      {/* Nova Hint Modal */}
      <AnimatePresence>
        {showNovaModal && (
          <NovaDialogueModal
            isOpen={showNovaModal}
            onClose={() => setShowNovaModal(false)}
            onTryAgain={() => {
              setShowNovaModal(false);
              setSelectedOption(null);
            }}
            question={currentStage.prompt}
            topic="Calculus & Rates of Change"
            playerGrade={player.grade}
          />
        )}
      </AnimatePresence>

      {/* Final Victory Celebration Modal */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="w-full max-w-md bg-gradient-to-b from-[#0e2735] to-[#040e14] border-4 border-cyan-400 rounded-3xl p-6 shadow-2xl text-center flex flex-col items-center"
            >
              <div className="w-16 h-16 rounded-2xl bg-cyan-500/20 border-2 border-cyan-400 flex items-center justify-center text-cyan-300 mb-3 animate-bounce">
                <Trophy className="w-8 h-8 text-cyan-400" />
              </div>

              <div className="text-xs font-mono uppercase tracking-widest text-cyan-400">
                CALCULUS CASCADE CLEARED
              </div>
              <h2 className="font-serif font-black text-2xl sm:text-3xl text-cyan-100 mt-1 mb-2">
                Navigator of Fluxions!
              </h2>

              <p className="text-sm text-cyan-100/90 font-serif leading-relaxed mb-4">
                You mastered instantaneous derivative velocity, tangent slopes, and definite integral water volume accumulation!
              </p>

              {/* Rewards Box */}
              <div className="w-full bg-[#040f16] border-2 border-cyan-600/60 rounded-2xl p-3.5 mb-5 flex justify-around text-center font-mono">
                <div>
                  <div className="text-lg font-bold text-yellow-400">+280</div>
                  <div className="text-[10px] text-cyan-200/80">XP</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-emerald-400">+7</div>
                  <div className="text-[10px] text-cyan-200/80">SEEDS</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-cyan-400">+6</div>
                  <div className="text-[10px] text-cyan-200/80">WATER</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-orange-400">+4</div>
                  <div className="text-[10px] text-cyan-200/80">FERTILIZER</div>
                </div>
              </div>

              <div className="flex gap-2 w-full">
                <button
                  onClick={() => {
                    sounds.playClick();
                    if (onNext) onNext();
                    else if (onBackToMap) onBackToMap();
                  }}
                  className="flex-1 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-serif font-black text-sm rounded-xl shadow-lg active:scale-95 transition"
                >
                  Continue Expedition
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
