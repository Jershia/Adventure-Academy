export type GradeLevel = 'K-2' | '3-5' | '6-8' | '9-12';
export type MainSubject = 'Math' | 'Science' | 'Language Arts';

export interface PlantData {
  id: string;
  name?: string;
  stage: 'seed' | 'sprout' | 'tree' | 'growing' | 'harvestable';
  plantedAt?: number;
  waterCount?: number;
  waterLevel?: number;
  fertilizerCount?: number;
  fertilizerApplied?: boolean;
}

export interface PlayerProfile {
  id: string;
  name: string;
  avatar?: string;
  email: string;
  grade: GradeLevel;
  mainSubject: MainSubject;
  level: number;
  xp: number;
  xpToNextLevel: number;
  streakDays: number;
  resources: {
    seeds: number;
    water: number;
    fertilizer: number;
  };
  unlockedAreas: string[];
  currentArea: string;
  completedQuests: string[];
  skillMastery: {
    [skillName: string]: number; // 0 to 100 percentage
  };
  learningStats: {
    visualSpeedScore: number; // e.g. 80
    textSpeedScore: number;   // e.g. 50
    visualChallengesSolved: number;
    textChallengesSolved: number;
    accuracyRate: number;     // e.g. 85
    totalAttempts: number;
    hintsRequested: number;
    strongTopics: string[];
    developingTopics: string[];
    recommendedPath: 'visual' | 'text';
  };
  camp: {
    level: number;
    buildings: {
      mapTable: { built: boolean; level: number };
      knowledgeBoard: { built: boolean; level: number };
      explorerTent: { built: boolean; level: number };
      plantBed: { built: boolean; level: number; plantsCount: number };
    };
    plants: PlantData[];
  };
  // Save the Planet Hackathon Eco-Impact Features
  realTreesPlanted: number;
  totalSaplingsGrown: number;
  co2OffsetKg: number;
  plantedTreeCertificates: PlantedTreeCertificate[];
  forestTrees: ForestTree[];
}

export interface PlantedTreeCertificate {
  id: string;
  species: string;
  commonName: string;
  region: string;
  coordinates: { lat: number; lng: number };
  plantedAt: number;
  co2PerYearKg: number;
  partner: string;
  dedicatedTo: string;
  certificateHash: string;
  realWorldImpact: string;
}

export interface ForestTree {
  id: string;
  species: string;
  commonName: string;
  growthPercent: number; // 0 to 100
  seedsInvested: number;
  waterGiven: number;
  fertilizerGiven: number;
  stage: 'seed' | 'sprout' | 'sapling' | 'canopy' | 'mature';
  completedRealTree: boolean;
  certificateId?: string;
}

export interface Quest {
  id: string;
  number?: string; // e.g. "QUEST 01"
  title: string;  // e.g. "Repair the Bridge"
  description?: string;
  learningConcept?: string; // e.g. "Quadratic Equations"
  learningObjective?: string;
  rewardSummary?: string; // e.g. "+100 XP, +3 Seeds, +1 Water, +1 Fertilizer"
  rewardXp?: number;
  rewardSeeds?: number;
  rewardWater?: number;
  rewardFertilizer?: number;
  rewards?: {
    xp: number;
    seeds: number;
    water: number;
    fertilizer: number;
  };
  difficulty?: 'starter' | 'standard' | 'challenge' | 'master';
  unlocked?: boolean;
  completed: boolean;
  type?: 'equation' | 'graph' | 'stepping_stones' | 'knowledge_gate' | 'master_circle' | 'probability' | 'trigonometry' | 'geometry_canopy' | 'ai_forge' | 'exponents' | 'calculus' | 'matrices';
  areaId?: string;
  stageCount?: number;
}

export interface SteppingStoneItem {
  id: number;
  equation: string;
  expectedAnswer: number;
  options: number[];
}

export interface ParabolaConfig {
  targetA: number; // e.g. 0.5 for wide, 2 for narrow
  targetB: number; // e.g. -2 for shift
  targetC: number;
  currentA: number;
  currentB: number;
  tolerance: number;
  hint: string;
}

export interface OrientationQuestion {
  id: number;
  question: string;
  equation: string;
  options: { label: string; text: string; correct: boolean }[];
  explanation: string;
}

export interface NovaDialogue {
  speaker: 'NOVA';
  mood: 'encouraging' | 'thinking' | 'celebrating' | 'guiding';
  message: string;
  hintText?: string;
  alternativeExplanation?: string;
}
