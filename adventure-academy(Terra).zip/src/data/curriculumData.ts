import { GradeLevel, MainSubject, OrientationQuestion } from '../types';

export interface ChallengeQuestion {
  id: string;
  stageNumber: number;
  stageTitle: string;
  topic: string;
  prompt: string;
  subPrompt?: string;
  equationOrVisual?: string;
  options: {
    id: string;
    text: string;
    value: string | number;
    explanation?: string;
  }[];
  correctAnswer: string | number;
  hint: string;
  terraEncouragement: string;
  interactiveType?: 'choice' | 'planks' | 'stones' | 'slider';
}

export interface ChallengeCurriculum {
  challengeId: string;
  title: string;
  description: string;
  learningObjective: string;
  questions: ChallengeQuestion[];
}

export const GRADE_LABELS: Record<GradeLevel, string> = {
  'K-2': 'Grade K-2 (Early Explorer)',
  '3-5': 'Grade 3-5 (Junior Scholar)',
  '6-8': 'Grade 6-8 (Middle Academy)',
  '9-12': 'Grade 9-12 (Advanced Scholar)',
};

export const SUBJECT_ICONS: Record<MainSubject, string> = {
  Math: '📐',
  Science: '🔬',
  'Language Arts': '📜',
};

// ==========================================
// 1. BRIDGE QUEST CURRICULUM
// ==========================================
export const BRIDGE_CURRICULUM: Record<MainSubject, Record<GradeLevel, ChallengeQuestion>> = {
  Math: {
    'K-2': {
      id: 'bridge-math-k2',
      stageNumber: 1,
      stageTitle: 'Plank Counting Bridge',
      topic: 'Addition & Number Bonds',
      prompt: 'The wooden bridge needs 8 planks in total. We already laid 5 planks down. How many more planks must we place?',
      subPrompt: 'Solve for the missing plank number: 5 + [ ? ] = 8',
      equationOrVisual: '5 + 🪵 = 8',
      options: [
        { id: 'a', text: '2 Planks', value: '2', explanation: '5 + 2 = 7, not quite 8.' },
        { id: 'b', text: '3 Planks', value: '3', explanation: 'Correct! 5 + 3 = 8 planks complete the bridge!' },
        { id: 'c', text: '4 Planks', value: '4', explanation: '5 + 4 = 9, that is too many planks.' },
      ],
      correctAnswer: '3',
      hint: 'Count on from 5: 6, 7, 8... how many fingers did you count?',
      terraEncouragement: 'Terra whispers: "Just 3 more cedar planks and our path across the woodland stream will be sturdy!"',
    },
    '3-5': {
      id: 'bridge-math-35',
      stageNumber: 1,
      stageTitle: 'Timber Array Multiplication',
      topic: 'Multiplication Arrays',
      prompt: 'The bridge spans 4 stone pillars. Each pillar requires 6 ironwood crossbeams to bear the explorer’s weight. How many crossbeams are needed in total?',
      subPrompt: 'Calculate the total crossbeams: 4 pillars × 6 beams each = ?',
      equationOrVisual: '4 × 6 = [ ? ]',
      options: [
        { id: 'a', text: '20 Beams', value: '20', explanation: '4 × 5 = 20, but we have 6 beams per pillar.' },
        { id: 'b', text: '24 Beams', value: '24', explanation: 'Spot on! 4 × 6 = 24 crossbeams locks the timber deck!' },
        { id: 'c', text: '28 Beams', value: '28', explanation: '4 × 7 = 28, which exceeds our needed supply.' },
      ],
      correctAnswer: '24',
      hint: 'Think of 4 groups of 6: 6 + 6 + 6 + 6.',
      terraEncouragement: 'Terra smiles: "The forest arrays line up like rows of pine trees! 24 beams lock the span!"',
    },
    '6-8': {
      id: 'bridge-math-68',
      stageNumber: 1,
      stageTitle: 'Linear Cable Tension Balance',
      topic: 'Linear Equations',
      prompt: 'To balance the suspension cable tension across the gorge, solve for x in the cable equilibrium equation:',
      subPrompt: 'Solve for x: 3x - 5 = 16',
      equationOrVisual: '3x - 5 = 16',
      options: [
        { id: 'a', text: 'x = 5', value: '5', explanation: '3(5) - 5 = 10, not 16.' },
        { id: 'b', text: 'x = 7', value: '7', explanation: 'Excellent! Add 5 to both sides (3x = 21), then divide by 3 (x = 7).' },
        { id: 'c', text: 'x = 8', value: '8', explanation: '3(8) - 5 = 19, which is too tight.' },
      ],
      correctAnswer: '7',
      hint: 'First undo subtraction: add 5 to both sides to get 3x = 21. Then divide by 3.',
      terraEncouragement: 'Terra rustles green leaves: "Balancing equations is like balancing rocks on a woodland cairn. x = 7 pulls the cable taut!"',
    },
    '9-12': {
      id: 'bridge-math-912',
      stageNumber: 1,
      stageTitle: 'Quadratic Arch Footholds',
      topic: 'Factoring Quadratic Equations',
      prompt: 'The parabolic bridge arch touches the riverbanks where height y = 0. Factor the quadratic equation to find the two grounding roots:',
      subPrompt: 'Factor: x² - 5x + 6 = 0  =>  (x - ?)(x - ?) = 0',
      equationOrVisual: 'x² - 5x + 6 = 0',
      options: [
        { id: 'a', text: 'x = -2 and x = -3', value: 'neg2neg3', explanation: '(-2)(-3) = +6, but (-2) + (-3) = -5, which means (x + 2)(x + 3) would give +5x.' },
        { id: 'b', text: 'x = 2 and x = 3', value: '2and3', explanation: 'Correct! (x - 2)(x - 3) = x² - 5x + 6 = 0, so roots are x = 2 and x = 3.' },
        { id: 'c', text: 'x = 1 and x = 6', value: '1and6', explanation: '(x - 1)(x - 6) = x² - 7x + 6.' },
      ],
      correctAnswer: '2and3',
      hint: 'Find two numbers that multiply to +6 and add up to -5: (-2) × (-3) = +6, and (-2) + (-3) = -5.',
      terraEncouragement: 'Terra glows with amber pollen: "Both roots anchor the bridge arch right onto the granite bedrock!"',
    },
  },
  Science: {
    'K-2': {
      id: 'bridge-sci-k2',
      stageNumber: 1,
      stageTitle: 'Floating Timber Materials',
      topic: 'Material Properties (Density & Buoyancy)',
      prompt: 'Terra needs help picking the best forest material to build the floating pontoon bridge. Which material floats naturally on water?',
      subPrompt: 'Which of these floats on the river?',
      equationOrVisual: '🌊 Water Buoyancy Test',
      options: [
        { id: 'a', text: 'Dry Pine Wood Planks', value: 'wood', explanation: 'Correct! Wood is less dense than water, so it floats safely!' },
        { id: 'b', text: 'Heavy Granite Boulder', value: 'stone', explanation: 'Granite is denser than water and sinks to the riverbed.' },
        { id: 'c', text: 'Solid Iron Anchor', value: 'iron', explanation: 'Iron is heavy and sinks straight down.' },
      ],
      correctAnswer: 'wood',
      hint: 'Think about twigs and fallen branches on a pond—do they float or sink?',
      terraEncouragement: 'Terra gently floats: "The cellular air pockets in pine wood keep our bridge bobbing lightly on the river!"',
    },
    '3-5': {
      id: 'bridge-sci-35',
      stageNumber: 1,
      stageTitle: 'Soil Stability & Root Anchorage',
      topic: 'Ecosystems & Erosion Control',
      prompt: 'The rushing river current is washing soil away from the bridge supports! What natural forest element best prevents soil erosion and anchors the riverbank?',
      subPrompt: 'Identify the natural erosion barrier:',
      equationOrVisual: '🌿 Riverbank Soil Anchor',
      options: [
        { id: 'a', text: 'Deep Willow & Alder Tree Roots', value: 'roots', explanation: 'Correct! Extensive root networks weave through soil, binding it tight against river currents!' },
        { id: 'b', text: 'Dry Sand Dunes', value: 'sand', explanation: 'Loose sand washes away rapidly in water currents.' },
        { id: 'c', text: 'Piles of Dry Fallen Leaves', value: 'leaves', explanation: 'Fallen leaves wash away easily in flowing water.' },
      ],
      correctAnswer: 'roots',
      hint: 'Plants grip the earth with underground structures that drink water and hold soil.',
      terraEncouragement: 'Terra beams: "Living roots are nature’s strongest rebar! They lock the riverbanks firm."',
    },
    '6-8': {
      id: 'bridge-sci-68',
      stageNumber: 1,
      stageTitle: 'Newtonian Force Equilibrium',
      topic: 'Forces & Newton’s Third Law',
      prompt: 'An explorer with a backpack exerts a downward gravitational force of 600 Newtons onto the bridge plank. According to Newton’s Laws, what upward force does the bridge plank exert on the explorer?',
      subPrompt: 'Action and Reaction force balance:',
      equationOrVisual: 'F_gravity (600 N ↓) vs F_normal (? ↑)',
      options: [
        { id: 'a', text: '0 N (No force upward)', value: '0', explanation: 'If there were no upward force, the explorer would fall straight through!' },
        { id: 'b', text: '600 N Normal Force upward', value: '600', explanation: 'Correct! By Newton’s Third Law and static equilibrium, the normal force matches the downward weight (600 N).' },
        { id: 'c', text: '1200 N Force upward', value: '1200', explanation: '1200 N upward would fling the explorer into the air!' },
      ],
      correctAnswer: '600',
      hint: 'Every action force has an equal and opposite reaction force in static equilibrium.',
      terraEncouragement: 'Terra hovers steadily: "Balanced forces keep us standing firm upon the plank without sinking or bouncing!"',
    },
    '9-12': {
      id: 'bridge-sci-912',
      stageNumber: 1,
      stageTitle: 'Structural Stress & Strain Analysis',
      topic: 'Mechanics: Tension vs Compression',
      prompt: 'In the suspension bridge design, the heavy steel cables hanging from the timber towers are pulled tight by the bridge deck’s weight. Which mechanical internal stress is acting inside the cable?',
      subPrompt: 'Identify the dominant mechanical stress type:',
      equationOrVisual: 'Cable Stress: σ = F / A',
      options: [
        { id: 'a', text: 'Tensile Stress (Tension)', value: 'tension', explanation: 'Correct! Suspension cables are designed specifically to withstand high tensile pulling forces along their axial length.' },
        { id: 'b', text: 'Compressive Stress', value: 'compression', explanation: 'Towers experience compression (pushing inward), but flexible cables buckle under compression.' },
        { id: 'c', text: 'Torsional Shear only', value: 'shear', explanation: 'Torsion is twisting; cables primarily experience pure axial tension.' },
      ],
      correctAnswer: 'tension',
      hint: 'When forces pull an object outward from both ends to stretch it, that is tension.',
      terraEncouragement: 'Terra glows brightly: "Tension pulls the cable atoms into alignment! The bridge can hold thousands of kilograms!"',
    },
  },
  'Language Arts': {
    'K-2': {
      id: 'bridge-la-k2',
      stageNumber: 1,
      stageTitle: 'The Rhyme Crossing',
      topic: 'Phonological Awareness & Rhyme',
      prompt: 'To carve the ancient forest password into the bridge timber, find the word that rhymes with "STREAM":',
      subPrompt: 'Which word rhymes with STREAM?',
      equationOrVisual: '🪵 S - T - R - E - A - M  ~  ?',
      options: [
        { id: 'a', text: 'BEAM', value: 'beam', explanation: 'Correct! Stream and Beam share the same ending sound (-eam)!' },
        { id: 'b', text: 'STONE', value: 'stone', explanation: 'Stone ends with -one, which does not rhyme with stream.' },
        { id: 'c', text: 'WATER', value: 'water', explanation: 'Water is related in meaning, but does not rhyme with stream.' },
      ],
      correctAnswer: 'beam',
      hint: 'Listen to the sound at the end of stream: "-eam". Which word ends the same way?',
      terraEncouragement: 'Terra laughs musically: "Stream and beam chime together like songbirds in the dawn!"',
    },
    '3-5': {
      id: 'bridge-la-35',
      stageNumber: 1,
      stageTitle: 'Parts of Speech: Dynamic Verbs',
      topic: 'Grammar & Vivid Action Verbs',
      prompt: 'Terra reads the ancient inscription on the bridge post. Which vivid action verb best fills the blank to describe the river?',
      subPrompt: '"The roaring mountain torrent _______ past the weathered wooden pylons."',
      equationOrVisual: 'The roaring mountain torrent [ ? ] past the pylons.',
      options: [
        { id: 'a', text: 'surged (Verb)', value: 'surged', explanation: 'Correct! "Surged" is a powerful, vivid action verb that brings the sentence to life!' },
        { id: 'b', text: 'rapidly (Adverb)', value: 'rapidly', explanation: '"Rapidly" is an adverb describing how something happens, but the sentence is missing its core verb.' },
        { id: 'c', text: 'turquoise (Adjective)', value: 'turquoise', explanation: '"Turquoise" is an adjective describing color, not an action.' },
      ],
      correctAnswer: 'surged',
      hint: 'A verb expresses physical or mental action. Which word tells what the water actually did?',
      terraEncouragement: 'Terra flutters with delight: "A vivid verb gives life to our expedition journal!"',
    },
    '6-8': {
      id: 'bridge-la-68',
      stageNumber: 1,
      stageTitle: 'Figurative Language: Bridge Personification',
      topic: 'Literary Devices',
      prompt: 'Analyze this passage from the explorer’s log: "The ancient bridge groaned under our footsteps, as if waking from a century of slumber." Which literary device is used here?',
      subPrompt: 'Identify the literary technique:',
      equationOrVisual: '"The bridge groaned... as if waking from slumber"',
      options: [
        { id: 'a', text: 'Personification', value: 'personification', explanation: 'Correct! Giving human emotions and actions (groaning, waking from slumber) to an inanimate bridge is personification.' },
        { id: 'b', text: 'Onomatopoeia only', value: 'onomatopoeia', explanation: 'While groan has a sound element, attributing human slumber and waking makes personification the primary device.' },
        { id: 'c', text: 'Hyperbole only', value: 'hyperbole', explanation: 'The description focuses on human qualities rather than pure numeric exaggeration.' },
      ],
      correctAnswer: 'personification',
      hint: 'When a writer gives human traits, voices, or behaviors to non-human objects, what is that called?',
      terraEncouragement: 'Terra nods: "The forest breathes and speaks in metaphor! Personification brings ancient timber to life."',
    },
    '9-12': {
      id: 'bridge-la-912',
      stageNumber: 1,
      stageTitle: 'Classical Rhetorical Keystone',
      topic: 'Rhetoric & Etymology',
      prompt: 'The inscription above the bridge keystone reads: "Trust not in mere vanity; let your crossing rest upon sound evidence and verifiable stone." Which classical rhetorical appeal does this inscription emphasize?',
      subPrompt: 'Identify the Aristotle rhetorical appeal:',
      equationOrVisual: 'Ethos vs Pathos vs Logos',
      options: [
        { id: 'a', text: 'Logos (Appeal to Reason & Verifiable Evidence)', value: 'logos', explanation: 'Correct! Logos appeals to logic, empirical proof, and rational soundness ("sound evidence and verifiable stone").' },
        { id: 'b', text: 'Pathos (Appeal to Emotion & Sentiment)', value: 'pathos', explanation: 'Pathos focuses on stirring passionate emotional reactions rather than rational verification.' },
        { id: 'c', text: 'Ethos (Appeal to Personal Moral Authority only)', value: 'ethos', explanation: 'While ethics matter, the sentence explicitly demands verifiable logical evidence (Logos).' },
      ],
      correctAnswer: 'logos',
      hint: 'Logos relates to logic, facts, measurements, and verifiable proofs.',
      terraEncouragement: 'Terra glows with radiant emerald light: "Logos stands upon the bedrock of truth! The keystone clicks into place!"',
    },
  },
};

// ==========================================
// 2. STEPPING STONES CURRICULUM (4 STONES)
// ==========================================
export interface SteppingStoneConfig {
  stoneIndex: number;
  prompt: string;
  badge: string;
  options: { text: string; value: string | number }[];
  correctAnswer: string | number;
  hint: string;
}

export const STEPPING_STONES_CURRICULUM: Record<MainSubject, Record<GradeLevel, SteppingStoneConfig[]>> = {
  Math: {
    'K-2': [
      { stoneIndex: 1, prompt: 'Stone 1: 3 acorns + 4 pinecones = ?', badge: 'Addition', options: [{ text: '6', value: 6 }, { text: '7', value: 7 }, { text: '8', value: 8 }], correctAnswer: 7, hint: 'Count: 3... 4, 5, 6, 7!' },
      { stoneIndex: 2, prompt: 'Stone 2: 9 river pebbles - 4 pebbles = ?', badge: 'Subtraction', options: [{ text: '5', value: 5 }, { text: '6', value: 6 }, { text: '4', value: 4 }], correctAnswer: 5, hint: 'Take 4 away from 9.' },
      { stoneIndex: 3, prompt: 'Stone 3: Which number is GREATER?', badge: 'Comparison', options: [{ text: '12', value: 12 }, { text: '7', value: 7 }, { text: '9', value: 9 }], correctAnswer: 12, hint: '12 comes after 7 and 9 on the number line.' },
      { stoneIndex: 4, prompt: 'Stone 4: What comes next: 2, 4, 6, ?', badge: 'Patterns', options: [{ text: '7', value: 7 }, { text: '8', value: 8 }, { text: '10', value: 10 }], correctAnswer: 8, hint: 'Add 2 each step: 6 + 2 = 8.' },
    ],
    '3-5': [
      { stoneIndex: 1, prompt: 'Stone 1: 7 × 8 = ?', badge: 'Multiplication', options: [{ text: '54', value: 54 }, { text: '56', value: 56 }, { text: '64', value: 64 }], correctAnswer: 56, hint: '7 times 7 is 49; add 7 more.' },
      { stoneIndex: 2, prompt: 'Stone 2: 45 ÷ 5 = ?', badge: 'Division', options: [{ text: '8', value: 8 }, { text: '9', value: 9 }, { text: '7', value: 7 }], correctAnswer: 9, hint: 'What number times 5 gives 45?' },
      { stoneIndex: 3, prompt: 'Stone 3: Which fraction is equivalent to 1/2?', badge: 'Fractions', options: [{ text: '2/4', value: '2/4' }, { text: '1/3', value: '1/3' }, { text: '2/5', value: '2/5' }], correctAnswer: '2/4', hint: 'Multiply top and bottom by 2.' },
      { stoneIndex: 4, prompt: 'Stone 4: Area of rectangle with length 6 and width 4 = ?', badge: 'Geometry Area', options: [{ text: '20', value: 20 }, { text: '24', value: 24 }, { text: '10', value: 10 }], correctAnswer: 24, hint: 'Area = Length × Width = 6 × 4.' },
    ],
    '6-8': [
      { stoneIndex: 1, prompt: 'Stone 1: Solve for x: x + 7 = 15', badge: 'One-Step Equation', options: [{ text: '6', value: 8 }, { text: '8', value: 8 }, { text: '9', value: 9 }], correctAnswer: 8, hint: 'Subtract 7 from 15: 15 - 7 = 8.' },
      { stoneIndex: 2, prompt: 'Stone 2: Solve for x: 2x - 3 = 11', badge: 'Two-Step Equation', options: [{ text: '7', value: 7 }, { text: '6', value: 6 }, { text: '8', value: 8 }], correctAnswer: 7, hint: 'Add 3: 2x = 14, then divide by 2: x = 7.' },
      { stoneIndex: 3, prompt: 'Stone 3: Evaluate: (-4) × 6 = ?', badge: 'Integer Signs', options: [{ text: '-24', value: -24 }, { text: '24', value: 24 }, { text: '-10', value: -10 }], correctAnswer: -24, hint: 'A negative times a positive is always negative.' },
      { stoneIndex: 4, prompt: 'Stone 4: What is 15% of 80?', badge: 'Percentages', options: [{ text: '10', value: 10 }, { text: '12', value: 12 }, { text: '14', value: 14 }], correctAnswer: 12, hint: '10% of 80 is 8, 5% is 4. 8 + 4 = 12.' },
    ],
    '9-12': [
      { stoneIndex: 1, prompt: 'Stone 1: Solve for positive x: x² - 49 = 0', badge: 'Quadratic Root', options: [{ text: 'x = 7', value: 7 }, { text: 'x = 14', value: 14 }, { text: 'x = 49', value: 49 }], correctAnswer: 7, hint: 'x² = 49 => x = √49 = 7.' },
      { stoneIndex: 2, prompt: 'Stone 2: Evaluate: log₂(32) = ?', badge: 'Logarithms', options: [{ text: '4', value: 4 }, { text: '5', value: 5 }, { text: '6', value: 6 }], correctAnswer: 5, hint: '2 to what power equals 32? 2⁵ = 32.' },
      { stoneIndex: 3, prompt: 'Stone 3: Exact value of sin(30°):', badge: 'Trigonometry', options: [{ text: '1/2', value: '1/2' }, { text: '√3/2', value: 'sqrt3/2' }, { text: '1', value: '1' }], correctAnswer: '1/2', hint: 'In a 30-60-90 triangle, the side opposite 30° is half the hypotenuse.' },
      { stoneIndex: 4, prompt: 'Stone 4: Derivative d/dx of (3x² + 5x):', badge: 'Calculus Derivative', options: [{ text: '6x + 5', value: '6x+5' }, { text: '3x + 5', value: '3x+5' }, { text: '6x²', value: '6x2' }], correctAnswer: '6x+5', hint: 'Power rule: d/dx(xⁿ) = n·xⁿ⁻¹. 3(2x) + 5 = 6x + 5.' },
    ],
  },
  Science: {
    'K-2': [
      { stoneIndex: 1, prompt: 'Stone 1: What part of a plant grows under the soil?', badge: 'Plant Anatomy', options: [{ text: 'Roots', value: 'roots' }, { text: 'Leaves', value: 'leaves' }, { text: 'Flowers', value: 'flowers' }], correctAnswer: 'roots', hint: 'Roots soak up water and nutrients from the dirt.' },
      { stoneIndex: 2, prompt: 'Stone 2: Which of these is a LIVING thing?', badge: 'Living vs Non-living', options: [{ text: 'Pine Tree', value: 'tree' }, { text: 'Granite Rock', value: 'rock' }, { text: 'River Water', value: 'water' }], correctAnswer: 'tree', hint: 'Living things grow, breathe, and reproduce.' },
      { stoneIndex: 3, prompt: 'Stone 3: What season comes after winter when flowers bloom?', badge: 'Seasons', options: [{ text: 'Spring', value: 'spring' }, { text: 'Autumn', value: 'autumn' }, { text: 'Summer', value: 'summer' }], correctAnswer: 'spring', hint: 'Warm breezes and new green sprouts arrive in Spring.' },
      { stoneIndex: 4, prompt: 'Stone 4: What do birds use to fly in the forest air?', badge: 'Animal Adaptations', options: [{ text: 'Wings & Feathers', value: 'wings' }, { text: 'Gills', value: 'gills' }, { text: 'Scales', value: 'scales' }], correctAnswer: 'wings', hint: 'Feathered wings catch air currents.' },
    ],
    '3-5': [
      { stoneIndex: 1, prompt: 'Stone 1: Liquid water turning into vapor gas is called:', badge: 'Water Cycle', options: [{ text: 'Evaporation', value: 'evaporation' }, { text: 'Condensation', value: 'condensation' }, { text: 'Freezing', value: 'freezing' }], correctAnswer: 'evaporation', hint: 'Heat from the Sun causes water to evaporate upward.' },
      { stoneIndex: 2, prompt: 'Stone 2: What is the primary source of energy for forest ecosystems?', badge: 'Ecosystems', options: [{ text: 'The Sun', value: 'sun' }, { text: 'Soil', value: 'soil' }, { text: 'Wind', value: 'wind' }], correctAnswer: 'sun', hint: 'Plants capture sunlight to create food through photosynthesis.' },
      { stoneIndex: 3, prompt: 'Stone 3: What invisible force pulls an apple down from a branch?', badge: 'Forces', options: [{ text: 'Gravity', value: 'gravity' }, { text: 'Magnetism', value: 'magnetism' }, { text: 'Friction', value: 'friction' }], correctAnswer: 'gravity', hint: 'Earth pulls all masses toward its center with gravity.' },
      { stoneIndex: 4, prompt: 'Stone 4: An animal that eats both plants and animals is a(n):', badge: 'Food Chains', options: [{ text: 'Omnivore', value: 'omnivore' }, { text: 'Herbivore', value: 'herbivore' }, { text: 'Carnivore', value: 'carnivore' }], correctAnswer: 'omnivore', hint: 'Bears and humans eat both berries and fish—they are omnivores.' },
    ],
    '6-8': [
      { stoneIndex: 1, prompt: 'Stone 1: In plant cells, photosynthesis takes place inside:', badge: 'Cell Biology', options: [{ text: 'Chloroplasts', value: 'chloroplasts' }, { text: 'Nucleus', value: 'nucleus' }, { text: 'Cell Wall', value: 'wall' }], correctAnswer: 'chloroplasts', hint: 'Chloroplasts contain green chlorophyll pigments that absorb light.' },
      { stoneIndex: 2, prompt: 'Stone 2: What is the chemical formula for water?', badge: 'Chemistry', options: [{ text: 'H₂O', value: 'h2o' }, { text: 'CO₂', value: 'co2' }, { text: 'NaCl', value: 'nacl' }], correctAnswer: 'h2o', hint: 'Two hydrogen atoms bonded to one oxygen atom.' },
      { stoneIndex: 3, prompt: 'Stone 3: Rocks formed from cooling molten volcanic magma are:', badge: 'Earth Science', options: [{ text: 'Igneous', value: 'igneous' }, { text: 'Sedimentary', value: 'sedimentary' }, { text: 'Metamorphic', value: 'metamorphic' }], correctAnswer: 'igneous', hint: 'Ignis means fire in Latin; basalt and granite are igneous.' },
      { stoneIndex: 4, prompt: 'Stone 4: The law of conservation of energy states that energy cannot be:', badge: 'Physics', options: [{ text: 'Created or destroyed', value: 'conserved' }, { text: 'Transformed', value: 'transformed' }, { text: 'Stored', value: 'stored' }], correctAnswer: 'conserved', hint: 'Energy can only change forms, never disappear into nothingness.' },
    ],
    '9-12': [
      { stoneIndex: 1, prompt: 'Stone 1: The primary cellular currency for chemical energy is:', badge: 'Biochemistry', options: [{ text: 'ATP', value: 'atp' }, { text: 'DNA', value: 'dna' }, { text: 'Hemoglobin', value: 'hemoglobin' }], correctAnswer: 'atp', hint: 'Adenosine triphosphate releases energy when its phosphate bond hydrolyzes.' },
      { stoneIndex: 2, prompt: 'Stone 2: In a cross between two heterozygous parents (Bb × Bb), what ratio of offspring will show the dominant phenotype?', badge: 'Genetics', options: [{ text: '3 out of 4 (75%)', value: '75' }, { text: '1 out of 2 (50%)', value: '50' }, { text: '1 out of 4 (25%)', value: '25' }], correctAnswer: '75', hint: 'Punnett square yields BB, Bb, Bb (dominant) and bb (recessive).' },
      { stoneIndex: 3, prompt: 'Stone 3: Le Chatelier’s principle predicts that an exothermic reaction will shift in which direction when heat is added?', badge: 'Thermodynamics', options: [{ text: 'Toward the Reactants (Left)', value: 'left' }, { text: 'Toward the Products (Right)', value: 'right' }, { text: 'No change', value: 'none' }], correctAnswer: 'left', hint: 'Adding heat adds a product in exothermic reactions, shifting equilibrium left.' },
      { stoneIndex: 4, prompt: 'Stone 4: Magnitude of Earth’s gravitational acceleration g near sea level:', badge: 'Kinematics', options: [{ text: '9.8 m/s²', value: '9.8' }, { text: '3.0 × 10⁸ m/s', value: 'c' }, { text: '6.67 × 10⁻¹¹', value: 'G' }], correctAnswer: '9.8', hint: 'Standard freefall acceleration is approximately 9.8 meters per second squared.' },
    ],
  },
  'Language Arts': {
    'K-2': [
      { stoneIndex: 1, prompt: 'Stone 1: What letter does the word "FOREST" start with?', badge: 'Letters', options: [{ text: 'F', value: 'f' }, { text: 'T', value: 't' }, { text: 'S', value: 's' }], correctAnswer: 'f', hint: 'F makes the /f/ sound like in Fox and Forest.' },
      { stoneIndex: 2, prompt: 'Stone 2: What is the OPPOSITE of "DARK"?', badge: 'Antonyms', options: [{ text: 'LIGHT', value: 'light' }, { text: 'NIGHT', value: 'night' }, { text: 'COLD', value: 'cold' }], correctAnswer: 'light', hint: 'The sun brings bright light to chase away the dark.' },
      { stoneIndex: 3, prompt: 'Stone 3: Which mark goes at the end of an asking sentence?', badge: 'Punctuation', options: [{ text: 'Question Mark (?)', value: 'question' }, { text: 'Period (.)', value: 'period' }, { text: 'Comma (,)', value: 'comma' }], correctAnswer: 'question', hint: 'When asking "Where are we going?", use a question mark.' },
      { stoneIndex: 4, prompt: 'Stone 4: Find the naming word (noun): "The bird sang."', badge: 'Nouns', options: [{ text: 'Bird', value: 'bird' }, { text: 'Sang', value: 'sang' }, { text: 'The', value: 'the' }], correctAnswer: 'bird', hint: 'A noun names a person, place, or creature.' },
    ],
    '3-5': [
      { stoneIndex: 1, prompt: 'Stone 1: Identify the adjective: "The ancient oak towered above us."', badge: 'Adjectives', options: [{ text: 'ancient', value: 'ancient' }, { text: 'oak', value: 'oak' }, { text: 'towered', value: 'towered' }], correctAnswer: 'ancient', hint: 'Adjectives describe nouns. How was the oak described?' },
      { stoneIndex: 2, prompt: 'Stone 2: "The river was as smooth as glass" is a:', badge: 'Similes', options: [{ text: 'Simile', value: 'simile' }, { text: 'Metaphor', value: 'metaphor' }, { text: 'Hyperbole', value: 'hyperbole' }], correctAnswer: 'simile', hint: 'A comparison using "as" or "like" is a simile.' },
      { stoneIndex: 3, prompt: 'Stone 3: The prefix "RE-" in "rebuild" means:', badge: 'Prefixes', options: [{ text: 'Again', value: 'again' }, { text: 'Not', value: 'not' }, { text: 'Before', value: 'before' }], correctAnswer: 'again', hint: 'To rebuild is to build again.' },
      { stoneIndex: 4, prompt: 'Stone 4: What is a synonym for "LUMINOUS"?', badge: 'Vocabulary', options: [{ text: 'Glowing / Bright', value: 'glowing' }, { text: 'Dark', value: 'dark' }, { text: 'Quiet', value: 'quiet' }], correctAnswer: 'glowing', hint: 'A luminous crystal shines with glowing light.' },
    ],
    '6-8': [
      { stoneIndex: 1, prompt: 'Stone 1: Identify the subject in: "Across the river stood a stone beacon."', badge: 'Sentence Structure', options: [{ text: 'A stone beacon', value: 'beacon' }, { text: 'The river', value: 'river' }, { text: 'Stood', value: 'stood' }], correctAnswer: 'beacon', hint: 'Who or what stood across the river? The beacon did!' },
      { stoneIndex: 2, prompt: 'Stone 2: An extreme, deliberate exaggeration is called:', badge: 'Literary Devices', options: [{ text: 'Hyperbole', value: 'hyperbole' }, { text: 'Metaphor', value: 'metaphor' }, { text: 'Irony', value: 'irony' }], correctAnswer: 'hyperbole', hint: '"I have walked a million miles today" is hyperbole.' },
      { stoneIndex: 3, prompt: 'Stone 3: Tone of a passage filled with words like "gloomy, shadows, sorrow":', badge: 'Tone & Mood', options: [{ text: 'Somber / Melancholy', value: 'somber' }, { text: 'Celebratory', value: 'celebratory' }, { text: 'Playful', value: 'playful' }], correctAnswer: 'somber', hint: 'Words related to shadows and grief establish a somber mood.' },
      { stoneIndex: 4, prompt: 'Stone 4: Which sentence is punctuated correctly?', badge: 'Mechanics', options: [{ text: 'We gathered cedar, pine, and birch.', value: 'correct' }, { text: 'We gathered cedar pine, and birch', value: 'wrong1' }, { text: 'We gathered, cedar pine and birch', value: 'wrong2' }], correctAnswer: 'correct', hint: 'Items in a series are separated by commas.' },
    ],
    '9-12': [
      { stoneIndex: 1, prompt: 'Stone 1: A reference to an external historical, biblical, or mythological event:', badge: 'Literary Allusion', options: [{ text: 'Allusion', value: 'allusion' }, { text: 'Illusion', value: 'illusion' }, { text: 'Allegory', value: 'allegory' }], correctAnswer: 'allusion', hint: 'An allusion references another well-known text or figure.' },
      { stoneIndex: 2, prompt: 'Stone 2: The Greek root "CHRON" in chronology and chronic means:', badge: 'Etymology', options: [{ text: 'Time', value: 'time' }, { text: 'Color', value: 'color' }, { text: 'Earth', value: 'earth' }], correctAnswer: 'time', hint: 'Chronos was the mythological personification of time.' },
      { stoneIndex: 3, prompt: 'Stone 3: "Jumbo shrimp" and "deafening silence" are examples of:', badge: 'Rhetorical Devices', options: [{ text: 'Oxymoron', value: 'oxymoron' }, { text: 'Euphemism', value: 'euphemism' }, { text: 'Anaphora', value: 'anaphora' }], correctAnswer: 'oxymoron', hint: 'Pairing two contradictory terms together produces an oxymoron.' },
      { stoneIndex: 4, prompt: 'Stone 4: The rhetorical appeal based on the speaker’s credibility and ethical character:', badge: 'Classical Rhetoric', options: [{ text: 'Ethos', value: 'ethos' }, { text: 'Pathos', value: 'pathos' }, { text: 'Logos', value: 'logos' }], correctAnswer: 'ethos', hint: 'Ethos establishes trustworthiness and authoritative character.' },
    ],
  },
};

// Helper function to fetch bridge question
export function getBridgeQuestion(subject: MainSubject, grade: GradeLevel): ChallengeQuestion {
  return BRIDGE_CURRICULUM[subject]?.[grade] || BRIDGE_CURRICULUM.Math['6-8'];
}

// Helper function to fetch stepping stones
export function getSteppingStones(subject: MainSubject, grade: GradeLevel): SteppingStoneConfig[] {
  return STEPPING_STONES_CURRICULUM[subject]?.[grade] || STEPPING_STONES_CURRICULUM.Math['6-8'];
}

// ==========================================
// 3. KNOWLEDGE GATE CURRICULUM
// ==========================================
export interface GateRunePuzzle {
  id: number;
  runeName: string;
  question: string;
  figureDescription: string;
  options: { label: string; text: string; correct: boolean }[];
  explanation: string;
}

export const GATE_CURRICULUM: Record<MainSubject, Record<GradeLevel, GateRunePuzzle[]>> = {
  Math: {
    'K-2': [
      {
        id: 1,
        runeName: 'Triangle Corner Rune',
        question: 'How many corners (vertices) does a triangle have?',
        figureDescription: 'Count the sharp points on this triangular stone:',
        options: [
          { label: 'A', text: '3 Corners', correct: true },
          { label: 'B', text: '4 Corners', correct: false },
          { label: 'C', text: '0 Corners', correct: false },
          { label: 'D', text: '5 Corners', correct: false },
        ],
        explanation: 'A triangle always has exactly 3 sides and 3 corners!',
      },
      {
        id: 2,
        runeName: 'Double Berries Rune',
        question: 'Terra found 4 green berries. If Terra finds 4 more, how many are there in total?',
        figureDescription: '4 + 4 = ?',
        options: [
          { label: 'A', text: '8 Berries', correct: true },
          { label: 'B', text: '6 Berries', correct: false },
          { label: 'C', text: '10 Berries', correct: false },
          { label: 'D', text: '7 Berries', correct: false },
        ],
        explanation: '4 + 4 = 8! Doubling 4 makes 8!',
      },
      {
        id: 3,
        runeName: 'Shape Sorter Rune',
        question: 'Which shape is perfectly round with zero straight edges?',
        figureDescription: 'A smooth circular disc of river granite:',
        options: [
          { label: 'A', text: 'Circle', correct: true },
          { label: 'B', text: 'Square', correct: false },
          { label: 'C', text: 'Rectangle', correct: false },
          { label: 'D', text: 'Triangle', correct: false },
        ],
        explanation: 'A circle has a curved continuous boundary with 0 straight edges!',
      },
    ],
    '3-5': [
      {
        id: 1,
        runeName: 'Sacred Garden Area Rune',
        question: 'Calculate the area of a rectangular flower bed with length 8 meters and width 6 meters:',
        figureDescription: 'Area = Length × Width',
        options: [
          { label: 'A', text: 'Area = 48 m²', correct: true },
          { label: 'B', text: 'Area = 28 m²', correct: false },
          { label: 'C', text: 'Area = 14 m²', correct: false },
          { label: 'D', text: 'Area = 56 m²', correct: false },
        ],
        explanation: '8 × 6 = 48 square meters!',
      },
      {
        id: 2,
        runeName: 'Perimeter Boundary Rune',
        question: 'What is the perimeter (distance around the border) of a square garden bed with sides of 7 meters?',
        figureDescription: 'Perimeter = 4 × Side length',
        options: [
          { label: 'A', text: 'Perimeter = 28 m', correct: true },
          { label: 'B', text: 'Perimeter = 49 m', correct: false },
          { label: 'C', text: 'Perimeter = 21 m', correct: false },
          { label: 'D', text: 'Perimeter = 14 m', correct: false },
        ],
        explanation: '4 × 7 = 28 meters around the perimeter!',
      },
      {
        id: 3,
        runeName: 'Angle Classification Rune',
        question: 'An angle that measures exactly 90 degrees is known as a:',
        figureDescription: 'Square corner symbol ∟',
        options: [
          { label: 'A', text: 'Right Angle', correct: true },
          { label: 'B', text: 'Acute Angle (<90°)', correct: false },
          { label: 'C', text: 'Obtuse Angle (>90°)', correct: false },
          { label: 'D', text: 'Straight Angle (180°)', correct: false },
        ],
        explanation: 'A 90° angle is a perpendicular Right Angle!',
      },
    ],
    '6-8': [
      {
        id: 1,
        runeName: 'Triangle Angle Rune',
        question: 'Find the missing interior angle x of this sacred sanctuary triangle:',
        figureDescription: 'Angles are 60°, 70°, and x°. Interior sum = 180°',
        options: [
          { label: 'A', text: 'x = 50°', correct: true },
          { label: 'B', text: 'x = 40°', correct: false },
          { label: 'C', text: 'x = 60°', correct: false },
          { label: 'D', text: 'x = 90°', correct: false },
        ],
        explanation: '180° - 60° - 70° = 50°!',
      },
      {
        id: 2,
        runeName: 'Pythagorean Waystone',
        question: 'A right-angled triangle has legs of length 3 and 4. What is the length of hypotenuse c?',
        figureDescription: 'a² + b² = c²  ➔  3² + 4² = c²',
        options: [
          { label: 'A', text: 'c = 5', correct: true },
          { label: 'B', text: 'c = 7', correct: false },
          { label: 'C', text: 'c = 25', correct: false },
          { label: 'D', text: 'c = 6', correct: false },
        ],
        explanation: '3² + 4² = 9 + 16 = 25. √25 = 5!',
      },
      {
        id: 3,
        runeName: 'Supplementary Angle Rune',
        question: 'Two angles on a straight stone beam are supplementary. If one angle is 115°, what is angle y?',
        figureDescription: '115° + y = 180°',
        options: [
          { label: 'A', text: 'y = 65°', correct: true },
          { label: 'B', text: 'y = 75°', correct: false },
          { label: 'C', text: 'y = 55°', correct: false },
          { label: 'D', text: 'y = 85°', correct: false },
        ],
        explanation: '180° - 115° = 65°!',
      },
    ],
    '9-12': [
      {
        id: 1,
        runeName: 'Trigonometric Sine Waystone',
        question: 'In the unit circle, what is the exact value of sin(π/6) or sin(30°)?',
        figureDescription: 'Unit circle radius r = 1, y-coordinate at 30°',
        options: [
          { label: 'A', text: '1/2 (or 0.5)', correct: true },
          { label: 'B', text: '√3 / 2', correct: false },
          { label: 'C', text: '√2 / 2', correct: false },
          { label: 'D', text: '1', correct: false },
        ],
        explanation: 'sin(30°) = 1/2 in standard trigonometry!',
      },
      {
        id: 2,
        runeName: 'Coordinate Distance Rune',
        question: 'Find the Euclidean distance between points A(1, 2) and B(4, 6):',
        figureDescription: 'd = √[(x₂ - x₁)² + (y₂ - y₁)²]',
        options: [
          { label: 'A', text: 'd = 5', correct: true },
          { label: 'B', text: 'd = 7', correct: false },
          { label: 'C', text: 'd = 25', correct: false },
          { label: 'D', text: 'd = √7', correct: false },
        ],
        explanation: '√[(4 - 1)² + (6 - 2)²] = √[3² + 4²] = √25 = 5!',
      },
      {
        id: 3,
        runeName: 'Circle Equation Rune',
        question: 'What is the radius of the circle defined by (x - 3)² + (y + 1)² = 36?',
        figureDescription: '(x - h)² + (y - k)² = r²',
        options: [
          { label: 'A', text: 'r = 6', correct: true },
          { label: 'B', text: 'r = 36', correct: false },
          { label: 'C', text: 'r = 18', correct: false },
          { label: 'D', text: 'r = 12', correct: false },
        ],
        explanation: 'r² = 36, so radius r = √36 = 6!',
      },
    ],
  },
  Science: {
    'K-2': [
      {
        id: 1,
        runeName: 'Plant Sunshine Rune',
        question: 'What do green leaves catch to help the plant make food?',
        figureDescription: 'Warm golden beams through the forest canopy:',
        options: [
          { label: 'A', text: 'Sunlight', correct: true },
          { label: 'B', text: 'Moon dust', correct: false },
          { label: 'C', text: 'Shadows', correct: false },
          { label: 'D', text: 'Snowflakes', correct: false },
        ],
        explanation: 'Leaves use sunlight to grow big and strong!',
      },
      {
        id: 2,
        runeName: 'Animal Habitat Rune',
        question: 'Where does an eagle build its nest?',
        figureDescription: 'High in the ancient giant tree branches:',
        options: [
          { label: 'A', text: 'High in the Tree Canopy', correct: true },
          { label: 'B', text: 'Deep underwater in the river', correct: false },
          { label: 'C', text: 'Underground in a dark mole tunnel', correct: false },
          { label: 'D', text: 'Inside a hollow mushroom', correct: false },
        ],
        explanation: 'Eagles nest high in towering forest canopies to keep eggs safe.',
      },
      {
        id: 3,
        runeName: 'Seasonal Cycle Rune',
        question: 'In which season do deciduous tree leaves turn bright red, yellow, and orange?',
        figureDescription: 'Crisp breezes and colorful falling leaves:',
        options: [
          { label: 'A', text: 'Autumn (Fall)', correct: true },
          { label: 'B', text: 'Summer', correct: false },
          { label: 'C', text: 'Winter', correct: false },
          { label: 'D', text: 'Spring', correct: false },
        ],
        explanation: 'In Autumn, trees stop producing chlorophyll and reveal vibrant warm colors!',
      },
    ],
    '3-5': [
      {
        id: 1,
        runeName: 'Cloud Formation Rune',
        question: 'When water vapor cools and condenses in the sky, what forms?',
        figureDescription: 'Vapor ➔ Tiny water droplets clustered in the air:',
        options: [
          { label: 'A', text: 'Clouds', correct: true },
          { label: 'B', text: 'Sunlight', correct: false },
          { label: 'C', text: 'Earthquakes', correct: false },
          { label: 'D', text: 'Magma', correct: false },
        ],
        explanation: 'Condensation of water vapor forms clouds in the atmosphere!',
      },
      {
        id: 2,
        runeName: 'Producer Organism Rune',
        question: 'In a forest food chain, which organism is a PRODUCER that makes its own food?',
        figureDescription: 'Green ferns, wild blackberry bushes, and pine trees:',
        options: [
          { label: 'A', text: 'Green Fern Plant', correct: true },
          { label: 'B', text: 'Forest Wolf', correct: false },
          { label: 'C', text: 'Red Fox', correct: false },
          { label: 'D', text: 'River Salmon', correct: false },
        ],
        explanation: 'Plants are autotrophic producers using photosynthesis!',
      },
      {
        id: 3,
        runeName: 'States of Matter Rune',
        question: 'When ice in the mountain stream warms up and turns into liquid water, what process occurred?',
        figureDescription: 'Solid ➔ Liquid transition:',
        options: [
          { label: 'A', text: 'Melting', correct: true },
          { label: 'B', text: 'Freezing', correct: false },
          { label: 'C', text: 'Sublimation', correct: false },
          { label: 'D', text: 'Rusting', correct: false },
        ],
        explanation: 'Heat energy causes crystalline ice to melt into flowing liquid.',
      },
    ],
    '6-8': [
      {
        id: 1,
        runeName: 'Chlorophyll Synthesis Rune',
        question: 'What gas do forest plants absorb from the air during photosynthesis?',
        figureDescription: 'CO₂ + H₂O + Sunlight ➔ Glucose + O₂',
        options: [
          { label: 'A', text: 'Carbon Dioxide (CO₂)', correct: true },
          { label: 'B', text: 'Helium (He)', correct: false },
          { label: 'C', text: 'Argon (Ar)', correct: false },
          { label: 'D', text: 'Methane (CH₄)', correct: false },
        ],
        explanation: 'Plants absorb carbon dioxide from the air and release oxygen gas!',
      },
      {
        id: 2,
        runeName: 'Tectonic Plate Rune',
        question: 'Which type of rock is formed when layers of mineral sediment and sand are compressed over millions of years?',
        figureDescription: 'Layered horizontal strata on river canyon cliffs:',
        options: [
          { label: 'A', text: 'Sedimentary Rock', correct: true },
          { label: 'B', text: 'Igneous Rock', correct: false },
          { label: 'C', text: 'Metamorphic Rock', correct: false },
          { label: 'D', text: 'Volcanic Basalt', correct: false },
        ],
        explanation: 'Sedimentary rocks form through compaction and cementation of mineral sediments.',
      },
      {
        id: 3,
        runeName: 'Newtonian Velocity Rune',
        question: 'If a river current flows at 3 meters per second, how far will a wooden raft travel in 20 seconds?',
        figureDescription: 'Distance = Velocity × Time',
        options: [
          { label: 'A', text: '60 meters', correct: true },
          { label: 'B', text: '23 meters', correct: false },
          { label: 'C', text: '17 meters', correct: false },
          { label: 'D', text: '120 meters', correct: false },
        ],
        explanation: 'Distance = 3 m/s × 20 s = 60 meters!',
      },
    ],
    '9-12': [
      {
        id: 1,
        runeName: 'Cellular Respiration Rune',
        question: 'Which organelle is the primary site of ATP generation via the electron transport chain?',
        figureDescription: 'Double-membrane organelle with inner cristae folds:',
        options: [
          { label: 'A', text: 'Mitochondrion', correct: true },
          { label: 'B', text: 'Ribosome', correct: false },
          { label: 'C', text: 'Endoplasmic Reticulum', correct: false },
          { label: 'D', text: 'Golgi Apparatus', correct: false },
        ],
        explanation: 'The mitochondrion carries out oxidative phosphorylation to produce ATP!',
      },
      {
        id: 2,
        runeName: 'Chemical Equilibrium Rune',
        question: 'For an endothermic reaction (ΔH > 0), how does increasing temperature affect the equilibrium constant K?',
        figureDescription: 'Reactants + Heat ⇌ Products',
        options: [
          { label: 'A', text: 'K increases (shifts toward products)', correct: true },
          { label: 'B', text: 'K decreases (shifts toward reactants)', correct: false },
          { label: 'C', text: 'K remains strictly constant', correct: false },
          { label: 'D', text: 'K drops to zero immediately', correct: false },
        ],
        explanation: 'Per van ’t Hoff equation and Le Chatelier, adding heat drives endothermic equilibrium toward products.',
      },
      {
        id: 3,
        runeName: 'Mendelian Genetics Rune',
        question: 'In pea plants, tall (T) is dominant over short (t). What percentage of offspring from Tt × tt will be tall?',
        figureDescription: 'Punnett cross: Tt (heterozygous) × tt (homozygous recessive)',
        options: [
          { label: 'A', text: '50% Tall (Tt)', correct: true },
          { label: 'B', text: '75% Tall', correct: false },
          { label: 'C', text: '100% Tall', correct: false },
          { label: 'D', text: '25% Tall', correct: false },
        ],
        explanation: 'The Punnett square produces Tt, Tt, tt, tt => 2 out of 4 (50%) tall offspring.',
      },
    ],
  },
  'Language Arts': {
    'K-2': [
      {
        id: 1,
        runeName: 'First Sound Rune',
        question: 'What is the first sound you hear in the word "TREE"?',
        figureDescription: 'Listen to the sound: /t/ - /r/ - /ee/',
        options: [
          { label: 'A', text: 'Letter T (/t/)', correct: true },
          { label: 'B', text: 'Letter B (/b/)', correct: false },
          { label: 'C', text: 'Letter M (/m/)', correct: false },
          { label: 'D', text: 'Letter S (/s/)', correct: false },
        ],
        explanation: 'Tree begins with the letter T!',
      },
      {
        id: 2,
        runeName: 'Rhyming Acorn Rune',
        question: 'Which word rhymes with "LOG"?',
        figureDescription: 'L - O - G  ~  ?',
        options: [
          { label: 'A', text: 'FROG', correct: true },
          { label: 'B', text: 'LEAF', correct: false },
          { label: 'C', text: 'MUD', correct: false },
          { label: 'D', text: 'STONE', correct: false },
        ],
        explanation: 'Log and Frog both end with the -og sound!',
      },
      {
        id: 3,
        runeName: 'Sentence Starters Rune',
        question: 'Every sentence should begin with a:',
        figureDescription: 'Look at the first letter of a sentence:',
        options: [
          { label: 'A', text: 'Capital letter', correct: true },
          { label: 'B', text: 'Comma', correct: false },
          { label: 'C', text: 'Number only', correct: false },
          { label: 'D', text: 'Lowercase letter', correct: false },
        ],
        explanation: 'Sentences always start with a capital letter!',
      },
    ],
    '3-5': [
      {
        id: 1,
        runeName: 'Metaphorical Path Rune',
        question: '"The giant forest trees were silent green sentinels guarding the valley." This is an example of a:',
        figureDescription: 'Directly stating one thing IS another without "like" or "as":',
        options: [
          { label: 'A', text: 'Metaphor', correct: true },
          { label: 'B', text: 'Simile', correct: false },
          { label: 'C', text: 'Alliteration', correct: false },
          { label: 'D', text: 'Hyperbole', correct: false },
        ],
        explanation: 'Directly equating trees to sentinels is a metaphor!',
      },
      {
        id: 2,
        runeName: 'Context Clues Rune',
        question: 'In the sentence: "The ancient oak was so COLOSSAL that six explorers could barely link arms around its trunk," colossal means:',
        figureDescription: 'Infer the definition from the context clues:',
        options: [
          { label: 'A', text: 'Enormously huge', correct: true },
          { label: 'B', text: 'Very slender', correct: false },
          { label: 'C', text: 'Dead and fallen', correct: false },
          { label: 'D', text: 'Brightly colored', correct: false },
        ],
        explanation: 'Needing six people to encircle the trunk clues us that colossal means gigantic!',
      },
      {
        id: 3,
        runeName: 'Root Word Rune',
        question: 'In the word "UNBREAKABLE", what is the base root word?',
        figureDescription: 'Prefix [un-] + Root + Suffix [-able]',
        options: [
          { label: 'A', text: 'break', correct: true },
          { label: 'B', text: 'un', correct: false },
          { label: 'C', text: 'able', correct: false },
          { label: 'D', text: 'unbreak', correct: false },
        ],
        explanation: '"Break" is the core root word!',
      },
    ],
    '6-8': [
      {
        id: 1,
        runeName: 'Clauses & Conjunctions Rune',
        question: 'Which of the following is an INDEPENDENT clause that can stand alone as a complete sentence?',
        figureDescription: 'Subject + Predicate with a complete thought:',
        options: [
          { label: 'A', text: 'The mountain mist settled over the pine valley.', correct: true },
          { label: 'B', text: 'Although the mountain mist settled over the valley', correct: false },
          { label: 'C', text: 'Because of the dense mountain mist', correct: false },
          { label: 'D', text: 'While we walked through the pine valley', correct: false },
        ],
        explanation: 'Option A expresses a complete independent thought without subordinating conjunctions!',
      },
      {
        id: 2,
        runeName: 'Author’s Purpose Rune',
        question: 'A field guide describing step-by-step how to identify medicinal forest herbs is written primarily to:',
        figureDescription: 'Evaluate purpose: Persuade, Inform, Entertain, or Express?',
        options: [
          { label: 'A', text: 'Inform / Instruct', correct: true },
          { label: 'B', text: 'Persuade the reader to buy herbs', correct: false },
          { label: 'C', text: 'Entertain with funny jokes', correct: false },
          { label: 'D', text: 'Criticize old traditions', correct: false },
        ],
        explanation: 'Instructional field manuals aim to inform and educate the reader.',
      },
      {
        id: 3,
        runeName: 'Allusion & Symbolism Rune',
        question: 'In literature, an evergreen pine tree that stays green through harsh freezing winters frequently symbolizes:',
        figureDescription: 'Seasonal symbolism and motif:',
        options: [
          { label: 'A', text: 'Endurance, resilience, and immortality', correct: true },
          { label: 'B', text: 'Rapid decay and weakness', correct: false },
          { label: 'C', text: 'Sudden impulsive anger', correct: false },
          { label: 'D', text: 'Financial greed and gold', correct: false },
        ],
        explanation: 'Evergreens symbolize eternal life, steadfast endurance, and persistence through adversity.',
      },
    ],
    '9-12': [
      {
        id: 1,
        runeName: 'Rhetorical Fallacy Rune',
        question: 'Attacking an opponent’s personal character instead of addressing their substantive argument is known as:',
        figureDescription: 'Identify the informal logical fallacy:',
        options: [
          { label: 'A', text: 'Ad Hominem', correct: true },
          { label: 'B', text: 'Straw Man', correct: false },
          { label: 'C', text: 'Post Hoc Ergo Propter Hoc', correct: false },
          { label: 'D', text: 'False Dichotomy', correct: false },
        ],
        explanation: 'Ad hominem (Latin: "to the person") attacks the person rather than the argument.',
      },
      {
        id: 2,
        runeName: 'Syntactic Parallelism Rune',
        question: '"We must cultivate our intellect, protect our sanctuary, and inspire our community." This sentence demonstrates:',
        figureDescription: 'Repetition of grammatical form (Verb + Possessive + Noun):',
        options: [
          { label: 'A', text: 'Parallel Structure (Parallelism)', correct: true },
          { label: 'B', text: 'Chiasmus', correct: false },
          { label: 'C', text: 'Litotes', correct: false },
          { label: 'D', text: 'Antithesis', correct: false },
        ],
        explanation: 'Balancing three identical verb phrase clauses produces rhetorical parallelism.',
      },
      {
        id: 3,
        runeName: 'Etymology of Ecology Rune',
        question: 'The term "Ecology" stems from the Greek root "OIKOS", which originally meant:',
        figureDescription: 'Etymological history of ecological science:',
        options: [
          { label: 'A', text: 'House or Dwelling Place', correct: true },
          { label: 'B', text: 'Green Foliage', correct: false },
          { label: 'C', text: 'Wild Animal', correct: false },
          { label: 'D', text: 'River Water', correct: false },
        ],
        explanation: 'Oikos means "household" or "home"—ecology is the study of our planetary household!',
      },
    ],
  },
};

export function getKnowledgeGatePuzzles(subject: MainSubject, grade: GradeLevel): GateRunePuzzle[] {
  return GATE_CURRICULUM[subject]?.[grade] || GATE_CURRICULUM.Math['6-8'];
}

// ==========================================
// 4. DYNAMIC QUEST ROSTER GENERATOR
// ==========================================
export function generateQuestsForGradeAndSubject(grade: GradeLevel, subject: MainSubject) {
  const gradeLabel = GRADE_LABELS[grade];
  const subjectIcon = SUBJECT_ICONS[subject];

  if (subject === 'Math') {
    if (grade === 'K-2') {
      return [
        {
          id: 'quest-01',
          title: 'Plank Counting Bridge',
          description: 'Help Terra place the missing planks (5 + ? = 8) to span the stream safely.',
          learningObjective: 'Number Bonds & Early Addition',
          rewards: { xp: 100, seeds: 3, water: 2, fertilizer: 1 },
          completed: false,
          areaId: 'Algebra Grove',
          difficulty: 'starter' as const,
        },
        {
          id: 'quest-02',
          title: 'Visual Sprout Lab',
          description: 'Slide the sunlight and rain bars to watch the sapling grow 1 to 10 units high.',
          learningObjective: 'Visual Number Lines & Bar Measurements',
          rewards: { xp: 120, seeds: 3, water: 3, fertilizer: 1 },
          completed: false,
          areaId: 'Algebra Grove',
          difficulty: 'starter' as const,
        },
        {
          id: 'quest-03',
          title: 'River Stepping Stones: Counting Steps',
          description: 'Hop across 4 stepping stones by counting acorns, pebbles, and number patterns.',
          learningObjective: 'Addition, Subtraction & Patterns',
          rewards: { xp: 130, seeds: 4, water: 2, fertilizer: 2 },
          completed: false,
          areaId: 'Algebra Grove',
          difficulty: 'starter' as const,
        },
        {
          id: 'quest-04-geometry-canopy',
          title: 'Shape Canopy & Berry Garden',
          description: 'Sort forest shapes into triangles, circles, and squares to open the sun canopy.',
          learningObjective: '2D Shape Identification & Corners',
          rewards: { xp: 150, seeds: 5, water: 3, fertilizer: 2 },
          completed: false,
          areaId: 'Geometry Canopy',
          difficulty: 'standard' as const,
        },
        {
          id: 'quest-05-geometry-gate',
          title: 'Knowledge Gate: 3 Ancient Shape Runes',
          description: 'Solve the 3 shape guardian stones to awaken the emerald portal.',
          learningObjective: 'Sides, Vertices & Shape Properties',
          rewards: { xp: 160, seeds: 5, water: 3, fertilizer: 2 },
          completed: false,
          areaId: 'Geometry Canopy',
          difficulty: 'standard' as const,
        },
        {
          id: 'quest-06-probability-meadow',
          title: 'Flower Petal Meadow: Color Tally',
          description: 'Count bluebells and yellow buttercups to see which color is more likely!',
          learningObjective: 'More Likely vs Less Likely',
          rewards: { xp: 170, seeds: 5, water: 4, fertilizer: 2 },
          completed: false,
          areaId: 'Probability Meadow',
          difficulty: 'standard' as const,
        },
        {
          id: 'quest-07-trigonometry-trail',
          title: 'Tall Pine Tree Watchtower',
          description: 'Compare tree heights using tall vs short measuring sticks.',
          learningObjective: 'Height Comparison & Measurement',
          rewards: { xp: 180, seeds: 6, water: 4, fertilizer: 2 },
          completed: false,
          areaId: 'Trigonometry Trail',
          difficulty: 'standard' as const,
        },
        {
          id: 'quest-09-exponent-caverns',
          title: 'Crystal Cavern: Sparkle Doubling',
          description: 'Watch glowing cavern crystals double from 2 to 4 to 8 sparkles.',
          learningObjective: 'Doubling Numbers & Skip Counting',
          rewards: { xp: 200, seeds: 6, water: 5, fertilizer: 3 },
          completed: false,
          areaId: 'Exponent Cavern',
          difficulty: 'challenge' as const,
        },
        {
          id: 'quest-10-calculus-cascade',
          title: 'Water Cascade: Speed of the Stream',
          description: 'Measure how fast or slow water droplets trickle over mossy stones.',
          learningObjective: 'Fast vs Slow & Water Flow',
          rewards: { xp: 210, seeds: 7, water: 5, fertilizer: 3 },
          completed: false,
          areaId: 'Calculus Cascade',
          difficulty: 'challenge' as const,
        },
        {
          id: 'quest-11-matrix-cipher',
          title: 'Sanctuary Grid Maze',
          description: 'Follow row and column stepping paths (Row 2, Column 3) to find the treasure.',
          learningObjective: 'Simple Grid Navigation',
          rewards: { xp: 220, seeds: 8, water: 5, fertilizer: 4 },
          completed: false,
          areaId: 'Matrix Cryptography Shrine',
          difficulty: 'master' as const,
        },
        {
          id: 'quest-08-master-circle',
          title: 'Master Challenge: Forest Guardian Crown',
          description: 'Combine all your number bonds and shapes to awaken the sacred heart tree.',
          learningObjective: 'Grade K-2 Math Capstone Mastery',
          rewards: { xp: 250, seeds: 10, water: 6, fertilizer: 5 },
          completed: false,
          areaId: 'Exam Summit',
          difficulty: 'master' as const,
        },
      ];
    } else if (grade === '3-5') {
      return [
        {
          id: 'quest-01',
          title: 'Timber Array Multiplication Bridge',
          description: 'Calculate total crossbeams across 4 stone pillars (4 × 6 = 24) to lock the timber deck.',
          learningObjective: 'Multiplication Arrays & Repeated Addition',
          rewards: { xp: 110, seeds: 4, water: 2, fertilizer: 1 },
          completed: false,
          areaId: 'Algebra Grove',
          difficulty: 'standard' as const,
        },
        {
          id: 'quest-02',
          title: 'Visual Graph: Rectangle Area Maximizer',
          description: 'Adjust width and length sliders to maximize the planting area of the sanctuary bed.',
          learningObjective: 'Area = Length × Width & Perimeter',
          rewards: { xp: 130, seeds: 3, water: 2, fertilizer: 2 },
          completed: false,
          areaId: 'Algebra Grove',
          difficulty: 'standard' as const,
        },
        {
          id: 'quest-03',
          title: 'River Stepping Stones: Multiplication & Fractions',
          description: 'Solve multi-digit products, division facts, and equivalent fractions across the rushing river.',
          learningObjective: 'Multiplication, Division & Fractions',
          rewards: { xp: 140, seeds: 4, water: 2, fertilizer: 2 },
          completed: false,
          areaId: 'Algebra Grove',
          difficulty: 'standard' as const,
        },
        {
          id: 'quest-04-geometry-canopy',
          title: 'Sacred Polygon Shrine: Area Slicer',
          description: 'Decompose composite L-shaped garden beds into simple rectangles to compute total area.',
          learningObjective: 'Composite Area & Perimeter',
          rewards: { xp: 180, seeds: 5, water: 3, fertilizer: 2 },
          completed: false,
          areaId: 'Geometry Canopy',
          difficulty: 'challenge' as const,
        },
        {
          id: 'quest-05-geometry-gate',
          title: 'Knowledge Gate: Right Angles & Borders',
          description: 'Identify perpendicular 90° right angles and calculate garden perimeters.',
          learningObjective: 'Angles, Triangles & Perimeters',
          rewards: { xp: 190, seeds: 5, water: 3, fertilizer: 2 },
          completed: false,
          areaId: 'Geometry Canopy',
          difficulty: 'challenge' as const,
        },
        {
          id: 'quest-06-probability-meadow',
          title: 'Probability Meadow: Fair Dice & Colored Urns',
          description: 'Determine fractional probabilities (e.g. 3 out of 10 red stones) and fair game outcomes.',
          learningObjective: 'Simple Probability & Fractions',
          rewards: { xp: 200, seeds: 6, water: 4, fertilizer: 3 },
          completed: false,
          areaId: 'Probability Meadow',
          difficulty: 'challenge' as const,
        },
        {
          id: 'quest-07-trigonometry-trail',
          title: 'Sun Shadow Incline & Height Proportions',
          description: 'Use shadow length ratios to determine the true height of the mountain watchtower.',
          learningObjective: 'Proportional Reasoning & Ratios',
          rewards: { xp: 220, seeds: 6, water: 4, fertilizer: 3 },
          completed: false,
          areaId: 'Trigonometry Trail',
          difficulty: 'challenge' as const,
        },
        {
          id: 'quest-09-exponent-caverns',
          title: 'Exponent Cavern: Powers of Ten & Place Value',
          description: 'Harness crystal energies growing by powers of 10 (10, 100, 1,000, 10,000).',
          learningObjective: 'Powers of Ten & Place Value Scaling',
          rewards: { xp: 240, seeds: 7, water: 5, fertilizer: 4 },
          completed: false,
          areaId: 'Exponent Cavern',
          difficulty: 'master' as const,
        },
        {
          id: 'quest-10-calculus-cascade',
          title: 'Calculus Cascade: Water Reservoir Volume',
          description: 'Calculate volume of cubic basins (Length × Width × Height) and inflow accumulation.',
          learningObjective: 'Volume of Rectangular Prisms & Inflow',
          rewards: { xp: 250, seeds: 7, water: 5, fertilizer: 4 },
          completed: false,
          areaId: 'Calculus Cascade',
          difficulty: 'master' as const,
        },
        {
          id: 'quest-11-matrix-cipher',
          title: 'Coordinate Treasure Grid (X, Y)',
          description: 'Plot and translate coordinates (x, y) across the sanctuary map to unlock the seal.',
          learningObjective: 'Coordinate Plane Quadrant I',
          rewards: { xp: 260, seeds: 8, water: 6, fertilizer: 4 },
          completed: false,
          areaId: 'Matrix Cryptography Shrine',
          difficulty: 'master' as const,
        },
        {
          id: 'quest-08-master-circle',
          title: 'Master Challenge: The Four Pillar Sum',
          description: 'Synthesize multi-digit operations, fractions, and geometry in the grand altar trial.',
          learningObjective: 'Grade 3-5 Math Comprehensive Capstone',
          rewards: { xp: 300, seeds: 10, water: 8, fertilizer: 5 },
          completed: false,
          areaId: 'Exam Summit',
          difficulty: 'master' as const,
        },
      ];
    } else if (grade === '6-8') {
      return [
        {
          id: 'quest-01',
          title: 'Linear Cable Tension Balance',
          description: 'Solve the linear suspension equation 3x - 5 = 16 to balance cable tension.',
          learningObjective: 'Two-Step Linear Equations',
          rewards: { xp: 120, seeds: 4, water: 2, fertilizer: 2 },
          completed: false,
          areaId: 'Algebra Grove',
          difficulty: 'standard' as const,
        },
        {
          id: 'quest-02',
          title: 'Linear Slope Lab (y = mx + b)',
          description: 'Calibrate slope m and y-intercept b to guide the energy beam straight to the receiver.',
          learningObjective: 'Slope-Intercept Form & Rate of Change',
          rewards: { xp: 140, seeds: 3, water: 3, fertilizer: 2 },
          completed: false,
          areaId: 'Algebra Grove',
          difficulty: 'standard' as const,
        },
        {
          id: 'quest-03',
          title: 'River Stepping Stones: Algebraic Step Equations',
          description: 'Solve one-step, two-step, negative integer, and percentage steps across the river.',
          learningObjective: 'Pre-Algebra & Integer Operations',
          rewards: { xp: 150, seeds: 4, water: 3, fertilizer: 2 },
          completed: false,
          areaId: 'Algebra Grove',
          difficulty: 'standard' as const,
        },
        {
          id: 'quest-04-geometry-canopy',
          title: 'Sacred Polygon Shrine: Transversal Angles',
          description: 'Find alternate interior angles and prove the 180° triangle sum theorem.',
          learningObjective: 'Parallel Lines, Transversals & Angle Sums',
          rewards: { xp: 200, seeds: 6, water: 4, fertilizer: 3 },
          completed: false,
          areaId: 'Geometry Canopy',
          difficulty: 'challenge' as const,
        },
        {
          id: 'quest-05-geometry-gate',
          title: 'Knowledge Gate: Pythagorean Theorem',
          description: 'Calculate missing triangle sides using a² + b² = c² (3-4-5 and 5-12-13).',
          learningObjective: 'Pythagorean Theorem & Right Triangles',
          rewards: { xp: 210, seeds: 6, water: 4, fertilizer: 3 },
          completed: false,
          areaId: 'Geometry Canopy',
          difficulty: 'challenge' as const,
        },
        {
          id: 'quest-06-probability-meadow',
          title: 'The Dice of Destiny: Independent Events',
          description: 'Compute theoretical probabilities P(A and B), dice sums, and sample spaces.',
          learningObjective: 'Theoretical Probability & Compound Events',
          rewards: { xp: 220, seeds: 6, water: 4, fertilizer: 3 },
          completed: false,
          areaId: 'Probability Meadow',
          difficulty: 'challenge' as const,
        },
        {
          id: 'quest-07-trigonometry-trail',
          title: 'Trigonometric Ratios & Similar Triangles',
          description: 'Use tangent ratio opposite/adjacent to estimate watchtower heights.',
          learningObjective: 'Similar Triangles & Intro to Tangent',
          rewards: { xp: 230, seeds: 6, water: 4, fertilizer: 3 },
          completed: false,
          areaId: 'Trigonometry Trail',
          difficulty: 'challenge' as const,
        },
        {
          id: 'quest-09-exponent-caverns',
          title: 'Exponent Cavern: Laws of Exponents',
          description: 'Simplify power products (xᵃ · xᵇ = xᵃ⁺ᵇ) and negative integer exponents.',
          learningObjective: 'Exponent Rules & Scientific Notation',
          rewards: { xp: 250, seeds: 7, water: 5, fertilizer: 4 },
          completed: false,
          areaId: 'Exponent Cavern',
          difficulty: 'master' as const,
        },
        {
          id: 'quest-10-calculus-cascade',
          title: 'Calculus Cascade: Rate of Water Flow',
          description: 'Determine instantaneous rate of change ΔV/Δt and constant water acceleration.',
          learningObjective: 'Rates of Change & Linear Derivatives Intro',
          rewards: { xp: 260, seeds: 7, water: 5, fertilizer: 4 },
          completed: false,
          areaId: 'Calculus Cascade',
          difficulty: 'master' as const,
        },
        {
          id: 'quest-11-matrix-cipher',
          title: 'Matrix Cipher: System of Linear Equations',
          description: 'Solve 2x2 coordinate intersection balances and grid transformations.',
          learningObjective: 'Systems of Equations & 2D Grid Transforms',
          rewards: { xp: 270, seeds: 8, water: 6, fertilizer: 4 },
          completed: false,
          areaId: 'Matrix Cryptography Shrine',
          difficulty: 'master' as const,
        },
        {
          id: 'quest-08-master-circle',
          title: 'Master Challenge: Algebraic Altar Synthesis',
          description: 'Synthesize linear systems, Pythagorean calculations, and exponent laws.',
          learningObjective: 'Grade 6-8 Math Mastery Capstone',
          rewards: { xp: 320, seeds: 10, water: 8, fertilizer: 5 },
          completed: false,
          areaId: 'Exam Summit',
          difficulty: 'master' as const,
        },
      ];
    } else {
      // 9-12 High School Math
      return [
        {
          id: 'quest-01',
          title: 'Quadratic Arch Footholds',
          description: 'Factor x² - 5x + 6 = 0 into roots x = 2 and x = 3 to anchor the parabolic bridge.',
          learningObjective: 'Factoring Quadratic Equations & Roots',
          rewards: { xp: 140, seeds: 4, water: 2, fertilizer: 2 },
          completed: false,
          areaId: 'Algebra Grove',
          difficulty: 'standard' as const,
        },
        {
          id: 'quest-02',
          title: 'Parabola Trajectory Field Lab',
          description: 'Calibrate vertex form y = a(x - h)² + k and launch angles to hit target coordinates.',
          learningObjective: 'Quadratic Vertex Form & Projectile Kinematics',
          rewards: { xp: 160, seeds: 4, water: 3, fertilizer: 2 },
          completed: false,
          areaId: 'Algebra Grove',
          difficulty: 'standard' as const,
        },
        {
          id: 'quest-03',
          title: 'River Stepping Stones: Advanced Algebraic Stones',
          description: 'Solve quadratic roots, logarithms, trigonometric values, and polynomial derivatives.',
          learningObjective: 'Advanced Algebra, Trig & Pre-Calculus',
          rewards: { xp: 170, seeds: 5, water: 3, fertilizer: 2 },
          completed: false,
          areaId: 'Algebra Grove',
          difficulty: 'standard' as const,
        },
        {
          id: 'quest-04-geometry-canopy',
          title: 'Sacred Polygon Shrine & Sector Arcs',
          description: 'Calculate circular sector areas (1/2 r² θ), arc lengths, and coordinate polygon proofs.',
          learningObjective: 'Radian Measure, Sector Area & Coordinate Geometry',
          rewards: { xp: 240, seeds: 6, water: 4, fertilizer: 3 },
          completed: false,
          areaId: 'Geometry Canopy',
          difficulty: 'challenge' as const,
        },
        {
          id: 'quest-05-geometry-gate',
          title: 'Knowledge Gate: Unit Circle & Analytic Geometry',
          description: 'Unlock emerald seals using sin(30°), distance formulas, and circle radius equations.',
          learningObjective: 'Unit Circle, Analytic Geometry & Proofs',
          rewards: { xp: 250, seeds: 6, water: 4, fertilizer: 3 },
          completed: false,
          areaId: 'Geometry Canopy',
          difficulty: 'challenge' as const,
        },
        {
          id: 'quest-06-probability-meadow',
          title: 'The Dice of Destiny: Combinatorics & Expected Value',
          description: 'Calculate combinations nCr, conditional probability P(A|B), and expected values.',
          learningObjective: 'Combinatorics & Conditional Probability',
          rewards: { xp: 260, seeds: 7, water: 5, fertilizer: 3 },
          completed: false,
          areaId: 'Probability Meadow',
          difficulty: 'challenge' as const,
        },
        {
          id: 'quest-07-trigonometry-trail',
          title: 'Beacon of Tangents: Law of Sines & Cosines',
          description: 'Solve non-right triangles using Law of Cosines c² = a² + b² - 2ab cos(C).',
          learningObjective: 'Law of Sines, Cosines & Elevation',
          rewards: { xp: 270, seeds: 7, water: 5, fertilizer: 3 },
          completed: false,
          areaId: 'Trigonometry Trail',
          difficulty: 'challenge' as const,
        },
        {
          id: 'quest-09-exponent-caverns',
          title: 'Luminescent Crystal Lattice & Logarithms',
          description: 'Model exponential crystal growth N(t) = N₀ · 2^(t/k) and solve log₃(x) = 4.',
          learningObjective: 'Exponential Growth, Logarithms & Half-Life',
          rewards: { xp: 280, seeds: 8, water: 5, fertilizer: 4 },
          completed: false,
          areaId: 'Exponent Cavern',
          difficulty: 'master' as const,
        },
        {
          id: 'quest-10-calculus-cascade',
          title: 'The River of Fluxions & Velocity Integrals',
          description: 'Differentiate position to find velocity v(t) = s\'(t) and integrate ∫ 3t² dt for fluid volume.',
          learningObjective: 'Power Rule Derivatives & Definite Integrals',
          rewards: { xp: 300, seeds: 8, water: 6, fertilizer: 5 },
          completed: false,
          areaId: 'Calculus Cascade',
          difficulty: 'master' as const,
        },
        {
          id: 'quest-11-matrix-cipher',
          title: 'Matrix Cryptography Shrine & Determinants',
          description: 'Compute 2×2 determinant keys ad - bc, transform spatial vectors, and analyze singular matrices.',
          learningObjective: 'Determinants, Vector Transformations & Inverses',
          rewards: { xp: 310, seeds: 9, water: 6, fertilizer: 5 },
          completed: false,
          areaId: 'Matrix Cryptography Shrine',
          difficulty: 'master' as const,
        },
        {
          id: 'quest-08-master-circle',
          title: 'Master Challenge: Four Elemental Altars',
          description: 'Synthesize quadratic roots, derivatives, and vector determinants in the pinnacle trial.',
          learningObjective: 'Grade 9-12 Advanced Math Synthesis Capstone',
          rewards: { xp: 350, seeds: 10, water: 8, fertilizer: 6 },
          completed: false,
          areaId: 'Exam Summit',
          difficulty: 'master' as const,
        },
      ];
    }
  } else if (subject === 'Science') {
    return [
      {
        id: 'quest-01',
        title: 'Bridge Materials & Natural Forces',
        description: `Examine material density, buoyancy, and structural anchor roots across the river. (${gradeLabel})`,
        learningObjective: 'Material Properties, Buoyancy & Soil Anchors',
        rewards: { xp: 120, seeds: 4, water: 3, fertilizer: 1 },
        completed: false,
        areaId: 'Algebra Grove',
        difficulty: 'standard' as const,
      },
      {
        id: 'quest-02',
        title: 'Plant Photosynthesis & Sunlight Lab',
        description: `Adjust sunlight and water flow to discover how forest plants convert photon energy to biomass. (${gradeLabel})`,
        learningObjective: 'Photosynthesis, Chlorophyll & Carbon Fixation',
        rewards: { xp: 130, seeds: 3, water: 3, fertilizer: 2 },
        completed: false,
        areaId: 'Algebra Grove',
        difficulty: 'standard' as const,
      },
      {
        id: 'quest-03',
        title: 'River Stepping Stones: Natural Sciences',
        description: `Answer 4 stepping stone inquiries covering ecology, cell biology, and energy conservation. (${gradeLabel})`,
        learningObjective: 'Ecosystems, Cellular Biology & Thermodynamics',
        rewards: { xp: 150, seeds: 4, water: 3, fertilizer: 2 },
        completed: false,
        areaId: 'Algebra Grove',
        difficulty: 'standard' as const,
      },
      {
        id: 'quest-04-geometry-canopy',
        title: 'Nature’s Geometry: Honeycomb & Crystal Lattice',
        description: `Examine hexagonal honeycomb tessellations and crystalline geometry in nature. (${gradeLabel})`,
        learningObjective: 'Biological Geometry & Hexagonal Packing',
        rewards: { xp: 190, seeds: 5, water: 4, fertilizer: 2 },
        completed: false,
        areaId: 'Geometry Canopy',
        difficulty: 'challenge' as const,
      },
      {
        id: 'quest-05-geometry-gate',
        title: 'Knowledge Gate: 3 Biome Guardian Runes',
        description: `Prove your scientific mastery of energy cycles, tectonic strata, and living cells. (${gradeLabel})`,
        learningObjective: 'Cell Organelles, Rock Strata & Energy',
        rewards: { xp: 200, seeds: 6, water: 4, fertilizer: 3 },
        completed: false,
        areaId: 'Geometry Canopy',
        difficulty: 'challenge' as const,
      },
      {
        id: 'quest-06-probability-meadow',
        title: 'Genetics Meadow: Punnett Squares & Traits',
        description: `Calculate allele inheritance probabilities (dominant vs recessive traits) in forest flora. (${gradeLabel})`,
        learningObjective: 'Mendelian Genetics & Trait Probabilities',
        rewards: { xp: 210, seeds: 6, water: 4, fertilizer: 3 },
        completed: false,
        areaId: 'Probability Meadow',
        difficulty: 'challenge' as const,
      },
      {
        id: 'quest-07-trigonometry-trail',
        title: 'Optics & Solar Angle Elevation',
        description: `Measure solar incidence angles and light refraction through dewdrop prisms. (${gradeLabel})`,
        learningObjective: 'Optics, Angles of Incidence & Solar Flux',
        rewards: { xp: 220, seeds: 6, water: 4, fertilizer: 3 },
        completed: false,
        areaId: 'Trigonometry Trail',
        difficulty: 'challenge' as const,
      },
      {
        id: 'quest-09-exponent-caverns',
        title: 'Radioactive Half-Life & Bacterial Growth',
        description: `Track exponential bacterial population doubling and mineral isotopic decay. (${gradeLabel})`,
        learningObjective: 'Exponential Growth, Half-Life & Isotopes',
        rewards: { xp: 240, seeds: 7, water: 5, fertilizer: 4 },
        completed: false,
        areaId: 'Exponent Cavern',
        difficulty: 'master' as const,
      },
      {
        id: 'quest-10-calculus-cascade',
        title: 'Hydrodynamic Flow & Kinetic Velocity',
        description: `Analyze fluid dynamics, flow rates, and kinetic energy in the rushing cascade. (${gradeLabel})`,
        learningObjective: 'Kinematics, Flow Rate & Kinetic Energy',
        rewards: { xp: 250, seeds: 8, water: 5, fertilizer: 4 },
        completed: false,
        areaId: 'Calculus Cascade',
        difficulty: 'master' as const,
      },
      {
        id: 'quest-11-matrix-cipher',
        title: 'Chemical Stoichiometry Balance Shrine',
        description: `Balance chemical reaction equations and molecular vectors to unlock ancient elemental seals. (${gradeLabel})`,
        learningObjective: 'Chemical Balancing & Molecular Equilibrium',
        rewards: { xp: 260, seeds: 8, water: 6, fertilizer: 5 },
        completed: false,
        areaId: 'Matrix Cryptography Shrine',
        difficulty: 'master' as const,
      },
      {
        id: 'quest-08-master-circle',
        title: 'Master Challenge: The Biosphere Altar',
        description: `Unite all ecological, chemical, and physical principles to regenerate the ancient world tree. (${gradeLabel})`,
        learningObjective: 'Comprehensive Science Biosphere Capstone',
        rewards: { xp: 300, seeds: 10, water: 8, fertilizer: 6 },
        completed: false,
        areaId: 'Exam Summit',
        difficulty: 'master' as const,
      },
    ];
  } else {
    // Language Arts
    return [
      {
        id: 'quest-01',
        title: 'The Inscription Bridge & Dynamic Words',
        description: `Carve poetic rhymes, vivid action verbs, and rhetorical keystones into the bridge. (${gradeLabel})`,
        learningObjective: 'Phonology, Vivid Verbs & Classical Rhetoric',
        rewards: { xp: 120, seeds: 4, water: 3, fertilizer: 1 },
        completed: false,
        areaId: 'Algebra Grove',
        difficulty: 'standard' as const,
      },
      {
        id: 'quest-02',
        title: 'Narrative Arc Plot Mountain Lab',
        description: `Chart story tension through Exposition, Inciting Incident, Climax, and Resolution. (${gradeLabel})`,
        learningObjective: 'Narrative Arcs, Plot Progression & Pacing',
        rewards: { xp: 130, seeds: 3, water: 3, fertilizer: 2 },
        completed: false,
        areaId: 'Algebra Grove',
        difficulty: 'standard' as const,
      },
      {
        id: 'quest-03',
        title: 'River Stepping Stones: Vocabulary & Grammar',
        description: `Step across the water by identifying parts of speech, literary devices, and Greek/Latin roots. (${gradeLabel})`,
        learningObjective: 'Etymology, Grammar & Literary Devices',
        rewards: { xp: 150, seeds: 4, water: 3, fertilizer: 2 },
        completed: false,
        areaId: 'Algebra Grove',
        difficulty: 'standard' as const,
      },
      {
        id: 'quest-04-geometry-canopy',
        title: 'Visual Imagery & Concrete Poetry Shrine',
        description: `Craft vivid visual imagery and shape-poetry echoing the forest canopy leaves. (${gradeLabel})`,
        learningObjective: 'Sensory Imagery & Figurative Description',
        rewards: { xp: 190, seeds: 5, water: 4, fertilizer: 2 },
        completed: false,
        areaId: 'Geometry Canopy',
        difficulty: 'challenge' as const,
      },
      {
        id: 'quest-05-geometry-gate',
        title: 'Knowledge Gate: 3 Literary Guardian Runes',
        description: `Decode ancient runic allegories, parallel clauses, and author purpose. (${gradeLabel})`,
        learningObjective: 'Allegory, Parallelism & Critical Reading',
        rewards: { xp: 200, seeds: 6, water: 4, fertilizer: 3 },
        completed: false,
        areaId: 'Geometry Canopy',
        difficulty: 'challenge' as const,
      },
      {
        id: 'quest-06-probability-meadow',
        title: 'Poetic Meter & Rhyme Distribution Meadow',
        description: `Explore iambic meters, syllable stress patterns, and stanza rhyme schemes. (${gradeLabel})`,
        learningObjective: 'Poetic Meter, Rhythm & Stanza Forms',
        rewards: { xp: 210, seeds: 6, water: 4, fertilizer: 3 },
        completed: false,
        areaId: 'Probability Meadow',
        difficulty: 'challenge' as const,
      },
      {
        id: 'quest-07-trigonometry-trail',
        title: 'Perspective & Point of View Watchtower',
        description: `Differentiate 1st person, 3rd person limited, and 3rd person omniscient narrative vantage points. (${gradeLabel})`,
        learningObjective: 'Narrative Point of View & Perspective',
        rewards: { xp: 220, seeds: 6, water: 4, fertilizer: 3 },
        completed: false,
        areaId: 'Trigonometry Trail',
        difficulty: 'challenge' as const,
      },
      {
        id: 'quest-09-exponent-caverns',
        title: 'Etymological Roots & Morphological Growth',
        description: `Trace how single Greek and Latin morphemes compound exponentially into modern vocabularies. (${gradeLabel})`,
        learningObjective: 'Morphology, Prefixes, Suffixes & Roots',
        rewards: { xp: 240, seeds: 7, water: 5, fertilizer: 4 },
        completed: false,
        areaId: 'Exponent Cavern',
        difficulty: 'master' as const,
      },
      {
        id: 'quest-10-calculus-cascade',
        title: 'Syntax Flow & Pacing in Prose',
        description: `Master cadence, sentence length variety, and transitions in evocative storytelling. (${gradeLabel})`,
        learningObjective: 'Syntactic Variety, Cadence & Flow',
        rewards: { xp: 250, seeds: 8, water: 5, fertilizer: 4 },
        completed: false,
        areaId: 'Calculus Cascade',
        difficulty: 'master' as const,
      },
      {
        id: 'quest-11-matrix-cipher',
        title: 'The Semantic Cipher & Classical Fallacies',
        description: `Identify rhetorical fallacies (Ad Hominem, Straw Man) and decipher logical argument structures. (${gradeLabel})`,
        learningObjective: 'Argumentation, Logic & Rhetorical Analysis',
        rewards: { xp: 260, seeds: 8, water: 6, fertilizer: 5 },
        completed: false,
        areaId: 'Matrix Cryptography Shrine',
        difficulty: 'master' as const,
      },
      {
        id: 'quest-08-master-circle',
        title: 'Master Challenge: The Lexicon Summit',
        description: `Deliver an eloquent synthesis of rhetorical devices, moral themes, and textual evidence. (${gradeLabel})`,
        learningObjective: 'Grade-level Language Arts Capstone Mastery',
        rewards: { xp: 300, seeds: 10, water: 8, fertilizer: 6 },
        completed: false,
        areaId: 'Exam Summit',
        difficulty: 'master' as const,
      },
    ];
  }
}

// ==========================================
// 5. GETTER UTILITIES FOR CHALLENGE COMPONENTS
// ==========================================

export function getBridgeCurriculum(arg1: any, arg2: any): ChallengeQuestion {
  const grade: GradeLevel = ['K-2', '3-5', '6-8', '9-12'].includes(arg1) ? arg1 : arg2 || '6-8';
  const subject: MainSubject = ['Math', 'Science', 'Language Arts'].includes(arg2) ? arg2 : arg1 || 'Math';
  return BRIDGE_CURRICULUM[subject]?.[grade] || BRIDGE_CURRICULUM.Math['6-8'];
}

export function getSteppingStonesCurriculum(arg1: any, arg2: any): SteppingStoneConfig[] {
  const grade: GradeLevel = ['K-2', '3-5', '6-8', '9-12'].includes(arg1) ? arg1 : arg2 || '6-8';
  const subject: MainSubject = ['Math', 'Science', 'Language Arts'].includes(arg2) ? arg2 : arg1 || 'Math';
  return STEPPING_STONES_CURRICULUM[subject]?.[grade] || STEPPING_STONES_CURRICULUM.Math['6-8'];
}

export function getGateCurriculum(arg1: any, arg2: any): GateRunePuzzle[] {
  const grade: GradeLevel = ['K-2', '3-5', '6-8', '9-12'].includes(arg1) ? arg1 : arg2 || '6-8';
  const subject: MainSubject = ['Math', 'Science', 'Language Arts'].includes(arg2) ? arg2 : arg1 || 'Math';
  return GATE_CURRICULUM[subject]?.[grade] || GATE_CURRICULUM.Math['6-8'];
}

// ==========================================
// 6. ORIENTATION TRIAL CURRICULUM
// ==========================================

export const ORIENTATION_CURRICULUM: Record<MainSubject, Record<GradeLevel, OrientationQuestion[]>> = {
  Math: {
    'K-2': [
      {
        id: 1,
        question: 'Count the woodland acorns: 4 on the moss plus 3 fallen from the oak.',
        equation: '4 + 3 = ?',
        options: [
          { label: 'A', text: '6', correct: false },
          { label: 'B', text: '7', correct: true },
          { label: 'C', text: '8', correct: false },
        ],
        explanation: '4 + 3 = 7 total acorns collected for winter!',
      },
      {
        id: 2,
        question: 'Terra had 10 wild blueberries and shared 4 with the forest squirrel.',
        equation: '10 - 4 = ?',
        options: [
          { label: 'A', text: '6', correct: true },
          { label: 'B', text: '5', correct: false },
          { label: 'C', text: '7', correct: false },
        ],
        explanation: '10 - 4 = 6 blueberries remaining!',
      },
      {
        id: 3,
        question: 'Which number is the largest in this forest cluster?',
        equation: 'Compare: 12, 19, 15',
        options: [
          { label: 'A', text: '12', correct: false },
          { label: 'B', text: '15', correct: false },
          { label: 'C', text: '19', correct: true },
        ],
        explanation: '19 is greater than both 12 and 15.',
      },
    ],
    '3-5': [
      {
        id: 1,
        question: 'Terra plants 7 seedling rows with 8 saplings in each row. How many saplings total?',
        equation: '7 × 8 = ?',
        options: [
          { label: 'A', text: '54', correct: false },
          { label: 'B', text: '56', correct: true },
          { label: 'C', text: '64', correct: false },
        ],
        explanation: '7 × 8 = 56 saplings rooted in the soil!',
      },
      {
        id: 2,
        question: 'A forest trail is divided into 4 quarters. Explorer Ash walked 3/4 of it. How much remains?',
        equation: '1 - 3/4 = ?',
        options: [
          { label: 'A', text: '1/4', correct: true },
          { label: 'B', text: '1/2', correct: false },
          { label: 'C', text: '2/4', correct: false },
        ],
        explanation: '4/4 - 3/4 = 1/4 of the trail left to explore.',
      },
      {
        id: 3,
        question: 'What is the perimeter of a rectangular woodland clearing with length 9m and width 5m?',
        equation: 'P = 2 × (9 + 5)',
        options: [
          { label: 'A', text: '45m', correct: false },
          { label: 'B', text: '28m', correct: true },
          { label: 'C', text: '32m', correct: false },
        ],
        explanation: '2 × (9 + 5) = 2 × 14 = 28 meters.',
      },
    ],
    '6-8': [
      {
        id: 1,
        question: 'Solve for the unknown coordinate x in this woodland trail equation:',
        equation: '2x + 6 = 18',
        options: [
          { label: 'A', text: 'x = 4', correct: false },
          { label: 'B', text: 'x = 6', correct: true },
          { label: 'C', text: 'x = 8', correct: false },
        ],
        explanation: 'Subtract 6: 2x = 12. Divide by 2: x = 6!',
      },
      {
        id: 2,
        question: 'A trail map scale shows 1 cm = 50 meters. If the river distance is 4.5 cm, what is the real distance?',
        equation: '4.5 × 50 = ?',
        options: [
          { label: 'A', text: '225 meters', correct: true },
          { label: 'B', text: '200 meters', correct: false },
          { label: 'C', text: '250 meters', correct: false },
        ],
        explanation: '4.5 × 50 = 225 meters through the woods.',
      },
      {
        id: 3,
        question: 'What is the value of 3³ - 2²?',
        equation: '3³ - 2² = ?',
        options: [
          { label: 'A', text: '23', correct: true },
          { label: 'B', text: '25', correct: false },
          { label: 'C', text: '19', correct: false },
        ],
        explanation: '27 - 4 = 23.',
      },
    ],
    '9-12': [
      {
        id: 1,
        question: 'Find all real roots for the quadratic arch foundation:',
        equation: 'x² - 9 = 0',
        options: [
          { label: 'A', text: 'x = 3 only', correct: false },
          { label: 'B', text: 'x = 3 and x = -3', correct: true },
          { label: 'C', text: 'x = 9 and x = -9', correct: false },
        ],
        explanation: 'Difference of squares: (x - 3)(x + 3) = 0 => x = ±3.',
      },
      {
        id: 2,
        question: 'What is the slope (gradient) of the line passing through points (2, 3) and (6, 11)?',
        equation: 'm = (y₂ - y₁) / (x₂ - x₁)',
        options: [
          { label: 'A', text: 'm = 2', correct: true },
          { label: 'B', text: 'm = 4', correct: false },
          { label: 'C', text: 'm = 1/2', correct: false },
        ],
        explanation: 'm = (11 - 3) / (6 - 2) = 8 / 4 = 2.',
      },
      {
        id: 3,
        question: 'Evaluate the trigonometric ratio for an angle of 30° on the watchtower triangle:',
        equation: 'sin(30°) = ?',
        options: [
          { label: 'A', text: '1/2', correct: true },
          { label: 'B', text: '√3/2', correct: false },
          { label: 'C', text: '1', correct: false },
        ],
        explanation: 'sin(30°) = 1/2 or 0.5 exactly.',
      },
    ],
  },
  Science: {
    'K-2': [
      {
        id: 1,
        question: 'Which of these gives a green forest sprout the energy it needs to grow tall?',
        equation: '🌱 Sprout Growth Energy',
        options: [
          { label: 'A', text: 'Sunlight and Water', correct: true },
          { label: 'B', text: 'Dark Cave and Sand', correct: false },
          { label: 'C', text: 'Cold Snow alone', correct: false },
        ],
        explanation: 'Sunlight, water, and rich soil help plants make their own food!',
      },
      {
        id: 2,
        question: 'Which part of an ancient tree anchors it deep into the ground and drinks water?',
        equation: '🌲 Tree Anatomy',
        options: [
          { label: 'A', text: 'Roots', correct: true },
          { label: 'B', text: 'Leaves', correct: false },
          { label: 'C', text: 'Twigs', correct: false },
        ],
        explanation: 'Roots branch underground to absorb moisture and stabilize the trunk.',
      },
      {
        id: 3,
        question: 'What happens when water in the river gets very, very cold in winter?',
        equation: '❄️ Water State Change',
        options: [
          { label: 'A', text: 'It turns into solid ice', correct: true },
          { label: 'B', text: 'It boils into steam', correct: false },
          { label: 'C', text: 'It turns into glowing stone', correct: false },
        ],
        explanation: 'At 0°C (32°F), liquid water freezes into solid ice.',
      },
    ],
    '3-5': [
      {
        id: 1,
        question: 'In a woodland food chain, which organism is a primary producer?',
        equation: '☀️ Energy Flow',
        options: [
          { label: 'A', text: 'Oak Tree & Wild Ferns', correct: true },
          { label: 'B', text: 'Woodland Fox', correct: false },
          { label: 'C', text: 'Forest Owl', correct: false },
        ],
        explanation: 'Plants use sunlight to produce glucose, making them primary producers.',
      },
      {
        id: 2,
        question: 'What process describes water evaporating from leaves, forming clouds, and raining?',
        equation: '🌧️ The Biosphere Cycle',
        options: [
          { label: 'A', text: 'The Water Cycle', correct: true },
          { label: 'B', text: 'Rock Metamorphism', correct: false },
          { label: 'C', text: 'Magnetic Drift', correct: false },
        ],
        explanation: 'Evaporation, condensation, and precipitation form the global water cycle.',
      },
      {
        id: 3,
        question: 'Which state of matter has a definite volume but takes the shape of its container?',
        equation: '🧊 -> 💧 -> 💨',
        options: [
          { label: 'A', text: 'Liquid', correct: true },
          { label: 'B', text: 'Solid', correct: false },
          { label: 'C', text: 'Gas', correct: false },
        ],
        explanation: 'Liquids flow and take the shape of their container while retaining fixed volume.',
      },
    ],
    '6-8': [
      {
        id: 1,
        question: 'Which organelle inside plant leaf cells contains chlorophyll and captures sunlight?',
        equation: '🌿 Cellular Biology',
        options: [
          { label: 'A', text: 'Chloroplast', correct: true },
          { label: 'B', text: 'Mitochondria', correct: false },
          { label: 'C', text: 'Vacuole', correct: false },
        ],
        explanation: 'Chloroplasts absorb photons to drive photosynthesis.',
      },
      {
        id: 2,
        question: 'According to Newton’s First Law, an object at rest in the forest will remain at rest unless:',
        equation: 'F_net = 0',
        options: [
          { label: 'A', text: 'Acted upon by an unbalanced external force', correct: true },
          { label: 'B', text: 'It runs out of chemical potential energy', correct: false },
          { label: 'C', text: 'Its velocity reaches thermal equilibrium', correct: false },
        ],
        explanation: 'An unbalanced net force is required to accelerate any mass.',
      },
      {
        id: 3,
        question: 'What gas do forest trees absorb during the light reactions of photosynthesis?',
        equation: '6 CO₂ + 6 H₂O ➔ C₆H₁₂O₆ + 6 O₂',
        options: [
          { label: 'A', text: 'Carbon Dioxide (CO₂)', correct: true },
          { label: 'B', text: 'Methane (CH₄)', correct: false },
          { label: 'C', text: 'Nitrogen Gas (N₂)', correct: false },
        ],
        explanation: 'Trees sequester atmospheric CO₂ to build cellulose and biomass.',
      },
    ],
    '9-12': [
      {
        id: 1,
        question: 'In cellular respiration, what molecule acts as the primary biochemical energy currency?',
        equation: 'ADP + Pi ➔ Energy Currency',
        options: [
          { label: 'A', text: 'Adenosine Triphosphate (ATP)', correct: true },
          { label: 'B', text: 'Hemoglobin', correct: false },
          { label: 'C', text: 'Ribosomal RNA', correct: false },
        ],
        explanation: 'ATP transfers phosphate bonds to drive endergonic cellular reactions.',
      },
      {
        id: 2,
        question: 'Which chemical bond involves the sharing of electron pairs between nonmetal atoms?',
        equation: 'H : O : H',
        options: [
          { label: 'A', text: 'Covalent bond', correct: true },
          { label: 'B', text: 'Ionic bond', correct: false },
          { label: 'C', text: 'Metallic bond', correct: false },
        ],
        explanation: 'Covalent bonds form when electronegative atoms share valence electrons.',
      },
      {
        id: 3,
        question: 'What ecological principle explains why only about 10% of energy transfers between trophic levels?',
        equation: 'Trophic Efficiency: ~10%',
        options: [
          { label: 'A', text: 'Second Law of Thermodynamics (Entropy & Metabolic Heat)', correct: true },
          { label: 'B', text: 'Law of Conservation of Momentum', correct: false },
          { label: 'C', text: 'Boyle’s Ideal Gas Law', correct: false },
        ],
        explanation: 'Metabolic maintenance and entropy loss radiate ~90% of consumed energy as heat.',
      },
    ],
  },
  'Language Arts': {
    'K-2': [
      {
        id: 1,
        question: 'Which of these forest words rhymes with "TREE"?',
        equation: 'Rhyme Challenge',
        options: [
          { label: 'A', text: 'BEE', correct: true },
          { label: 'B', text: 'BARK', correct: false },
          { label: 'C', text: 'LEAF', correct: false },
        ],
        explanation: 'Tree and Bee share the matching -ee sound!',
      },
      {
        id: 2,
        question: 'Which letter should be capitalized in this woodland sentence?',
        equation: '"the green moss grows on stone."',
        options: [
          { label: 'A', text: 'Capitalize "T" in "The"', correct: true },
          { label: 'B', text: 'Capitalize "m" in "moss"', correct: false },
          { label: 'C', text: 'Capitalize "s" in "stone"', correct: false },
        ],
        explanation: 'Every sentence begins with a capital letter!',
      },
      {
        id: 3,
        question: 'What punctuation mark goes at the end of a curious question?',
        equation: '"Where did the baby deer run [ ? ]"',
        options: [
          { label: 'A', text: 'Question mark (?)', correct: true },
          { label: 'B', text: 'Period (.)', correct: false },
          { label: 'C', text: 'Exclamation mark (!)', correct: false },
        ],
        explanation: 'Questions always conclude with a question mark (?)!',
      },
    ],
    '3-5': [
      {
        id: 1,
        question: 'Identify the vivid ACTION VERB in this forest sentence:',
        equation: '"The swift hawk glided silently across the cedar canopy."',
        options: [
          { label: 'A', text: 'glided', correct: true },
          { label: 'B', text: 'swift', correct: false },
          { label: 'C', text: 'canopy', correct: false },
        ],
        explanation: '"Glided" describes the physical action of flying gracefully.',
      },
      {
        id: 2,
        question: '"The morning dew sparkled like tiny diamonds on the grass." What figure of speech is this?',
        equation: 'Figurative Language',
        options: [
          { label: 'A', text: 'Simile (using "like")', correct: true },
          { label: 'B', text: 'Metaphor (direct renaming)', correct: false },
          { label: 'C', text: 'Alliteration', correct: false },
        ],
        explanation: 'Comparisons using "like" or "as" are similes.',
      },
      {
        id: 3,
        question: 'What prefix added to the root word "CYCLE" means to use again?',
        equation: '[ ? ] + cycle = reuse',
        options: [
          { label: 'A', text: 're- (Recycle)', correct: true },
          { label: 'B', text: 'un- (Uncycle)', correct: false },
          { label: 'C', text: 'pre- (Precycle)', correct: false },
        ],
        explanation: 'The Latin prefix "re-" means again or back.',
      },
    ],
    '6-8': [
      {
        id: 1,
        question: 'Which sentence demonstrates dynamic ACTIVE VOICE?',
        equation: 'Active vs Passive Syntax',
        options: [
          { label: 'A', text: 'The river carved deep canyons through the ancient limestone.', correct: true },
          { label: 'B', text: 'Deep canyons were carved by the river through limestone.', correct: false },
          { label: 'C', text: 'The ancient limestone was being eroded by moving water.', correct: false },
        ],
        explanation: 'Active voice places the agent ("The river") as the grammatical subject performing the action.',
      },
      {
        id: 2,
        question: 'What literary device is used when an author hints at events that will happen later in the story?',
        equation: 'Narrative Craft',
        options: [
          { label: 'A', text: 'Foreshadowing', correct: true },
          { label: 'B', text: 'Hyperbole', correct: false },
          { label: 'C', text: 'Personification', correct: false },
        ],
        explanation: 'Foreshadowing plants early narrative clues that anticipate future plot developments.',
      },
      {
        id: 3,
        question: 'Choose the word with a negative connotation compared to neutral "curious":',
        equation: 'Nuance & Connotation',
        options: [
          { label: 'A', text: 'Nosy', correct: true },
          { label: 'B', text: 'Inquisitive', correct: false },
          { label: 'C', text: 'Interested', correct: false },
        ],
        explanation: '"Nosy" carries an intrusive, unwelcome negative connotation.',
      },
    ],
    '9-12': [
      {
        id: 1,
        question: 'Which rhetorical appeal relies on logical reasoning, verifiable evidence, and statistics?',
        equation: 'Aristotelian Appeals',
        options: [
          { label: 'A', text: 'Logos', correct: true },
          { label: 'B', text: 'Ethos', correct: false },
          { label: 'C', text: 'Pathos', correct: false },
        ],
        explanation: 'Logos appeals to the intellect through logical structure and factual data.',
      },
      {
        id: 2,
        question: '"Ask not what your forest can do for you; ask what you can do for your forest." What scheme is this?',
        equation: 'Rhetorical Schemes',
        options: [
          { label: 'A', text: 'Chiasmus (reversed parallel structure)', correct: true },
          { label: 'B', text: 'Oxymoron', correct: false },
          { label: 'C', text: 'Synecdoche', correct: false },
        ],
        explanation: 'Chiasmus inverts the syntactic order of corresponding words in adjacent phrases.',
      },
      {
        id: 3,
        question: 'When a speaker praises an opponent for "honesty" while revealing their deception, what irony is present?',
        equation: 'Dramatic vs Situational vs Verbal',
        options: [
          { label: 'A', text: 'Verbal Irony', correct: true },
          { label: 'B', text: 'Dramatic Irony', correct: false },
          { label: 'C', text: 'Situational Irony', correct: false },
        ],
        explanation: 'Verbal irony occurs when stated words directly contradict the speaker’s intended meaning.',
      },
    ],
  },
};

export function getOrientationTrial(grade: GradeLevel, subject: MainSubject): OrientationQuestion[] {
  return ORIENTATION_CURRICULUM[subject]?.[grade] || ORIENTATION_CURRICULUM.Math['6-8'];
}

// ==========================================
// 7. MASTER CHALLENGE DATA MODEL
// ==========================================

export interface MasterChallengeOption {
  id: number;
  text: string;
  correct: boolean;
  explanation?: string;
}

export interface MasterChallengeData {
  title: string;
  prompt: string;
  subtext: string;
  options: MasterChallengeOption[];
}

export const MASTER_CHALLENGES: Record<MainSubject, Record<GradeLevel, MasterChallengeData>> = {
  Math: {
    'K-2': {
      title: 'The Great Forest Count Summit',
      prompt: 'Terra collected 10 pinecones, 15 cedar sprigs, and 5 golden acorns. How many woodland treasures total?',
      subtext: 'Combine all three groups to unlock the Master Forest Crest: 10 + 15 + 5 = ?',
      options: [
        { id: 1, text: '30 Treasures in total', correct: true, explanation: '10 + 15 = 25, and 25 + 5 = 30 treasures!' },
        { id: 2, text: '25 Treasures in total', correct: false },
        { id: 3, text: '35 Treasures in total', correct: false },
        { id: 4, text: '20 Treasures in total', correct: false },
      ],
    },
    '3-5': {
      title: 'The Ancient Shrine Sanctuary Dimensions',
      prompt: 'A sacred forest garden has a length of 12 meters and width of 8 meters. Determine both its Area and Perimeter:',
      subtext: 'Area = Length × Width  |  Perimeter = 2 × (Length + Width)',
      options: [
        { id: 1, text: 'Area = 96 m²; Perimeter = 40 m', correct: true, explanation: '12 × 8 = 96 m², and 2 × (12 + 8) = 40 m.' },
        { id: 2, text: 'Area = 40 m²; Perimeter = 96 m', correct: false },
        { id: 3, text: 'Area = 84 m²; Perimeter = 38 m', correct: false },
        { id: 4, text: 'Area = 100 m²; Perimeter = 44 m', correct: false },
      ],
    },
    '6-8': {
      title: 'The Forest Slope & Linear Equilibrium',
      prompt: 'Two suspension cables balance the ancient canopy platform: 3x - 4 = 14 and y = 2x + 1. Find x and y at equilibrium:',
      subtext: 'Solve 3x - 4 = 14 for x, then substitute x into y = 2x + 1.',
      options: [
        { id: 1, text: 'x = 6; y = 13', correct: true, explanation: '3x = 18 => x = 6. Then y = 2(6) + 1 = 13.' },
        { id: 2, text: 'x = 5; y = 11', correct: false },
        { id: 3, text: 'x = 6; y = 12', correct: false },
        { id: 4, text: 'x = 8; y = 17', correct: false },
      ],
    },
    '9-12': {
      title: 'Canonical Trajectory of the Celestial Orb',
      prompt: 'y = -x² + 8x - 12',
      subtext: 'Determine the maximum altitude vertex reached by the orb and the coordinates where it touches ground (y = 0).',
      options: [
        {
          id: 1,
          text: 'Max height = 4 at x = 4; Roots at x = 2 and x = 6',
          correct: true,
          explanation: 'Vertex x = -b/(2a) = 4. Height = -(16) + 32 - 12 = 4. Roots: -(x - 2)(x - 6) = 0 => x = 2, 6.',
        },
        { id: 2, text: 'Max height = 6 at x = 3; Roots at x = 1 and x = 5', correct: false },
        { id: 3, text: 'Max height = 8 at x = 4; Roots at x = 0 and x = 8', correct: false },
        { id: 4, text: 'Max height = 2 at x = 2; Roots at x = 3 and x = 5', correct: false },
      ],
    },
  },
  Science: {
    'K-2': {
      title: 'The Biosphere Garden Synthesis',
      prompt: 'Which complete collection provides everything a forest sapling requires to thrive and flourish?',
      subtext: 'Identify all primary environmental necessities for photosynthesis and vitality.',
      options: [
        { id: 1, text: 'Sunlight, Fresh Water, Rich Soil & Clean Air', correct: true, explanation: 'All four components provide radiant photons, water, mineral nutrients, and carbon dioxide!' },
        { id: 2, text: 'Darkness, Dry Sand, Saltwater & Gravel', correct: false },
        { id: 3, text: 'Only Sunlight without any moisture', correct: false },
        { id: 4, text: 'Only Ice crystals and stone slabs', correct: false },
      ],
    },
    '3-5': {
      title: 'The Forest Food Web Equilibrium',
      prompt: 'A healthy forest ecosystem contains Sun ➔ Ferns ➔ Rabbits ➔ Lynx. How does energy flow and what role do decomposers play?',
      subtext: 'Synthesize trophic energy transfer and recycling across ecological niches.',
      options: [
        { id: 1, text: 'Energy flows from producers to consumers; decomposers recycle organic nutrients back to soil', correct: true, explanation: 'Solar energy transfers up trophic tiers, while fungi and bacteria decompose matter into bioavailable minerals.' },
        { id: 2, text: 'Energy flows backwards from apex predators down to sunlight without any nutrient loss', correct: false },
        { id: 3, text: 'Decomposers create new solar photons from dark river rocks', correct: false },
        { id: 4, text: 'Producers consume apex predators to power atmospheric rain clouds', correct: false },
      ],
    },
    '6-8': {
      title: 'The Photosynthesis & Respiration Equilibrium',
      prompt: '6 CO₂ + 6 H₂O + Light Energy ➔ C₆H₁₂O₆ + 6 O₂',
      subtext: 'Identify the chemical inputs and outputs that link plant photosynthesis with animal cellular respiration.',
      options: [
        { id: 1, text: 'Plants produce glucose & oxygen used in cellular respiration; respiration returns CO₂ and water', correct: true, explanation: 'The carbon and oxygen cycles are coupled: photosynthesis synthesizes carbohydrates, while respiration hydrolyzes them to produce ATP.' },
        { id: 2, text: 'Plants absorb oxygen to produce carbon monoxide and heavy nitrogen', correct: false },
        { id: 3, text: 'Respiration creates solar light rays directly inside the mitochondria', correct: false },
        { id: 4, text: 'Carbon dioxide is completely destroyed and transformed into lead ions', correct: false },
      ],
    },
    '9-12': {
      title: 'Thermodynamics & Trophic Biomass Cascade',
      prompt: 'A woodland biome produces 10,000 kJ of net primary biomass from solar radiation. Calculate energy reaching the tertiary carnivore tier:',
      subtext: 'Apply the Second Law of Thermodynamics and the Lindeman 10% Trophic Efficiency Rule across 3 successive transfers.',
      options: [
        { id: 1, text: 'Primary: 10,000 kJ ➔ Herbivores: 1,000 kJ ➔ Secondary: 100 kJ ➔ Tertiary: 10 kJ', correct: true, explanation: 'Each transfer conserves approximately 10% of chemical energy; 90% radiates as metabolic heat and cellular maintenance entropy.' },
        { id: 2, text: 'Primary: 10,000 kJ ➔ Herbivores: 5,000 kJ ➔ Secondary: 2,500 kJ ➔ Tertiary: 1,250 kJ', correct: false },
        { id: 3, text: 'Primary: 10,000 kJ ➔ Herbivores: 10,000 kJ ➔ Secondary: 10,000 kJ ➔ Tertiary: 10,000 kJ', correct: false },
        { id: 4, text: 'Primary: 10,000 kJ ➔ Herbivores: 100 kJ ➔ Secondary: 10 kJ ➔ Tertiary: 0.1 kJ', correct: false },
      ],
    },
  },
  'Language Arts': {
    'K-2': {
      title: 'The Woodland Fable Moral Summit',
      prompt: 'In the forest tale, the patient Tortoise steady-steps along while the boastful Hare rests. What is the central moral?',
      subtext: 'Identify the thematic lesson taught by this classic woodland fable.',
      options: [
        { id: 1, text: 'Slow, steady perseverance triumphs over overconfidence and haste', correct: true, explanation: 'Consistency and dedication win the race, showing perseverance is key!' },
        { id: 2, text: 'Always run as fast as possible then take a deep nap', correct: false },
        { id: 3, text: 'Never start any expedition through the woods', correct: false },
        { id: 4, text: 'Hiding in the hollow log guarantees victory', correct: false },
      ],
    },
    '3-5': {
      title: 'Figurative Language & Imagery Synthesis',
      prompt: '"The ancient weeping willow sighed in the evening breeze, wrapping its leafy shawl around the sleeping fawn."',
      subtext: 'Identify the primary literary device and its emotional effect on the reader.',
      options: [
        { id: 1, text: 'Personification (attributing human actions like sighing and wrapping a shawl to create a protective, soothing mood)', correct: true, explanation: 'The tree is personified as a caring guardian, creating a peaceful and nurturing mood.' },
        { id: 2, text: 'Hyperbole to exaggerate a dangerous wildfire explosion', correct: false },
        { id: 3, text: 'Onomatopoeia mimicking mechanical gears grinding', correct: false },
        { id: 4, text: 'Satire mocking the habits of woodland wildlife', correct: false },
      ],
    },
    '6-8': {
      title: 'Dramatic Irony & Narrative Vantage Point',
      prompt: 'An explorer tiptoes toward an ancient chest thinking it contains gold, while the audience already read the inscription revealing it houses a swarm of forest sprites.',
      subtext: 'Identify the type of irony and why it intensifies narrative suspense.',
      options: [
        { id: 1, text: 'Dramatic Irony: the audience possesses crucial knowledge that the protagonist lacks, creating anticipation and tension', correct: true, explanation: 'Dramatic irony builds reader engagement through the discrepancy between character awareness and audience insight.' },
        { id: 2, text: 'Situational Irony because gold coins turned into physical granite', correct: false },
        { id: 3, text: 'Verbal Irony because the explorer shouted a sarcastic pun', correct: false },
        { id: 4, text: 'Historical Irony examining ancient political treatises', correct: false },
      ],
    },
    '9-12': {
      title: 'Classical Rhetoric & Deductive Argumentation',
      prompt: 'Major Premise: All balanced forest ecosystems depend upon keystone predators. Minor Premise: Wolves are keystone predators of the Northern Woods. Conclusion: The Northern Woods depends upon wolves for ecosystem balance.',
      subtext: 'Identify the classical logical structure and verify its validity:',
      options: [
        { id: 1, text: 'Valid Categorical Syllogism (Deductive reasoning where the conclusion logically and necessarily follows from true premises)', correct: true, explanation: 'The categorical syllogism follows Barbara form (AAA-1), logically guaranteeing the truth of the conclusion.' },
        { id: 2, text: 'Inductive generalization vulnerable to the Post Hoc Fallacy', correct: false },
        { id: 3, text: 'Ad Hominem argument discrediting the speaker’s character', correct: false },
        { id: 4, text: 'Circular reasoning (Begging the Question) with tautological premises', correct: false },
      ],
    },
  },
};

export function getMasterChallenge(grade: GradeLevel, subject: MainSubject): MasterChallengeData {
  return MASTER_CHALLENGES[subject]?.[grade] || MASTER_CHALLENGES.Math['6-8'];
}


