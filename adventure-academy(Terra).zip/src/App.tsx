import React, { useState, useEffect } from 'react';
import { NavigationHeader } from './components/NavigationHeader';
import { TitleScreen } from './components/TitleScreen';
import { LoginModal } from './components/LoginModal';
import { CharacterSetup } from './components/CharacterSetup';
import { OrientationTrial } from './components/OrientationTrial';
import { WorldMap } from './components/WorldMap';
import { GameplayHome } from './components/GameplayHome';
import { BridgeQuest } from './components/BridgeQuest';
import { ParabolaLab } from './components/ParabolaLab';
import { RiverSteppingStones } from './components/RiverSteppingStones';
import { NovaInsightsView } from './components/NovaInsightsView';
import { KnowledgeGate } from './components/KnowledgeGate';
import { CampGardenView } from './components/CampGardenView';
import { MasterChallenge } from './components/MasterChallenge';
import { ReforestationGrove } from './components/ReforestationGrove';
import { ProbabilityMeadowChallenge } from './components/ProbabilityMeadowChallenge';
import { TrigonometryTrailChallenge } from './components/TrigonometryTrailChallenge';
import { GeometryCanopyChallenge } from './components/GeometryCanopyChallenge';
import { ExponentCrystalCavern } from './components/ExponentCrystalCavern';
import { CalculusCascadeChallenge } from './components/CalculusCascadeChallenge';
import { MatrixCipherChallenge } from './components/MatrixCipherChallenge';
import { PlayerProfile, Quest } from './types';
import { sounds } from './utils/soundEffects';
import { generateQuestsForGradeAndSubject } from './data/curriculumData';

const INITIAL_PLAYER: PlayerProfile = {
  id: 'explorer-1',
  name: 'Forest Scholar Ash',
  email: 'explorer@whisperingwoods.org',
  grade: '6-8',
  mainSubject: 'Math',
  avatar: 'sage',
  level: 1,
  xp: 120,
  xpToNextLevel: 500,
  streakDays: 5,
  resources: {
    seeds: 10,
    water: 5,
    fertilizer: 3,
  },
  unlockedAreas: ['Algebra Grove'],
  currentArea: 'Algebra Grove',
  completedQuests: [],
  skillMastery: {
    'Quadratic Equations': 78,
  },
  learningStats: {
    visualSpeedScore: 80,
    textSpeedScore: 50,
    visualChallengesSolved: 14,
    textChallengesSolved: 6,
    accuracyRate: 88,
    totalAttempts: 22,
    hintsRequested: 4,
    strongTopics: ['Algebra', 'Linear Equations'],
    developingTopics: ['Graph Interpretation', 'Parabolas'],
    recommendedPath: 'visual',
  },
  camp: {
    level: 2,
    buildings: {
      mapTable: { built: true, level: 1 },
      knowledgeBoard: { built: true, level: 1 },
      explorerTent: { built: true, level: 1 },
      plantBed: { built: true, level: 1, plantsCount: 2 },
    },
    plants: [
      { id: 'p1', name: 'Algebra Bloom', stage: 'harvestable', waterLevel: 3, fertilizerApplied: true },
      { id: 'p2', name: 'Geometry Vine', stage: 'growing', waterLevel: 2, fertilizerApplied: false },
      { id: 'p3', name: 'Calculus Sprout', stage: 'sprout', waterLevel: 1, fertilizerApplied: false },
      { id: 'p4', name: 'Empty Bed', stage: 'seed', waterLevel: 0, fertilizerApplied: false },
    ],
  },
  // Save the Planet Hackathon Reforestation Grove
  realTreesPlanted: 2,
  totalSaplingsGrown: 7,
  co2OffsetKg: 44,
  plantedTreeCertificates: [
    {
      id: 'ECO-TREE-8821',
      species: 'Rhizophora mucronata',
      commonName: 'Asiatic Red Mangrove',
      region: 'Mahajanga Estuary, Madagascar',
      coordinates: { lat: -15.7167, lng: 46.3167 },
      plantedAt: Date.now() - 86400000 * 3,
      co2PerYearKg: 24,
      partner: 'Eden Reforestation Projects',
      dedicatedTo: 'Forest Scholar Ash',
      certificateHash: 'sha256-a9f8b7c6d5e4',
      realWorldImpact: 'Stabilizes coastal estuaries and sequesters 24kg CO2 annually.',
    },
    {
      id: 'ECO-TREE-8822',
      species: 'Acacia senegal',
      commonName: 'Gum Acacia',
      region: 'Great Green Wall, Senegal',
      coordinates: { lat: 14.4974, lng: -14.4524 },
      plantedAt: Date.now() - 86400000,
      co2PerYearKg: 20,
      partner: 'One Tree Planted Alliance',
      dedicatedTo: 'Forest Scholar Ash',
      certificateHash: 'sha256-e3d2c1b0a9f8',
      realWorldImpact: 'Combats desertification along the Sahel corridor.',
    },
  ],
  forestTrees: [
    {
      id: 'ft-1',
      species: 'Sequoiadendron giganteum',
      commonName: 'Giant Sequoia',
      growthPercent: 85,
      seedsInvested: 5,
      waterGiven: 4,
      fertilizerGiven: 2,
      stage: 'canopy',
      completedRealTree: false,
    },
    {
      id: 'ft-2',
      species: 'Adansonia digitata',
      commonName: 'African Baobab',
      growthPercent: 40,
      seedsInvested: 3,
      waterGiven: 2,
      fertilizerGiven: 1,
      stage: 'sapling',
      completedRealTree: false,
    },
    {
      id: 'ft-3',
      species: 'Swietenia macrophylla',
      commonName: 'Big-Leaf Mahogany',
      growthPercent: 15,
      seedsInvested: 2,
      waterGiven: 1,
      fertilizerGiven: 0,
      stage: 'sprout',
      completedRealTree: false,
    },
  ],
};

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<string>('title');
  const [player, setPlayer] = useState<PlayerProfile>(INITIAL_PLAYER);
  const [quests, setQuests] = useState<Quest[]>(() =>
    generateQuestsForGradeAndSubject(INITIAL_PLAYER.grade, INITIAL_PLAYER.mainSubject)
  );

  // Fetch initial profile and quests from backend Express API on mount
  useEffect(() => {
    async function loadData() {
      try {
        const [profRes, questRes] = await Promise.all([
          fetch('/api/player/profile'),
          fetch('/api/quests'),
        ]);

        if (profRes.ok) {
          const profData = await profRes.json();
          if (profData.profile) setPlayer(profData.profile);
        }
        if (questRes.ok) {
          const questData = await questRes.json();
          if (questData.quests) setQuests(questData.quests);
        }
      } catch (e) {
        console.log('Using local client state for Adventure Academy');
      }
    }
    loadData();
  }, []);

  // Update profile handler (persisting to backend)
  const handleUpdateProfile = async (updates: Partial<PlayerProfile>) => {
    const updated = { ...player, ...updates };
    setPlayer(updated);

    // If grade or main subject changed, dynamically regenerate the quest log
    if (
      (updates.grade && updates.grade !== player.grade) ||
      (updates.mainSubject && updates.mainSubject !== player.mainSubject)
    ) {
      const regeneratedQuests = generateQuestsForGradeAndSubject(updated.grade, updated.mainSubject);
      setQuests(regeneratedQuests);
    }

    try {
      await fetch('/api/player/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
    } catch (e) {
      // offline fallback
    }
  };

  // Add rewards on quest completion & boost living forest saplings
  const handleAddRewards = (rewards: { xp: number; seeds: number; water: number; fertilizer: number }) => {
    const newXp = player.xp + rewards.xp;
    const newLevel = newXp >= player.xpToNextLevel ? player.level + 1 : player.level;

    // Boost the first uncompleted tree in the living forest with quest eco-energy!
    const updatedTrees = (player.forestTrees || []).map((tree, index) => {
      if (!tree.completedRealTree && tree.growthPercent < 100) {
        const boosted = Math.min(100, tree.growthPercent + 15);
        return {
          ...tree,
          growthPercent: boosted,
          stage: (boosted >= 100 ? 'mature' : boosted >= 60 ? 'canopy' : boosted >= 30 ? 'sapling' : 'sprout') as any,
        };
      }
      return tree;
    });

    const updatedProfile: PlayerProfile = {
      ...player,
      level: newLevel,
      xp: newXp,
      resources: {
        seeds: player.resources.seeds + rewards.seeds,
        water: player.resources.water + rewards.water,
        fertilizer: player.resources.fertilizer + rewards.fertilizer,
      },
      forestTrees: updatedTrees,
    };

    handleUpdateProfile(updatedProfile);
  };

  const handleNavigate = (screenId: string) => {
    sounds.playClick();
    setCurrentScreen(screenId);
  };

  return (
    <div className="min-h-screen bg-[#120a05] text-[#f4ecd8] flex flex-col font-serif select-none overflow-x-hidden">
      {/* Top HUD with Inventory, Level, Resources & Scene Switcher */}
      <NavigationHeader
        currentScreen={currentScreen}
        onSelectScreen={handleNavigate}
        player={player}
      />

      {/* Main Dynamic Screen Viewport */}
      <main className="flex-1 relative">
        {currentScreen === 'title' && (
          <TitleScreen
            onStart={() => setCurrentScreen('setup')}
            onOpenLogin={() => setCurrentScreen('login')}
          />
        )}

        {currentScreen === 'login' && (
          <LoginModal
            onSuccess={(prof) => {
              setPlayer(prof);
              setCurrentScreen('hub');
            }}
            onBack={() => setCurrentScreen('title')}
          />
        )}

        {currentScreen === 'setup' && (
          <CharacterSetup
            player={player}
            onComplete={(updates) => {
              handleUpdateProfile(updates);
              setCurrentScreen('orientation');
            }}
            onBack={() => setCurrentScreen('title')}
          />
        )}

        {currentScreen === 'orientation' && (
          <OrientationTrial
            player={player}
            onComplete={(score) => {
              handleAddRewards({ xp: 100, seeds: 2, water: 2, fertilizer: 1 });
              setCurrentScreen('map');
            }}
            onSkip={() => setCurrentScreen('map')}
          />
        )}

        {currentScreen === 'map' && (
          <WorldMap
            player={player}
            onSelectArea={(areaId) => {
              handleUpdateProfile({ currentArea: areaId });
              if (areaId === 'Probability Meadow') setCurrentScreen('probability');
              else if (areaId === 'Trigonometry Trail') setCurrentScreen('trigonometry');
              else if (areaId === 'Geometry Canopy') setCurrentScreen('geometryCanopy');
              else if (areaId === 'Exponent Cavern') setCurrentScreen('crystals');
              else if (areaId === 'Calculus Cascade') setCurrentScreen('calculus');
              else if (areaId === 'Matrix Cryptography Shrine') setCurrentScreen('cipher');
              else if (areaId === 'Exam Summit') setCurrentScreen('master');
              else setCurrentScreen('hub');
            }}
            onBack={() => setCurrentScreen('hub')}
          />
        )}

        {currentScreen === 'hub' && (
          <GameplayHome
            player={player}
            quests={quests}
            onStartQuest={(questId) => {
              if (questId === 'quest-02' || questId === 'quest-02-parabola') setCurrentScreen('parabola');
              else if (questId === 'quest-03' || questId === 'quest-03-river-stones') setCurrentScreen('steppingStones');
              else if (questId === 'quest-04' || questId === 'quest-04-geometry-canopy') setCurrentScreen('geometryCanopy');
              else if (questId === 'quest-05' || questId === 'quest-05-geometry-gate') setCurrentScreen('gate');
              else if (questId === 'quest-06' || questId === 'quest-06-probability-meadow') setCurrentScreen('probability');
              else if (questId === 'quest-07' || questId === 'quest-07-trigonometry-trail') setCurrentScreen('trigonometry');
              else if (questId === 'quest-08' || questId === 'quest-08-master-circle') setCurrentScreen('master');
              else if (questId === 'quest-09' || questId === 'quest-09-exponent-caverns') setCurrentScreen('crystals');
              else if (questId === 'quest-10' || questId === 'quest-10-calculus-cascade') setCurrentScreen('calculus');
              else if (questId === 'quest-11' || questId === 'quest-11-matrix-cipher') setCurrentScreen('cipher');
              else setCurrentScreen('bridge');
            }}
            onNavigate={handleNavigate}
          />
        )}

        {currentScreen === 'bridge' && (
          <BridgeQuest
            player={player}
            onCompleteQuest={handleAddRewards}
            onNextQuest={() => setCurrentScreen('parabola')}
          />
        )}

        {currentScreen === 'parabola' && (
          <ParabolaLab
            player={player}
            onComplete={handleAddRewards}
            onNext={() => setCurrentScreen('steppingStones')}
          />
        )}

        {currentScreen === 'steppingStones' && (
          <RiverSteppingStones
            player={player}
            onComplete={handleAddRewards}
            onNext={() => setCurrentScreen('insights')}
          />
        )}

        {currentScreen === 'probability' && (
          <ProbabilityMeadowChallenge
            player={player}
            onComplete={handleAddRewards}
            onNext={() => setCurrentScreen('trigonometry')}
            onBackToMap={() => setCurrentScreen('map')}
          />
        )}

        {currentScreen === 'trigonometry' && (
          <TrigonometryTrailChallenge
            player={player}
            onComplete={handleAddRewards}
            onNext={() => setCurrentScreen('geometryCanopy')}
            onBackToMap={() => setCurrentScreen('map')}
          />
        )}

        {currentScreen === 'geometryCanopy' && (
          <GeometryCanopyChallenge
            player={player}
            onComplete={handleAddRewards}
            onNext={() => setCurrentScreen('crystals')}
            onBackToMap={() => setCurrentScreen('map')}
          />
        )}

        {currentScreen === 'crystals' && (
          <ExponentCrystalCavern
            player={player}
            onComplete={handleAddRewards}
            onNext={() => setCurrentScreen('calculus')}
            onBackToMap={() => setCurrentScreen('map')}
          />
        )}

        {currentScreen === 'calculus' && (
          <CalculusCascadeChallenge
            player={player}
            onComplete={handleAddRewards}
            onNext={() => setCurrentScreen('cipher')}
            onBackToMap={() => setCurrentScreen('map')}
          />
        )}

        {currentScreen === 'cipher' && (
          <MatrixCipherChallenge
            player={player}
            onComplete={handleAddRewards}
            onNext={() => setCurrentScreen('master')}
            onBackToMap={() => setCurrentScreen('map')}
          />
        )}

        {currentScreen === 'insights' && (
          <NovaInsightsView
            player={player}
            onChoosePath={(path) => {
              if (path === 'visual') setCurrentScreen('parabola');
              else setCurrentScreen('bridge');
            }}
            onNavigate={handleNavigate}
          />
        )}

        {currentScreen === 'gate' && (
          <KnowledgeGate
            player={player}
            onUnlockRealm={(realmName, rewards) => {
              const updatedUnlocked = Array.from(new Set([...player.unlockedAreas, realmName]));
              handleUpdateProfile({
                unlockedAreas: updatedUnlocked,
                currentArea: realmName,
              });
              handleAddRewards(rewards);
            }}
            onNext={() => setCurrentScreen('camp')}
          />
        )}

        {currentScreen === 'camp' && (
          <CampGardenView
            player={player}
            onUpdatePlayer={(updated) => setPlayer(updated)}
            onNavigate={handleNavigate}
          />
        )}

        {currentScreen === 'grove' && (
          <ReforestationGrove
            player={player}
            onUpdatePlayer={(updated) => setPlayer(updated)}
            onNavigate={handleNavigate}
          />
        )}

        {currentScreen === 'master' && (
          <MasterChallenge
            player={player}
            onComplete={handleAddRewards}
            onBackToTitle={() => setCurrentScreen('title')}
          />
        )}
      </main>
    </div>
  );
}
