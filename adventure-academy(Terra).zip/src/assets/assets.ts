// Exported asset image paths generated for Adventure Academy scenes
import forestPath from './images/academy_forest_path_1788805385925.jpg';
import campFire from './images/academy_camp_fire_1788805415321.jpg';
import ruinsGate from './images/ancient_ruins_gate_1788805436943.jpg';
import worldMap from './images/parchment_world_map_1788805466605.jpg';
import scienceMap from './images/science_biosphere_map_1788842567379.jpg';
import literatureMap from './images/literature_lore_map_1788842581878.jpg';
import masteryTree from './images/magical_mastery_tree_1788805499138.jpg';
import steppingStones from './images/river_stepping_stones_1788805534641.jpg';
import scholarExplorer from './images/forest_explorer_1788840902081.jpg';
import terraCompanion from './images/terra_forest_spirit_1788840217625.jpg';

export const ASSETS = {
  forestPath,
  forestBackground: forestPath,
  campFire,
  ruinsGate,
  worldMap,
  mathMap: worldMap,
  scienceMap,
  literatureMap,
  masteryTree,
  sacredTree: masteryTree,
  steppingStones,
  scholarExplorer,
  forestExplorer: scholarExplorer,
  terraCompanion,
};
